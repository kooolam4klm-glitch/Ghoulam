from datetime import datetime, timezone
import time


class MT5Connection:
    """Keep the MT5 terminal session alive and fetch the quote after chart data.

    This module intentionally only reads market/account data. It does not expose
    any order_send path.
    """
    def __init__(self):
        self.mt5 = None
        self.initialized = False
        self._today_pnl_cache = 0.0
        self._today_pnl_checked_at = 0.0
        self._today_pnl_available = False
        try:
            import MetaTrader5 as mt5
            self.mt5 = mt5
        except Exception:
            self.mt5 = None

    def _timeframe(self, name):
        mapping = {
            "M1": "TIMEFRAME_M1", "M5": "TIMEFRAME_M5", "M15": "TIMEFRAME_M15",
            "M30": "TIMEFRAME_M30", "H1": "TIMEFRAME_H1", "H4": "TIMEFRAME_H4",
            "D1": "TIMEFRAME_D1"
        }
        if name not in mapping:
            raise ValueError(f"إطار زمني غير مدعوم: {name}")
        return getattr(self.mt5, mapping[name])

    def _ensure_initialized(self):
        # Do not call initialize() on every UI refresh; repeatedly initializing
        # can add latency and makes it harder to distinguish a stable session.
        if self.initialized:
            try:
                if self.mt5.terminal_info() is not None:
                    return True, None
            except Exception:
                pass
            self.initialized = False
        if not self.mt5.initialize():
            return False, f"تعذر تهيئة MT5: {self.mt5.last_error()}"
        self.initialized = True
        return True, None

    def _require_live_terminal(self):
        """Return an error when the terminal process is open but broker link is down."""
        try:
            terminal = self.mt5.terminal_info()
        except Exception as exc:
            self.initialized = False
            return f"تعذر قراءة حالة منصة MT5: {exc}"
        if terminal is None:
            self.initialized = False
            return f"تعذر قراءة حالة منصة MT5: {self.mt5.last_error()}"
        if not bool(getattr(terminal, "connected", False)):
            return "منصة MT5 مفتوحة، لكن اتصالها بخادم الوسيط منقطع. لن تُستخدم البيانات المخزنة مؤقتاً."
        return None

    def connect_and_read(self, symbol, timeframe):
        if self.mt5 is None:
            return {"ok": False, "error": "حزمة MetaTrader5 غير متاحة. نفّذ pip install -r requirements.txt."}
        try:
            ok, err = self._ensure_initialized()
            if not ok:
                return {"ok": False, "error": err}
            # A running terminal process is not proof of a live broker connection.
            # MT5 may keep cached account/bars/ticks while the network is down.
            live_error = self._require_live_terminal()
            if live_error:
                return {"ok": False, "error": live_error}
            account = self.mt5.account_info()
            if account is None:
                # Mark the session for a clean reinitialization on the next call.
                self.initialized = False
                return {"ok": False, "error": f"لا توجد معلومات حساب: {self.mt5.last_error()}"}

            symbol = symbol.strip()
            if not self.mt5.symbol_select(symbol, True):
                return {"ok": False, "error": f"الرمز {symbol} غير متاح أو لم يتم تفعيله في Market Watch."}

            # Read the candle series first, then request the quote last so that
            # any ticks received while bars are fetched are reflected in Bid/Ask.
            bars = self.mt5.copy_rates_from_pos(symbol, self._timeframe(timeframe), 0, 150)
            tick = self.mt5.symbol_info_tick(symbol)
            # Capture receipt immediately after requesting the most recent quote.
            # This is local receipt time, not the broker/server tick timestamp.
            received_epoch = time.time()
            received_local = datetime.fromtimestamp(received_epoch).astimezone().strftime("%Y-%m-%d %H:%M:%S (محلي)")
            if tick is None or bars is None or len(bars) == 0:
                return {"ok": False, "error": f"تعذر قراءة بيانات الرمز: {self.mt5.last_error()}"}

            trade_modes = {
                getattr(self.mt5, "ACCOUNT_TRADE_MODE_DEMO", 0): "DEMO",
                getattr(self.mt5, "ACCOUNT_TRADE_MODE_CONTEST", 2): "CONTEST",
                getattr(self.mt5, "ACCOUNT_TRADE_MODE_REAL", 1): "REAL"
            }
            account_dict = {
                "login": getattr(account, "login", "—"),
                "balance": float(getattr(account, "balance", 0.0)),
                "equity": float(getattr(account, "equity", 0.0)),
                "currency": str(getattr(account, "currency", "")),
                "server": str(getattr(account, "server", "—")),
                "trade_mode": trade_modes.get(getattr(account, "trade_mode", -1), "UNKNOWN"),
                "floating_pnl": float(getattr(account, "profit", 0.0) or 0.0),
                "margin": float(getattr(account, "margin", 0.0) or 0.0),
                "margin_free": float(getattr(account, "margin_free", 0.0) or 0.0),
            }
            # Positions and history are read-only. No order functions are used.
            positions = []
            positions_available = False
            try:
                raw_positions = self.mt5.positions_get()
                positions_available = raw_positions is not None
                for pos in (raw_positions or []):
                    pos_type = getattr(pos, "type", -1)
                    buy_type = getattr(self.mt5, "POSITION_TYPE_BUY", 0)
                    positions.append({
                        "ticket": int(getattr(pos, "ticket", 0) or 0),
                        "symbol": str(getattr(pos, "symbol", "")),
                        "direction": "BUY" if pos_type == buy_type else "SELL",
                        "volume": float(getattr(pos, "volume", 0.0) or 0.0),
                        "price_open": float(getattr(pos, "price_open", 0.0) or 0.0),
                        "price_current": float(getattr(pos, "price_current", 0.0) or 0.0),
                        "profit": float(getattr(pos, "profit", 0.0) or 0.0),
                        "swap": float(getattr(pos, "swap", 0.0) or 0.0),
                        "sl": float(getattr(pos, "sl", 0.0) or 0.0),
                        "tp": float(getattr(pos, "tp", 0.0) or 0.0),
                    })
            except Exception:
                positions = []
            # Account-wide realized result for the current UTC calendar day. Cache it
            # for 30 seconds to avoid requesting the entire deal history every tick.
            now_wall = time.time()
            if now_wall - self._today_pnl_checked_at >= 30:
                self._today_pnl_checked_at = now_wall
                self._today_pnl_available = False
                try:
                    from datetime import timedelta
                    now_utc = datetime.now(timezone.utc)
                    start_utc = datetime(now_utc.year, now_utc.month, now_utc.day, tzinfo=timezone.utc)
                    deals = self.mt5.history_deals_get(start_utc, now_utc)
                    if deals is not None:
                        self._today_pnl_cache = sum(
                            float(getattr(deal, "profit", 0.0) or 0.0)
                            + float(getattr(deal, "commission", 0.0) or 0.0)
                            + float(getattr(deal, "swap", 0.0) or 0.0)
                            + float(getattr(deal, "fee", 0.0) or 0.0)
                            for deal in deals
                        )
                        self._today_pnl_available = True
                except Exception:
                    pass
            account_dict["today_realized_pnl"] = self._today_pnl_cache if self._today_pnl_available else None
            account_dict["today_pnl_available"] = self._today_pnl_available
            account_dict["open_positions"] = positions
            account_dict["positions_count"] = len(positions)
            account_dict["positions_available"] = positions_available
            if positions_available:
                account_dict["floating_pnl"] = sum(p["profit"] + p["swap"] for p in positions)
            symbol_info = self.mt5.symbol_info(symbol)
            return {"ok": True, "account": account_dict, "tick": tick, "bars": bars,
                    "read_received_epoch": received_epoch,
                    "read_received_local_label": received_local,
                    "read_perf_counter": time.perf_counter(),
                    "symbol_info": {
                        "digits": getattr(symbol_info, "digits", 5),
                        "point": getattr(symbol_info, "point", 0.00001),
                        "trade_tick_size": getattr(symbol_info, "trade_tick_size", 0.0),
                        "trade_tick_value": getattr(symbol_info, "trade_tick_value", 0.0),
                        "volume_min": getattr(symbol_info, "volume_min", 0.0),
                        "volume_max": getattr(symbol_info, "volume_max", 0.0),
                        "volume_step": getattr(symbol_info, "volume_step", 0.0),
                    }}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def read_context_frames(self, symbol, timeframes=("M15", "H1", "H4"), count=120):
        """Fetch multi-timeframe closed-candle context. Read-only; no order API."""
        if self.mt5 is None:
            return {"ok": False, "error": "حزمة MetaTrader5 غير متاحة."}
        try:
            ok, err = self._ensure_initialized()
            if not ok:
                return {"ok": False, "error": err}
            live_error = self._require_live_terminal()
            if live_error:
                return {"ok": False, "error": live_error}
            symbol = str(symbol).strip()
            if not symbol:
                return {"ok": False, "error": "رمز الأداة فارغ."}
            if not self.mt5.symbol_select(symbol, True):
                return {"ok": False, "error": f"الرمز {symbol} غير متاح في Market Watch."}
            frames = {}
            errors = {}
            for name in timeframes:
                try:
                    rates = self.mt5.copy_rates_from_pos(symbol, self._timeframe(name), 0, int(count))
                    if rates is None or len(rates) == 0:
                        errors[name] = str(self.mt5.last_error())
                    else:
                        frames[name] = rates
                except Exception as exc:
                    errors[name] = str(exc)
            if not frames:
                return {"ok": False, "error": "تعذر جلب شموع السياق متعدد الأطر: " + repr(errors)}
            return {"ok": True, "frames": frames, "errors": errors}
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

    def read_chart_data(self, symbol, timeframe, count=150):
        """Read-only chart payload for the built-in chart window."""
        if self.mt5 is None:
            return {"ok": False, "error": "حزمة MetaTrader5 غير متاحة."}
        try:
            ok, err = self._ensure_initialized()
            if not ok:
                return {"ok": False, "error": err}
            live_error = self._require_live_terminal()
            if live_error:
                return {"ok": False, "error": live_error}
            symbol = str(symbol or "").strip()
            if not symbol:
                return {"ok": False, "error": "رمز الأداة فارغ."}
            if not self.mt5.symbol_select(symbol, True):
                return {"ok": False, "error": f"الرمز {symbol} غير متاح في Market Watch."}
            safe_count = max(60, min(500, int(count)))
            rates = self.mt5.copy_rates_from_pos(symbol, self._timeframe(timeframe), 0, safe_count)
            tick = self.mt5.symbol_info_tick(symbol)
            info = self.mt5.symbol_info(symbol)
            if rates is None or len(rates) == 0:
                return {"ok": False, "error": f"تعذر جلب شموع الشارت: {self.mt5.last_error()}"}
            return {
                "ok": True, "bars": rates, "tick": tick,
                "digits": int(getattr(info, "digits", 2)) if info is not None else 2,
                "point": float(getattr(info, "point", 0.01)) if info is not None else 0.01,
            }
        except Exception as exc:
            return {"ok": False, "error": str(exc)}

