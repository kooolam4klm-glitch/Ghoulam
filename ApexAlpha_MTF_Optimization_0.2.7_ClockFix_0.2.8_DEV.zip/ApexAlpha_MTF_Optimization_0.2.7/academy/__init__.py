"""Apex Alpha Strategy Academy: persistent lesson and strategy library."""
