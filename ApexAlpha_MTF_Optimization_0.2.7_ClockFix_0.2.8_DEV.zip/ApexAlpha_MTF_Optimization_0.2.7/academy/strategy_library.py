"""Persistent, local-first library for lessons and extracted trading strategies.

The library stores transcripts and analysis, not downloaded media. Strategies remain
informational drafts until separately tested; this module never connects to MT5 or
places orders.
"""
from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

DB_PATH = Path.home() / "ApexAlpha" / "strategy_academy.sqlite3"


def _connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(DB_PATH), timeout=10)
    con.row_factory = sqlite3.Row
    return con


@contextmanager
def _db():
    con = _connect()
    try:
        with con:
            yield con
    finally:
        con.close()


def initialize_db() -> None:
    with _db() as con:
        con.execute(
            """CREATE TABLE IF NOT EXISTS lessons (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                source_type TEXT NOT NULL DEFAULT 'text',
                source_uri TEXT NOT NULL DEFAULT '',
                transcript TEXT NOT NULL DEFAULT '',
                analysis_text TEXT NOT NULL DEFAULT '',
                strategy_json TEXT NOT NULL DEFAULT '{}',
                status TEXT NOT NULL DEFAULT 'needs_transcript',
                model TEXT NOT NULL DEFAULT '',
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )"""
        )
        con.execute("CREATE INDEX IF NOT EXISTS idx_lessons_updated ON lessons(updated_at DESC)")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def save_lesson(
    title: str,
    source_type: str = "text",
    source_uri: str = "",
    transcript: str = "",
    lesson_id: int | None = None,
    analysis_text: str | None = None,
    strategy: dict[str, Any] | None = None,
    status: str | None = None,
    model: str | None = None,
) -> int:
    """Create or update a lesson. Existing analysis/status are retained if omitted."""
    initialize_db()
    title = str(title or "درس دون عنوان").strip()[:250] or "درس دون عنوان"
    source_type = str(source_type or "text").strip()[:32]
    source_uri = str(source_uri or "").strip()[:2000]
    transcript = str(transcript or "")[:1_000_000]
    now = _now()
    with _db() as con:
        if lesson_id is not None:
            current = con.execute("SELECT * FROM lessons WHERE id=?", (int(lesson_id),)).fetchone()
            if current is not None:
                transcript_changed = str(current["transcript"] or "") != transcript
                if analysis_text is None:
                    new_analysis = "" if transcript_changed else current["analysis_text"]
                else:
                    new_analysis = str(analysis_text)
                if strategy is None:
                    new_strategy = "{}" if transcript_changed else current["strategy_json"]
                else:
                    new_strategy = json.dumps(strategy, ensure_ascii=False)
                if status is None:
                    new_status = ("draft" if transcript.strip() else "needs_transcript") if transcript_changed else current["status"]
                else:
                    new_status = str(status)
                new_model = ("" if transcript_changed else current["model"]) if model is None else str(model)
                con.execute(
                    """UPDATE lessons SET title=?, source_type=?, source_uri=?, transcript=?,
                       analysis_text=?, strategy_json=?, status=?, model=?, updated_at=? WHERE id=?""",
                    (title, source_type, source_uri, transcript, new_analysis, new_strategy,
                     new_status, new_model, now, int(lesson_id)),
                )
                return int(lesson_id)
        actual_status = status or ("needs_transcript" if not transcript.strip() else "draft")
        cur = con.execute(
            """INSERT INTO lessons(title, source_type, source_uri, transcript, analysis_text,
               strategy_json, status, model, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (title, source_type, source_uri, transcript, analysis_text or "",
             json.dumps(strategy or {}, ensure_ascii=False), actual_status, model or "", now, now),
        )
        return int(cur.lastrowid)


def save_analysis(lesson_id: int, analysis_text: str, strategy: dict[str, Any] | None, model: str) -> None:
    initialize_db()
    with _db() as con:
        cur = con.execute(
            """UPDATE lessons SET analysis_text=?, strategy_json=?, status='draft_untested',
               model=?, updated_at=? WHERE id=?""",
            (str(analysis_text or ""), json.dumps(strategy or {}, ensure_ascii=False),
             str(model or ""), _now(), int(lesson_id)),
        )
        if cur.rowcount == 0:
            raise KeyError(f"Lesson {lesson_id} does not exist")


def get_lesson(lesson_id: int) -> dict[str, Any] | None:
    initialize_db()
    with _db() as con:
        row = con.execute("SELECT * FROM lessons WHERE id=?", (int(lesson_id),)).fetchone()
    if row is None:
        return None
    result = dict(row)
    try:
        result["strategy"] = json.loads(result.pop("strategy_json") or "{}")
    except (json.JSONDecodeError, TypeError):
        result["strategy"] = {}
        result.pop("strategy_json", None)
    return result


def list_lessons(search: str = "", limit: int = 500) -> list[dict[str, Any]]:
    initialize_db()
    search = str(search or "").strip()
    like = f"%{search}%"
    with _db() as con:
        if search:
            rows = con.execute(
                """SELECT id, title, source_type, source_uri, status, updated_at FROM lessons
                   WHERE title LIKE ? OR transcript LIKE ? OR analysis_text LIKE ?
                   ORDER BY updated_at DESC LIMIT ?""",
                (like, like, like, max(1, min(int(limit), 1000))),
            ).fetchall()
        else:
            rows = con.execute(
                """SELECT id, title, source_type, source_uri, status, updated_at FROM lessons
                   ORDER BY updated_at DESC LIMIT ?""",
                (max(1, min(int(limit), 1000)),),
            ).fetchall()
    return [dict(row) for row in rows]


def delete_lesson(lesson_id: int) -> bool:
    initialize_db()
    with _db() as con:
        cur = con.execute("DELETE FROM lessons WHERE id=?", (int(lesson_id),))
    return cur.rowcount > 0


def parse_subtitle_text(text: str) -> str:
    """Convert common SRT/VTT subtitle text into readable transcript paragraphs."""
    import re

    raw = str(text or "").replace("\ufeff", "")
    output: list[str] = []
    seen: set[str] = set()
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.upper() == "WEBVTT" or line.startswith(("NOTE ", "Kind:", "Language:")):
            continue
        if line.isdigit():
            continue
        if "-->" in line:
            continue
        line = re.sub(r"<[^>]+>", "", line)
        line = re.sub(r"\{\\an\d+\}", "", line)
        line = re.sub(r"&amp;", "&", line, flags=re.I)
        line = re.sub(r"&lt;", "<", line, flags=re.I)
        line = re.sub(r"&gt;", ">", line, flags=re.I)
        line = re.sub(r"\s+", " ", line).strip()
        if not line:
            continue
        # Subtitle exporters often repeat adjacent cues; suppress only adjacent repeats.
        if output and output[-1].casefold() == line.casefold():
            continue
        output.append(line)
    return "\n".join(output)
