"""Lesson ingestion helpers: caption retrieval and explicit audio transcription.

No video is downloaded by the URL workflow: only available subtitle/caption files are
requested from supported extractors. If captions are unavailable, import a subtitle or
transcribe a local media file with the configured API key.
"""
from __future__ import annotations

import json
import os
import subprocess
import tempfile
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from academy.strategy_library import parse_subtitle_text

MAX_UPLOAD_BYTES = 25 * 1024 * 1024
VIDEO_EXTENSIONS = {".mp4", ".m4v", ".mov", ".webm", ".mkv", ".avi"}
AUDIO_EXTENSIONS = {".mp3", ".m4a", ".wav", ".ogg", ".flac", ".mpeg", ".mpga", ".webm", ".mp4"}


def fetch_available_captions(url: str) -> tuple[str, str]:
    """Return (transcript, title) using available captions where yt-dlp supports the URL."""
    url = str(url or "").strip()
    if not (url.startswith("https://") or url.startswith("http://")):
        raise ValueError("أدخل رابطًا يبدأ بـ https:// أو http://")
    try:
        import yt_dlp  # optional dependency, included in requirements.txt
    except ImportError as exc:
        raise RuntimeError("أداة قراءة الترجمات غير مثبتة. ثبّت المتطلبات من requirements.txt ثم أعد المحاولة.") from exc

    with tempfile.TemporaryDirectory(prefix="apexalpha_captions_") as temp_dir:
        opts = {
            "skip_download": True,
            "writesubtitles": True,
            "writeautomaticsub": True,
            "subtitleslangs": ["ar", "en", "fr", "ru", "ar.*", "en.*", "fr.*", "ru.*"],
            "subtitlesformat": "vtt/best",
            "outtmpl": str(Path(temp_dir) / "%(id)s.%(ext)s"),
            "quiet": True,
            "no_warnings": True,
            "noplaylist": True,
            "socket_timeout": 20,
            "retries": 1,
            "ignoreerrors": False,
        }
        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=True)
        except Exception as exc:
            raise RuntimeError(
                "تعذر جلب الترجمة تلقائيًا من هذا الرابط. قد يحتاج تسجيل دخول أو لا يوفّر ترجمات قابلة للوصول. "
                "يمكنك استيراد ملف SRT/VTT أو تفريغ الفيديو محليًا. التفاصيل: " + str(exc)[:300]
            ) from exc
        files = sorted(Path(temp_dir).glob("*.vtt")) + sorted(Path(temp_dir).glob("*.srt"))
        transcript_parts: list[str] = []
        for file_path in files:
            try:
                content = file_path.read_text(encoding="utf-8", errors="replace")
                cleaned = parse_subtitle_text(content)
                if cleaned and cleaned not in transcript_parts:
                    transcript_parts.append(cleaned)
            except OSError:
                continue
        transcript = "\n\n".join(transcript_parts).strip()
        title = str((info or {}).get("title") or "درس فيديو مستورد")
        if not transcript:
            raise RuntimeError(
                "تم فتح الرابط لكن لم أعثر على ترجمة متاحة باللغات العربية أو الإنجليزية أو الفرنسية أو الروسية. "
                "استورد ملف ترجمة أو استخدم زر تفريغ فيديو/صوت."
            )
        return transcript, title


def _extract_audio_if_needed(path: Path, temp_dir: str) -> Path:
    """Extract/compact audio as mono MP3 when video or an oversized audio file is selected."""
    is_video = path.suffix.lower() in VIDEO_EXTENSIONS
    try:
        too_large = path.stat().st_size > MAX_UPLOAD_BYTES
    except OSError:
        too_large = False
    if not is_video and not too_large:
        return path
    output = Path(temp_dir) / "apex_audio.mp3"
    try:
        completed = subprocess.run(
            ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(path),
             "-vn", "-ac", "1", "-ar", "16000", "-b:a", "64k", str(output)],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180, check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if completed.returncode == 0 and output.exists() and output.stat().st_size > 0:
            return output
    except (OSError, subprocess.TimeoutExpired):
        pass
    # The transcription endpoint also accepts MP4/WebM containers with an audio stream.
    return path


def transcribe_media_file(path: str, api_key: str, base_url: str = "https://api.openai.com/v1") -> str:
    """Transcribe local audio/video through the configured OpenAI-compatible endpoint.

    The media is transmitted only after the user explicitly chooses transcription. The
    application keeps the resulting transcript, not a duplicate of the uploaded media.
    """
    source = Path(path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError("لم يتم العثور على ملف الفيديو/الصوت المحدد.")
    if source.suffix.lower() not in AUDIO_EXTENSIONS | VIDEO_EXTENSIONS:
        raise ValueError("صيغة الملف غير مدعومة. استخدم MP3 أو M4A أو WAV أو MP4 أو WebM أو صيغة صوت معروفة.")
    if not api_key:
        raise ValueError("يلزم إعداد مفتاح API من الإعدادات لتفريغ الصوت إلى نص. قد تترتب تكلفة API.")
    base = str(base_url or "https://api.openai.com/v1").strip().rstrip("/")
    if not base.startswith("https://"):
        raise ValueError("عنوان API يجب أن يبدأ بـ https://")

    with tempfile.TemporaryDirectory(prefix="apexalpha_transcribe_") as temp_dir:
        media = _extract_audio_if_needed(source, temp_dir)
        size = media.stat().st_size
        if size > MAX_UPLOAD_BYTES:
            raise ValueError(
                "حجم الصوت بعد المعالجة أكبر من 25 MiB. قصّ الدرس إلى مقاطع أقصر أو خفّض معدل الصوت ثم أعد الاستيراد."
            )
        if media.suffix.lower() not in AUDIO_EXTENSIONS:
            raise ValueError("تعذر استخراج مسار صوت صالح. ثبّت FFmpeg أو استورد ملف صوت منفصلًا.")
        boundary = "----ApexAlphaBoundary8c4b39a8"
        fields = [("model", "gpt-4o-mini-transcribe"), ("response_format", "json")]
        body_parts: list[bytes] = []
        for name, value in fields:
            body_parts.append(
                f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"\r\n\r\n{value}\r\n".encode("utf-8")
            )
        data = media.read_bytes()
        filename = media.name.replace('"', "_")
        mime = "audio/mpeg" if media.suffix.lower() == ".mp3" else (
            "audio/mp4" if media.suffix.lower() in (".mp4", ".m4a", ".m4v") else
            "audio/wav" if media.suffix.lower() == ".wav" else "application/octet-stream"
        )
        body_parts.append(
            f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{filename}\"\r\n"
            f"Content-Type: {mime}\r\n\r\n".encode("utf-8") + data + b"\r\n"
        )
        body_parts.append(f"--{boundary}--\r\n".encode("utf-8"))
        body = b"".join(body_parts)
        request = Request(
            base + "/audio/transcriptions", data=body,
            headers={"Authorization": f"Bearer {api_key}",
                     "Content-Type": f"multipart/form-data; boundary={boundary}",
                     "Content-Length": str(len(body)), "User-Agent": "ApexAlpha/2.9.0"},
            method="POST",
        )
        try:
            with urlopen(request, timeout=180) as response:
                parsed = json.loads(response.read().decode("utf-8", errors="replace"))
        except HTTPError as exc:
            detail = exc.read(1600).decode("utf-8", errors="replace")
            raise RuntimeError(f"فشل تفريغ الصوت (HTTP {exc.code}): {detail}") from exc
        except URLError as exc:
            raise RuntimeError(f"تعذر الاتصال بخدمة تفريغ الصوت: {exc.reason}") from exc
        transcript = str(parsed.get("text", "") if isinstance(parsed, dict) else "").strip()
        if not transcript:
            raise RuntimeError("أعادت خدمة التفريغ نصًا فارغًا. قد يكون المقطع بلا كلام واضح.")
        return transcript
