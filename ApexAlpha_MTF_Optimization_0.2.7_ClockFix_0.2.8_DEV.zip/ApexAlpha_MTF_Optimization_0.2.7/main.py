import sys
from PySide6.QtWidgets import QApplication
from interface.dashboard import Dashboard

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("Apex Alpha Intelligence Core")
    window = Dashboard()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
