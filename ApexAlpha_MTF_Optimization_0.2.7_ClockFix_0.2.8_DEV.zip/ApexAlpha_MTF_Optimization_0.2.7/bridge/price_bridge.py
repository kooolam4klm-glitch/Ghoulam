"""Read-only local TCP receiver for the Apex Price Bridge MT5 Expert Advisor.

Only binds to 127.0.0.1; accepts one JSON object per newline and never sends
commands back to MT5. The MT5 Python API remains available as a fallback.
"""
from __future__ import annotations

import json
import socket
import threading
import time
from datetime import datetime
from types import SimpleNamespace
from typing import Callable, Optional


class PriceBridgeServer:
    def __init__(self, host: str = "127.0.0.1", port: int = 47831,
                 on_tick: Optional[Callable[[dict], None]] = None,
                 on_client_state: Optional[Callable[[bool], None]] = None):
        self.host = host
        self.port = int(port)
        self.on_tick = on_tick
        self.on_client_state = on_client_state
        self._server: Optional[socket.socket] = None
        self._thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self._latest: dict[str, dict] = {}
        self._clients = 0
        self.started = False
        self.error: Optional[str] = None

    def start(self) -> bool:
        if self.started:
            return True
        try:
            server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server.bind((self.host, self.port))
            server.listen(4)
            server.settimeout(0.5)
            self._server = server
            self._stop.clear()
            self._thread = threading.Thread(target=self._accept_loop,
                                           name="ApexPriceBridge", daemon=True)
            self._thread.start()
            self.started = True
            self.error = None
            return True
        except OSError as exc:
            self.error = f"تعذر تشغيل جسر الأسعار المحلي على {self.host}:{self.port}: {exc}"
            try:
                if self._server:
                    self._server.close()
            except OSError:
                pass
            self._server = None
            self.started = False
            return False

    @property
    def client_connected(self) -> bool:
        with self._lock:
            return self._clients > 0

    def _set_client_count(self, delta: int) -> None:
        with self._lock:
            prior = self._clients > 0
            self._clients = max(0, self._clients + delta)
            current = self._clients > 0
        if prior != current and self.on_client_state:
            try:
                self.on_client_state(current)
            except Exception:
                pass

    def _accept_loop(self) -> None:
        while not self._stop.is_set():
            server = self._server
            if server is None:
                break
            try:
                client, address = server.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            if address[0] not in ("127.0.0.1", "::1"):
                client.close()
                continue
            client.settimeout(1.0)
            thread = threading.Thread(target=self._client_loop,
                                      args=(client,), daemon=True)
            thread.start()

    def _client_loop(self, client: socket.socket) -> None:
        self._set_client_count(1)
        buffer = b""
        try:
            with client:
                while not self._stop.is_set():
                    try:
                        chunk = client.recv(4096)
                    except socket.timeout:
                        continue
                    if not chunk:
                        break
                    buffer += chunk
                    if len(buffer) > 65536:
                        buffer = b""  # discard malformed/oversized frame
                        continue
                    while b"\n" in buffer:
                        raw, buffer = buffer.split(b"\n", 1)
                        if not raw.strip():
                            continue
                        try:
                            msg = json.loads(raw.decode("utf-8"))
                            self._accept_message(msg)
                        except (UnicodeDecodeError, json.JSONDecodeError, TypeError, ValueError):
                            continue
        except OSError:
            pass
        finally:
            self._set_client_count(-1)

    def _accept_message(self, msg: dict) -> None:
        if not isinstance(msg, dict) or msg.get("type") != "tick":
            return
        symbol = str(msg.get("symbol", "")).strip()
        if not symbol or len(symbol) > 80:
            return
        try:
            bid = float(msg["bid"])
            ask = float(msg["ask"])
            time_msc = int(msg.get("time_msc", 0))
            tick_time = int(msg.get("time", time_msc // 1000))
            if not (0 < bid < 1e12 and 0 < ask < 1e12 and ask >= bid and time_msc > 0):
                return
            offset_raw = msg.get("server_utc_offset_seconds")
            broker_offset = int(offset_raw) if offset_raw is not None else None
            if broker_offset is not None and (abs(broker_offset) > 14 * 3600 or broker_offset % 60 != 0):
                return
            tick = SimpleNamespace(
                time=tick_time, time_msc=time_msc, bid=bid, ask=ask,
                broker_offset_seconds=broker_offset,
                server_time=int(msg.get("server_time", 0) or 0),
                gmt_time=int(msg.get("gmt_time", 0) or 0),
                last=float(msg.get("last", 0.0) or 0.0),
                volume=int(msg.get("volume", 0) or 0),
                flags=int(msg.get("flags", 0) or 0),
                volume_real=float(msg.get("volume_real", 0.0) or 0.0),
            )
        except (KeyError, TypeError, ValueError, OverflowError):
            return
        receipt_epoch = time.time()
        receipt_local = datetime.fromtimestamp(receipt_epoch).astimezone().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3] + " (محلي)"
        payload = {
            "symbol": symbol, "tick": tick, "received_epoch": receipt_epoch,
            "received_monotonic": time.monotonic(), "received_local_label": receipt_local,
            "source": "Apex Price Bridge (MT5 EA)",
            "broker_offset_seconds": broker_offset,
        }
        with self._lock:
            self._latest[symbol] = payload
        if self.on_tick:
            try:
                self.on_tick({
                    "symbol": symbol, "bid": bid, "ask": ask,
                    "time_msc": time_msc, "received_epoch": receipt_epoch,
                    "received_local_label": receipt_local,
                })
            except Exception:
                pass

    def get_latest(self, symbol: str, max_age_seconds: float = 5.0) -> Optional[dict]:
        with self._lock:
            payload = self._latest.get(str(symbol).strip())
            if payload is None:
                return None
            result = dict(payload)
        age = time.monotonic() - result["received_monotonic"]
        if age < 0 or age > max_age_seconds:
            return None
        result["receipt_age_seconds"] = age
        return result

    def stop(self) -> None:
        self._stop.set()
        if self._server is not None:
            try:
                self._server.close()
            except OSError:
                pass
        self._server = None
        self.started = False
