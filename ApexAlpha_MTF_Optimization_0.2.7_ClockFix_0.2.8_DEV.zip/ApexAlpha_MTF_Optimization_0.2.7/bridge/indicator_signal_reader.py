"""Read-only reader for Apex Alpha MT5 indicator snapshots written to Common/Files.

This module does not connect to the broker and cannot place or modify orders.
"""
from __future__ import annotations
import json
import time
from pathlib import Path
from typing import Any

ALLOWED_DIRECTIONS = {"BUY", "SELL", "WAIT"}

class IndicatorSnapshotError(ValueError):
    pass

def read_indicator_snapshot(path: str | Path, *, expected_symbol: str = "BTCUSD",
                             expected_timeframe: str | None = None,
                             max_age_seconds: int = 900,
                             now_epoch: float | None = None) -> dict[str, Any]:
    """Read and validate a JSON snapshot. `bar_time` is MT5 epoch seconds.

    max_age_seconds checks the signal candle time, not file modification time.
    The caller should compare this snapshot with the bot's own signal and prefer
    WAIT/manual review when they disagree.
    """
    p = Path(path)
    try:
        data = json.loads(p.read_text(encoding="utf-8-sig"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise IndicatorSnapshotError(f"Cannot read indicator snapshot: {exc}") from exc
    if not isinstance(data, dict) or data.get("schema") != 1:
        raise IndicatorSnapshotError("Unsupported or malformed snapshot schema")
    if data.get("source") != "ApexAlpha_MT5_Indicator":
        raise IndicatorSnapshotError("Unexpected snapshot source")
    if str(data.get("symbol", "")).upper() != expected_symbol.upper():
        raise IndicatorSnapshotError("Symbol mismatch; expected " + expected_symbol)
    tf = str(data.get("timeframe", ""))
    if expected_timeframe and tf.upper() != expected_timeframe.upper():
        raise IndicatorSnapshotError("Timeframe mismatch; expected " + expected_timeframe)
    if data.get("direction") not in ALLOWED_DIRECTIONS:
        raise IndicatorSnapshotError("Invalid direction")
    if data.get("trading_enabled") is not False:
        raise IndicatorSnapshotError("Snapshot must explicitly keep trading disabled")
    try:
        bar_time = int(data["bar_time"])
        score = int(data["score"])
        bid, ask = float(data["bid"]), float(data["ask"])
    except (KeyError, TypeError, ValueError, OverflowError) as exc:
        raise IndicatorSnapshotError("Missing or invalid timestamp/score/quote") from exc
    if bar_time <= 0 or not (0 <= score <= 100) or not (0 < bid <= ask):
        raise IndicatorSnapshotError("Invalid timestamp, score, or quote")
    now = time.time() if now_epoch is None else float(now_epoch)
    age = now - bar_time
    if age < -300 or age > max_age_seconds:
        raise IndicatorSnapshotError(f"Stale or future-dated snapshot ({age:.0f}s)")
    for key in ("atr", "entry", "stop_loss", "tp1", "tp2", "pivot_high", "pivot_low"):
        try:
            value = float(data.get(key, 0.0))
        except (TypeError, ValueError, OverflowError) as exc:
            raise IndicatorSnapshotError(f"Invalid numeric field: {key}") from exc
        if value < 0:
            raise IndicatorSnapshotError(f"Negative numeric field: {key}")
    data["age_seconds"] = max(0, int(age))
    data["read_only"] = True
    return data
