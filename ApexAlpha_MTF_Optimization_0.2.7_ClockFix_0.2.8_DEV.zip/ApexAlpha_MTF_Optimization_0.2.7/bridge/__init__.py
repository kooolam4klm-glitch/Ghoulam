"""Local MT5 quote bridge: read-only TCP receiver."""
