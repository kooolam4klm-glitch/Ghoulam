"""Read-only risk calculations for Apex Alpha.

These helpers calculate an informational position-size proposal only. They never
send orders to MT5, and the execution guard always fails closed.
"""
from __future__ import annotations
from math import isfinite, floor
from typing import Any


def _positive_number(value: Any, field: str) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{field} must be a number") from exc
    if not isfinite(number) or number <= 0:
        raise ValueError(f"{field} must be finite and greater than zero")
    return number


def calculate_position_size(*, balance: float, risk_percent: float,
                            entry: float, stop_loss: float,
                            tick_size: float, tick_value: float,
                            volume_min: float = 0.01,
                            volume_max: float = 100.0,
                            volume_step: float = 0.01) -> dict[str, Any]:
    """Estimate volume from account risk and instrument tick economics.

    ``tick_value`` must be the account-currency value of one tick for one lot,
    as supplied/verified for the broker's instrument. Fees, slippage, gaps and
    conversion changes are not included. If the rounded volume falls below the
    broker minimum, returns no usable volume instead of rounding risk upward.
    """
    balance = _positive_number(balance, "balance")
    entry = _positive_number(entry, "entry")
    stop_loss = _positive_number(stop_loss, "stop_loss")
    tick_size = _positive_number(tick_size, "tick_size")
    tick_value = _positive_number(tick_value, "tick_value")
    volume_min = _positive_number(volume_min, "volume_min")
    volume_max = _positive_number(volume_max, "volume_max")
    volume_step = _positive_number(volume_step, "volume_step")
    try:
        risk_percent = float(risk_percent)
    except (TypeError, ValueError) as exc:
        raise ValueError("risk_percent must be a number") from exc
    if not isfinite(risk_percent) or not 0 < risk_percent <= 5:
        raise ValueError("risk_percent must be greater than 0 and at most 5")
    if volume_max < volume_min:
        raise ValueError("volume_max must be greater than or equal to volume_min")
    if entry == stop_loss:
        raise ValueError("entry and stop_loss must differ")

    distance = abs(entry - stop_loss)
    ticks_at_risk = distance / tick_size
    risk_budget = balance * risk_percent / 100.0
    risk_per_lot = ticks_at_risk * tick_value
    if not isfinite(risk_per_lot) or risk_per_lot <= 0:
        raise ValueError("calculated risk per lot is invalid")
    raw_volume = risk_budget / risk_per_lot
    # Floor to step; never round up beyond the requested risk budget.
    volume = floor((raw_volume + 1e-12) / volume_step) * volume_step
    volume = min(volume, volume_max)
    volume = round(volume, 8)
    if volume < volume_min:
        return {
            "ok": False, "volume": None, "risk_budget": round(risk_budget, 8),
            "risk_per_lot": round(risk_per_lot, 8), "stop_distance": distance,
            "reason": "Risk budget is too small for the broker's minimum volume; no volume recommended.",
        }
    estimated_risk = volume * risk_per_lot
    return {
        "ok": True, "volume": volume, "risk_budget": round(risk_budget, 8),
        "estimated_risk": round(estimated_risk, 8),
        "risk_per_lot": round(risk_per_lot, 8), "stop_distance": distance,
        "risk_percent_actual": round(estimated_risk / balance * 100.0, 6),
        "reason": "Informational estimate only; verify broker tick economics, fees, slippage and contract rules.",
    }


def validate_trade_proposal(proposal):
    """Fail-closed guard: this application build has no order execution."""
    return {"ok": False, "reason": "Execution is disabled in this build. It is read-only/simulation-only."}
