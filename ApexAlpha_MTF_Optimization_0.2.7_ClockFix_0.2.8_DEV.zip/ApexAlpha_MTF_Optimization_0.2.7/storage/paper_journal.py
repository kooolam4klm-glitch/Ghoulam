"""Local-only shadow signal journal for evaluation; never sends broker orders."""
from __future__ import annotations

import math
import sqlite3
from datetime import datetime
from threading import Lock
from typing import Any

from storage.database import DB_PATH

STRATEGY_ID = "SMA10-30_RSI14_ATR14_V1"
_INITIALIZED_PATH = None
_INIT_LOCK = Lock()


def _connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH, timeout=5.0)
    con.row_factory = sqlite3.Row
    return con


def initialize_paper_journal():
    global _INITIALIZED_PATH
    path_key = str(DB_PATH.resolve())
    if _INITIALIZED_PATH == path_key and DB_PATH.exists():
        return
    with _INIT_LOCK:
        if _INITIALIZED_PATH == path_key and DB_PATH.exists():
            return
        with _connect() as con:
            con.execute(
                """CREATE TABLE IF NOT EXISTS shadow_signals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    signal_key TEXT NOT NULL UNIQUE,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    symbol TEXT NOT NULL,
                    timeframe TEXT NOT NULL,
                    direction TEXT NOT NULL CHECK(direction IN ('BUY','SELL')),
                    strategy_id TEXT NOT NULL,
                    signal_bar_time INTEGER NOT NULL,
                    entry REAL NOT NULL,
                    stop_loss REAL NOT NULL,
                    take_profit REAL NOT NULL,
                    initial_risk REAL NOT NULL,
                    status TEXT NOT NULL DEFAULT 'OPEN',
                    user_decision TEXT NOT NULL DEFAULT 'PENDING',
                    exit_price REAL,
                    exited_at TEXT,
                    r_multiple REAL,
                    max_favorable_r REAL NOT NULL DEFAULT 0,
                    max_adverse_r REAL NOT NULL DEFAULT 0,
                    last_tick_time_msc INTEGER NOT NULL DEFAULT 0,
                    source TEXT NOT NULL DEFAULT 'MT5'
                )""")
            con.execute("CREATE INDEX IF NOT EXISTS ix_shadow_open_symbol ON shadow_signals(status, symbol)")
        _INITIALIZED_PATH = path_key


def record_shadow_signal(signal: dict[str, Any], symbol: str, timeframe: str,
                         bar_time: int | None, entry_tick_time_msc: int = 0,
                         source: str = "MT5") -> dict[str, Any] | None:
    """Persist one candidate per closed bar/direction; return id and whether new."""
    initialize_paper_journal()
    direction = str(signal.get("direction", "")).upper()
    entry = signal.get("entry")
    stop = signal.get("stop_loss")
    target = signal.get("take_profit")
    if direction not in {"BUY", "SELL"} or bar_time is None:
        return None
    try:
        entry, stop, target = float(entry), float(stop), float(target)
        risk = abs(entry - stop)
        if not all(math.isfinite(v) and v > 0 for v in (entry, stop, target, risk)):
            return None
        if (direction == "BUY" and not stop < entry < target) or (
                direction == "SELL" and not target < entry < stop):
            return None
    except (TypeError, ValueError):
        return None

    symbol = str(symbol).strip()
    timeframe = str(timeframe).strip().upper()
    strategy_id = str(signal.get("strategy_id") or STRATEGY_ID)
    key = f"{symbol.casefold()}|{timeframe}|{int(bar_time)}|{direction}|{strategy_id}"
    with _connect() as con:
        cur = con.execute(
            """INSERT OR IGNORE INTO shadow_signals
               (signal_key, symbol, timeframe, direction, strategy_id, signal_bar_time,
                entry, stop_loss, take_profit, initial_risk, last_tick_time_msc, source)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (key, symbol, timeframe, direction, strategy_id, int(bar_time), entry, stop,
             target, risk, max(0, int(entry_tick_time_msc or 0)), str(source)[:80]))
        created = cur.rowcount == 1
        row = con.execute(
            "SELECT id, user_decision, status FROM shadow_signals WHERE signal_key = ?", (key,)
        ).fetchone()
        return {"id": int(row["id"]), "created": created,
                "user_decision": str(row["user_decision"]), "status": str(row["status"]),
                "signal_key": key}


def set_user_decision(signal_id: int, decision: str) -> bool:
    decision = str(decision).upper()
    if decision not in {"APPROVED", "REJECTED"}:
        raise ValueError("decision must be APPROVED or REJECTED")
    initialize_paper_journal()
    with _connect() as con:
        cur = con.execute(
            "UPDATE shadow_signals SET user_decision=? WHERE id=? AND user_decision='PENDING'",
            (decision, int(signal_id)))
        return cur.rowcount == 1


def update_open_signals(symbol: str, bid: float, ask: float,
                        tick_time_msc: int | None = None) -> list[dict[str, Any]]:
    """Track shadow outcomes from quotes. Uses Bid to exit BUY and Ask to exit SELL."""
    initialize_paper_journal()
    try:
        bid, ask = float(bid), float(ask)
        if not (math.isfinite(bid) and math.isfinite(ask) and 0 < bid <= ask):
            return []
        tick_msc = max(0, int(tick_time_msc or 0))
    except (TypeError, ValueError, OverflowError):
        return []

    closed: list[dict[str, Any]] = []
    now_label = datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S (local)")
    with _connect() as con:
        rows = con.execute(
            "SELECT * FROM shadow_signals WHERE status='OPEN' AND lower(symbol)=lower(?)",
            (str(symbol).strip(),)).fetchall()
        for row in rows:
            last_msc = int(row["last_tick_time_msc"] or 0)
            if tick_msc and tick_msc <= last_msc:
                continue
            direction = str(row["direction"])
            entry = float(row["entry"])
            stop = float(row["stop_loss"])
            target = float(row["take_profit"])
            risk = float(row["initial_risk"])
            exit_quote = bid if direction == "BUY" else ask

            if direction == "BUY":
                favorable = (bid - entry) / risk
                adverse = (entry - bid) / risk
                if bid <= stop:
                    status = "SL_HIT"
                elif bid >= target:
                    status = "TP_HIT"
                else:
                    status = "OPEN"
                signed_r = (exit_quote - entry) / risk
            else:
                favorable = (entry - ask) / risk
                adverse = (ask - entry) / risk
                if ask >= stop:
                    status = "SL_HIT"
                elif ask <= target:
                    status = "TP_HIT"
                else:
                    status = "OPEN"
                signed_r = (entry - exit_quote) / risk

            max_favorable = max(float(row["max_favorable_r"]), favorable)
            max_adverse = max(float(row["max_adverse_r"]), adverse)
            new_tick_msc = tick_msc or last_msc
            if status == "OPEN":
                con.execute(
                    """UPDATE shadow_signals SET max_favorable_r=?, max_adverse_r=?,
                       last_tick_time_msc=? WHERE id=?""",
                    (max_favorable, max_adverse, new_tick_msc, int(row["id"])))
            else:
                con.execute(
                    """UPDATE shadow_signals SET status=?, exit_price=?, exited_at=?, r_multiple=?,
                       max_favorable_r=?, max_adverse_r=?, last_tick_time_msc=? WHERE id=? AND status='OPEN'""",
                    (status, exit_quote, now_label, signed_r, max_favorable, max_adverse,
                     new_tick_msc, int(row["id"])))
                closed.append({"id": int(row["id"]), "symbol": str(row["symbol"]),
                               "timeframe": str(row["timeframe"]), "direction": direction,
                               "status": status, "exit_price": exit_quote,
                               "r_multiple": signed_r})
    return closed


def recent_signals(limit: int = 200) -> list[dict[str, Any]]:
    initialize_paper_journal()
    with _connect() as con:
        rows = con.execute(
            """SELECT id, created_at, symbol, timeframe, direction, entry, stop_loss,
                      take_profit, status, user_decision, exit_price, exited_at, r_multiple,
                      max_favorable_r, max_adverse_r, source
               FROM shadow_signals ORDER BY id DESC LIMIT ?""", (max(1, min(5000, int(limit))),)
        ).fetchall()
        return [dict(row) for row in rows]


def signal_summary() -> dict[str, Any]:
    initialize_paper_journal()
    with _connect() as con:
        row = con.execute(
            """SELECT COUNT(*) total,
                      SUM(CASE WHEN status='OPEN' THEN 1 ELSE 0 END) open_count,
                      SUM(CASE WHEN status='TP_HIT' THEN 1 ELSE 0 END) wins,
                      SUM(CASE WHEN status='SL_HIT' THEN 1 ELSE 0 END) losses,
                      AVG(CASE WHEN status IN ('TP_HIT','SL_HIT') THEN r_multiple END) avg_r
               FROM shadow_signals"""
        ).fetchone()
    total = int(row["total"] or 0)
    open_count = int(row["open_count"] or 0)
    wins = int(row["wins"] or 0)
    losses = int(row["losses"] or 0)
    resolved = wins + losses
    return {"total": total, "open": open_count, "wins": wins, "losses": losses,
            "resolved": resolved, "win_rate": (wins / resolved * 100.0) if resolved else None,
            "avg_r": float(row["avg_r"]) if row["avg_r"] is not None else None}
