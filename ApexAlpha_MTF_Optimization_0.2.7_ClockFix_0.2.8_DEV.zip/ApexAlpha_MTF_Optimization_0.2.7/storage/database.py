import sqlite3
from pathlib import Path

DB_PATH = Path.home() / "ApexAlpha" / "aaic_events.sqlite3"

def initialize_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DB_PATH) as con:
        con.execute("""CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            event TEXT NOT NULL,
            details TEXT
        )""")

def record_event(event, details):
    initialize_db()
    with sqlite3.connect(DB_PATH) as con:
        con.execute("INSERT INTO events(event, details) VALUES (?, ?)", (str(event), str(details)))

def recent_events(limit=200):
    initialize_db()
    with sqlite3.connect(DB_PATH) as con:
        con.row_factory = sqlite3.Row
        rows = con.execute("SELECT created_at, event, details FROM events ORDER BY id DESC LIMIT ?", (int(limit),)).fetchall()
    return [dict(row) for row in reversed(rows)]
