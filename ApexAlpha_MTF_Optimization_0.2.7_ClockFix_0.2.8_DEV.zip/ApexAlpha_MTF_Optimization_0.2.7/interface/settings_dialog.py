from __future__ import annotations
import threading
from PySide6.QtCore import QObject, Signal, Qt
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QTabWidget, QWidget, QFormLayout, QLabel,
    QComboBox, QCheckBox, QLineEdit, QPushButton, QGroupBox, QMessageBox, QApplication, QDoubleSpinBox
)
from config.app_settings import load_settings, save_settings
from services.secure_store import save_api_key, get_api_key, clear_api_key
from services.openai_client import test_connection
from services.i18n import translate_widget_tree
from services.voice_notifier import VoiceNotifier
from services.voice_language import resolve_voice_language

_LABELS = {
    "ar": {"title":"إعدادات Apex Alpha", "general":"عام", "ai":"الذكاء الاصطناعي وAPI", "voice":"الصوت والتنبيهات", "language":"لغة الواجهة", "theme":"المظهر", "provider":"مزوّد الذكاء الاصطناعي", "model":"اسم النموذج", "base":"عنوان API الأساسي", "key":"مفتاح API (مخفي)", "key_hint":"اتركه فارغًا للاحتفاظ بالمفتاح المحفوظ", "enabled":"تفعيل مساعد الذكاء الاصطناعي", "auto":"تحليل الإشارات تلقائيًا عبر API (قد يستهلك رصيدًا)", "voice_enabled":"تفعيل الكلام والتنبيهات الصوتية", "signal_voice":"إعلان الإشارات الجديدة صوتيًا", "position_voice":"الإعلان عند فتح/إغلاق مركز فعلي", "reply_voice":"قراءة ردود المساعد بصوت", "voice_language":"لغة المساعد الصوتي", "voice_auto":"تلقائي حسب لغة الرد/الواجهة", "test_voice":"اختبار الصوت", "test":"اختبار الاتصال", "save":"حفظ الإعدادات", "cancel":"إلغاء", "clear":"حذف المفتاح المحفوظ", "note":"المفتاح لا يُحفظ كنص واضح. التخزين الدائم المشفر متاح عبر Windows DPAPI.", "theme_dark":"داكن", "theme_light":"فاتح", "theme_system":"مطابقة Windows", "status_saved":"تم حفظ الإعدادات المحلية."},
    "en": {"title":"Apex Alpha Settings", "general":"General", "ai":"AI & API", "voice":"Voice & Alerts", "language":"Interface language", "theme":"Appearance", "provider":"AI provider", "model":"Model name", "base":"API base URL", "key":"API key (hidden)", "key_hint":"Leave blank to keep the saved key", "enabled":"Enable AI assistant", "auto":"Auto-analyse new signals via API (may incur usage costs)", "voice_enabled":"Enable speech and voice alerts", "signal_voice":"Speak new signal alerts", "position_voice":"Announce real position open/close", "reply_voice":"Speak assistant responses", "voice_language":"Assistant voice language", "voice_auto":"Auto from reply/interface language", "test_voice":"Test voice", "test":"Test connection", "save":"Save settings", "cancel":"Cancel", "clear":"Delete saved key", "note":"The key is not stored as plain text. Persistent encryption uses Windows DPAPI.", "theme_dark":"Dark", "theme_light":"Light", "theme_system":"Match Windows", "status_saved":"Local settings saved."},
    "fr": {"title":"Paramètres Apex Alpha", "general":"Général", "ai":"IA et API", "voice":"Voix et alertes", "language":"Langue de l’interface", "theme":"Apparence", "provider":"Fournisseur IA", "model":"Nom du modèle", "base":"URL de base API", "key":"Clé API (masquée)", "key_hint":"Laisser vide pour conserver la clé enregistrée", "enabled":"Activer l’assistant IA", "auto":"Analyser automatiquement les signaux via l’API (coût possible)", "voice_enabled":"Activer la synthèse vocale et les alertes", "signal_voice":"Annoncer les nouveaux signaux", "position_voice":"Annoncer l’ouverture/la fermeture d’une position réelle", "reply_voice":"Lire les réponses de l’assistant", "voice_language":"Langue vocale de l’assistant", "voice_auto":"Automatique selon la réponse/interface", "test_voice":"Tester la voix", "test":"Tester la connexion", "save":"Enregistrer les paramètres", "cancel":"Annuler", "clear":"Supprimer la clé enregistrée", "note":"La clé n’est pas enregistrée en clair. Le chiffrement persistant utilise Windows DPAPI.", "theme_dark":"Sombre", "theme_light":"Clair", "theme_system":"Suivre Windows", "status_saved":"Paramètres locaux enregistrés."},
    "ru": {"title":"Настройки Apex Alpha", "general":"Общие", "ai":"ИИ и API", "voice":"Голос и оповещения", "language":"Язык интерфейса", "theme":"Оформление", "provider":"Поставщик ИИ", "model":"Название модели", "base":"Базовый URL API", "key":"Ключ API (скрыт)", "key_hint":"Оставьте пустым, чтобы сохранить текущий ключ", "enabled":"Включить ИИ-помощника", "auto":"Автоматически анализировать сигналы через API (возможна оплата)", "voice_enabled":"Включить речь и голосовые оповещения", "signal_voice":"Озвучивать новые сигналы", "position_voice":"Сообщать об открытии/закрытии реальной позиции", "reply_voice":"Озвучивать ответы помощника", "voice_language":"Язык голоса помощника", "voice_auto":"Авто по языку ответа/интерфейса", "test_voice":"Проверить голос", "test":"Проверить соединение", "save":"Сохранить настройки", "cancel":"Отмена", "clear":"Удалить сохранённый ключ", "note":"Ключ не хранится в открытом виде. Для постоянного шифрования используется Windows DPAPI.", "theme_dark":"Тёмная", "theme_light":"Светлая", "theme_system":"Как в Windows", "status_saved":"Локальные настройки сохранены."},
}

class _TestSignals(QObject):
    finished = Signal(bool, str)

class SettingsDialog(QDialog):
    settings_saved = Signal(dict)
    def __init__(self, parent=None):
        super().__init__(parent)
        self.settings = load_settings()
        self.setMinimumSize(580, 540)
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMinimizeButtonHint |
                            Qt.WindowType.WindowMaximizeButtonHint | Qt.WindowType.WindowSystemMenuHint)
        self.setSizeGripEnabled(True)
        self.setWindowTitle("إعدادات Apex Alpha")
        root = QVBoxLayout(self)
        self.tabs = QTabWidget(); root.addWidget(self.tabs, 1)

        general = QWidget(); gf = QFormLayout(general)
        self.language = QComboBox()
        for code, name in (("ar","العربية"),("en","English"),("fr","Français"),("ru","Русский")):
            self.language.addItem(name, code)
        self.language.setCurrentIndex(max(0, self.language.findData(self.settings.get("language", "ar"))))
        self.theme = QComboBox(); self.theme.addItem("داكن", "dark"); self.theme.addItem("فاتح", "light"); self.theme.addItem("مطابقة Windows", "system")
        self.theme.setCurrentIndex(max(0, self.theme.findData(self.settings.get("theme", "dark"))))
        gf.addRow("لغة الواجهة:", self.language); gf.addRow("المظهر:", self.theme)
        self.ai_enabled = QCheckBox("تفعيل مساعد الذكاء الاصطناعي")
        self.ai_enabled.setChecked(bool(self.settings.get("ai_enabled", True)))
        self.ai_auto = QCheckBox("تحليل الإشارات الجديدة تلقائيًا عبر API (قد يستهلك رصيدًا)")
        self.ai_auto.setChecked(bool(self.settings.get("ai_auto_analyze_signals", False)))
        gf.addRow(self.ai_enabled); gf.addRow(self.ai_auto)
        self.risk_percent = QDoubleSpinBox()
        self.risk_percent.setRange(0.1, 5.0); self.risk_percent.setSingleStep(0.1); self.risk_percent.setDecimals(1)
        self.risk_percent.setSuffix(" %")
        self.risk_percent.setValue(float(self.settings.get("risk_percent", 1.0)))
        gf.addRow("مخاطرة تقديرية لكل توصية (محاكاة فقط):", self.risk_percent)
        self.tabs.addTab(general, "عام")

        ai = QWidget(); af = QFormLayout(ai)
        self.provider = QComboBox(); self.provider.addItems(["OpenAI", "Anthropic", "Google AI", "Local model"])
        self.provider.setCurrentText(self.settings.get("ai_provider", "OpenAI"))
        self.model = QComboBox(); self.model.setEditable(True)
        self.model.addItems(["gpt-4o-mini", "gpt-4.1-mini", "gpt-4.1", "gpt-4o"])
        self.model.setCurrentText(self.settings.get("ai_model", "gpt-4o-mini"))
        self.base_url = QLineEdit(self.settings.get("ai_base_url", "https://api.openai.com/v1"))
        self.api_key = QLineEdit(); self.api_key.setEchoMode(QLineEdit.EchoMode.Password)
        self.api_key.setPlaceholderText("•••••••• (مفتاح محفوظ) — أدخل مفتاحًا جديدًا للتغيير" if get_api_key() else "أدخل مفتاح API؛ لن يظهر أثناء الكتابة")
        self.api_note = QLabel("المفتاح لا يُحفظ كنص واضح. التخزين الدائم المشفّر متاح عبر Windows DPAPI.")
        self.api_note.setWordWrap(True)
        self.connection_status = QLabel("الاتصال لم يُختبر بعد.")
        self.test_btn = QPushButton("اختبار الاتصال")
        self.clear_key_btn = QPushButton("حذف المفتاح المحفوظ")
        af.addRow("مزوّد الذكاء الاصطناعي:", self.provider); af.addRow("اسم النموذج:", self.model)
        af.addRow("عنوان API الأساسي:", self.base_url); af.addRow("مفتاح API:", self.api_key)
        af.addRow(self.api_note); af.addRow(self.test_btn, self.clear_key_btn); af.addRow(self.connection_status)
        self.tabs.addTab(ai, "الذكاء الاصطناعي وAPI")

        voice = QWidget(); vf = QFormLayout(voice)
        self.voice_enabled = QCheckBox("تفعيل الكلام والتنبيهات الصوتية")
        self.voice_enabled.setChecked(bool(self.settings.get("voice_enabled", True)))
        self.signal_voice = QCheckBox("إعلان الإشارات الجديدة صوتيًا")
        self.signal_voice.setChecked(bool(self.settings.get("announce_signals", True)))
        self.position_voice = QCheckBox("الإعلان عند فتح/إغلاق مركز فعلي")
        self.position_voice.setChecked(bool(self.settings.get("announce_positions", True)))
        self.reply_voice = QCheckBox("قراءة ردود المساعد بصوت")
        self.reply_voice.setChecked(bool(self.settings.get("voice_responses", True)))
        self.connection_voice = QCheckBox("الإعلان صوتيًا عند انقطاع الاتصال")
        self.connection_voice.setChecked(bool(self.settings.get("announce_connection", False)))
        self.voice_language = QComboBox()
        for code, name in (("auto", "تلقائي حسب لغة الرد/الواجهة"), ("ar", "العربية"), ("en", "English"), ("fr", "Français"), ("ru", "Русский")):
            self.voice_language.addItem(name, code)
        self.voice_language.setCurrentIndex(max(0, self.voice_language.findData(self.settings.get("voice_language", "auto"))))
        self.test_voice_btn = QPushButton("اختبار الصوت")
        self.voice_test_status = QLabel("تأكد من تثبيت صوت Windows للغة المختارة.")
        self.voice_test_status.setWordWrap(True)
        for checkbox in (self.voice_enabled, self.signal_voice, self.position_voice, self.reply_voice, self.connection_voice):
            vf.addRow(checkbox)
        vf.addRow("لغة المساعد الصوتي:", self.voice_language)
        vf.addRow(self.test_voice_btn, self.voice_test_status)
        self.tabs.addTab(voice, "الصوت والتنبيهات")

        bottom = QHBoxLayout(); bottom.addStretch()
        self.save_btn = QPushButton("حفظ الإعدادات"); self.cancel_btn = QPushButton("إلغاء")
        bottom.addWidget(self.save_btn); bottom.addWidget(self.cancel_btn); root.addLayout(bottom)
        self.save_btn.clicked.connect(self.save)
        self.cancel_btn.clicked.connect(self.reject)
        self.test_btn.clicked.connect(self.test_api)
        self.test_voice_btn.clicked.connect(self.test_voice)
        self.clear_key_btn.clicked.connect(self.clear_api)
        self._test_signals = _TestSignals(self)
        self._test_signals.finished.connect(self._test_finished)
        self.language.currentIndexChanged.connect(self.retranslate)
        self.retranslate()

    def retranslate(self, *_args):
        language = self.language.currentData() or "ar"
        translate_widget_tree(self, language)
        self.setWindowTitle(_LABELS.get(language, _LABELS["ar"])["title"])
        labels = _LABELS.get(language, _LABELS["ar"])
        self.tabs.setTabText(0, labels["general"])
        self.tabs.setTabText(1, labels["ai"])
        self.tabs.setTabText(2, labels["voice"])
        self.save_btn.setText(labels["save"])
        self.cancel_btn.setText(labels["cancel"])
        self.test_btn.setText(labels["test"])
        self.clear_key_btn.setText(labels["clear"])
        self.test_voice_btn.setText(labels["test_voice"])
        self.voice_test_status.setText("تأكد من تثبيت صوت Windows للغة المختارة." if language == "ar" else ("Make sure a Windows voice for the selected language is installed." if language == "en" else ("Vérifiez qu’une voix Windows est installée pour cette langue." if language == "fr" else "Убедитесь, что голос Windows для выбранного языка установлен.")))
        auto_voice_label = labels["voice_auto"]
        auto_index = self.voice_language.findData("auto")
        if auto_index >= 0:
            self.voice_language.setItemText(auto_index, auto_voice_label)

    def save(self):
        updated = {
            "language": self.language.currentData(), "theme": self.theme.currentData(),
            "risk_percent": self.risk_percent.value(),
            "ai_enabled": self.ai_enabled.isChecked(), "ai_auto_analyze_signals": self.ai_auto.isChecked(),
            "ai_provider": self.provider.currentText(), "ai_model": self.model.currentText().strip() or "gpt-4o-mini",
            "ai_base_url": self.base_url.text().strip() or "https://api.openai.com/v1",
            "voice_enabled": self.voice_enabled.isChecked(), "voice_language": self.voice_language.currentData(),
            "announce_signals": self.signal_voice.isChecked(),
            "announce_positions": self.position_voice.isChecked(), "voice_responses": self.reply_voice.isChecked(),
            "announce_connection": self.connection_voice.isChecked(),
        }
        try:
            persisted = save_settings(updated)
            message = ""
            if self.api_key.text().strip():
                ok, message = save_api_key(self.api_key.text().strip())
                if not ok:
                    QMessageBox.warning(self, "حفظ المفتاح", message)
            self.api_key.clear()
            self.settings = persisted
            self.settings_saved.emit(dict(persisted))
            self.accept()
        except Exception as exc:
            QMessageBox.critical(self, "خطأ حفظ الإعدادات", str(exc))


    def test_voice(self):
        language = self.voice_language.currentData() or "auto"
        interface_language = self.language.currentData() or "ar"
        samples = {
            "ar": "هذا اختبار صوت المساعد Apex Alpha. لم يتم تنفيذ أي صفقة.",
            "en": "This is an Apex Alpha voice test. No trade has been executed.",
            "fr": "Ceci est un test vocal d’Apex Alpha. Aucune transaction n’a été exécutée.",
            "ru": "Это проверка голоса Apex Alpha. Сделки не выполнялись.",
        }
        sample_language = language if language in samples else interface_language
        sample_text = samples.get(sample_language, samples["ar"])
        resolved = resolve_voice_language(language, sample_text, interface_language)
        accepted = VoiceNotifier().speak(samples.get(resolved, samples["ar"]), resolved, self.voice_enabled.isChecked())
        if not self.voice_enabled.isChecked():
            self.voice_test_status.setText("فعّل الكلام والتنبيهات الصوتية أولًا.")
        elif accepted:
            self.voice_test_status.setText(f"تم إرسال اختبار الصوت باللغة: {resolved}. إذا لم تسمع صوتًا، تحقق من أصوات Windows المثبتة.")
        else:
            self.voice_test_status.setText("تعذر بدء اختبار الصوت.")

    def clear_api(self):
        answer = QMessageBox.question(self, "حذف مفتاح API", "هل تريد حذف مفتاح API المحفوظ؟")
        if answer == QMessageBox.StandardButton.Yes:
            clear_api_key(); self.api_key.clear()
            self.api_key.setPlaceholderText("لا يوجد مفتاح محفوظ")
            self.connection_status.setText("تم حذف المفتاح المحفوظ.")

    def test_api(self):
        if self.provider.currentText() != "OpenAI":
            self.connection_status.setText("هذا الإصدار يختبر OpenAI فقط؛ موفّرات أخرى تحتاج موائمات منفصلة.")
            return
        from services.secure_store import get_api_key
        key = self.api_key.text().strip() or get_api_key()
        if not key:
            self.connection_status.setText("أدخل مفتاح API أولًا.")
            return
        self.test_btn.setEnabled(False); self.connection_status.setText("جارٍ اختبار الاتصال…")
        model, base = self.model.currentText().strip(), self.base_url.text().strip()
        def worker():
            try:
                text = test_connection(key, model, base)
                self._test_signals.finished.emit(True, "نجح الاتصال بـ OpenAI API: " + text[:180])
            except Exception as exc:
                self._test_signals.finished.emit(False, str(exc)[:500])
        threading.Thread(target=worker, daemon=True, name="ApexAPITest").start()

    def _test_finished(self, ok, message):
        self.test_btn.setEnabled(True)
        self.connection_status.setText(message)
        self.connection_status.setStyleSheet("color: #45b881;" if ok else "color: #f87171;")
