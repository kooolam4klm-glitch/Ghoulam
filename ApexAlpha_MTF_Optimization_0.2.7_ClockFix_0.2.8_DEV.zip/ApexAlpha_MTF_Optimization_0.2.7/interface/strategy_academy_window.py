"""Apex Alpha Strategy Academy window.

Phase 1 supports URL caption import where available, local subtitle/text import, local
media transcription through the configured API, structured strategy extraction, and a
persistent local library. It does not directly affect the live recommendation engine.
"""
from __future__ import annotations

import json
from pathlib import Path

from PySide6.QtCore import QThread, Signal, Qt
from PySide6.QtWidgets import (
    QDialog, QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QPushButton,
    QLineEdit, QPlainTextEdit, QListWidget, QListWidgetItem, QMessageBox, QFileDialog,
    QSplitter, QGroupBox, QSizePolicy,
)

from academy.ingestion import fetch_available_captions, transcribe_media_file
from academy.strategy_analyzer import analyze_transcript
from academy.strategy_library import (
    delete_lesson, get_lesson, list_lessons, parse_subtitle_text, save_analysis, save_lesson,
)
from config.app_settings import load_settings
from services.secure_store import get_api_key


STATUS_LABELS = {
    "needs_transcript": "ينتظر النص",
    "draft": "مسودة",
    "draft_untested": "استراتيجية غير مختبرة",
}

FIELD_LABELS = {
    "strategy_name": "اسم الاستراتيجية",
    "summary": "ملخص الدرس",
    "markets": "الأسواق / الأدوات",
    "timeframes": "الأطر الزمنية",
    "indicators": "المؤشرات والأدوات",
    "buy_rules": "قواعد الشراء BUY",
    "sell_rules": "قواعد البيع SELL",
    "entry_rules": "شروط الدخول والتأكيد",
    "stop_loss_rules": "قواعد وقف الخسارة",
    "take_profit_rules": "قواعد جني الأرباح والخروج",
    "risk_rules": "إدارة المخاطر",
    "no_trade_conditions": "متى لا نتداول؟",
    "examples_from_source": "أمثلة من المصدر",
    "ambiguities_and_missing_rules": "النقاط الغامضة والناقصة",
    "test_plan": "خطة الاختبار المقترحة",
    "warnings": "تحذيرات وحدود",
}


class AcademyWorker(QThread):
    succeeded = Signal(str, object)
    failed = Signal(str, str)

    def __init__(self, task: str, payload: dict, parent=None):
        super().__init__(parent)
        self.task = task
        self.payload = dict(payload)

    def run(self):
        try:
            if self.task == "captions":
                transcript, title = fetch_available_captions(self.payload["url"])
                self.succeeded.emit(self.task, {"transcript": transcript, "title": title})
            elif self.task == "transcribe":
                transcript = transcribe_media_file(
                    self.payload["path"], self.payload["api_key"], self.payload["base_url"]
                )
                self.succeeded.emit(self.task, {"transcript": transcript, "path": self.payload["path"]})
            elif self.task == "analyze":
                rendered, strategy = analyze_transcript(
                    self.payload["transcript"], self.payload["api_key"],
                    self.payload["model"], self.payload["base_url"],
                )
                self.succeeded.emit(self.task, {
                    "lesson_id": int(self.payload["lesson_id"]),
                    "rendered": rendered,
                    "strategy": strategy,
                    "model": self.payload["model"],
                })
            else:
                raise ValueError("نوع مهمة غير معروف")
        except Exception as exc:
            self.failed.emit(self.task, str(exc))


def _format_analysis(text: str) -> str:
    text = str(text or "").strip()
    if not text:
        return "لم يُحلل الدرس بعد."
    try:
        obj = json.loads(text)
    except json.JSONDecodeError:
        return text
    if not isinstance(obj, dict):
        return text
    if "raw_analysis" in obj:
        return str(obj.get("raw_analysis") or text)
    lines = []
    for key, label in FIELD_LABELS.items():
        value = obj.get(key)
        if value in (None, "", [], {}):
            continue
        lines.append(label + ":")
        if isinstance(value, list):
            lines.extend("  • " + str(item) for item in value)
        elif isinstance(value, dict):
            lines.append(json.dumps(value, ensure_ascii=False, indent=2))
        else:
            lines.append(str(value))
        lines.append("")
    return "\n".join(lines).strip() or text


class StrategyAcademyWindow(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Apex Alpha — أكاديمية الاستراتيجيات")
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMinimizeButtonHint |
                            Qt.WindowType.WindowMaximizeButtonHint | Qt.WindowType.WindowSystemMenuHint)
        self.setWindowModality(Qt.WindowModality.NonModal)
        self.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        self.resize(1120, 790)
        self.setMinimumSize(900, 640)
        self.current_lesson_id: int | None = None
        self._source_type_hint = "text"
        self._source_uri_hint = ""
        self.worker: AcademyWorker | None = None
        self._working_task = ""

        root = QVBoxLayout(self)
        root.setContentsMargins(14, 12, 14, 12)
        root.setSpacing(10)

        header = QHBoxLayout()
        title = QLabel("أكاديمية الاستراتيجيات")
        title.setStyleSheet("font-size: 21px; font-weight: 800; color: #a78bfa; padding: 3px;")
        self.state_label = QLabel("ذاكرة محلية • لا تؤثر الاستراتيجيات في التوصيات حتى تُختبر وتُدمج صراحةً")
        self.state_label.setWordWrap(True)
        self.state_label.setStyleSheet("color: #d99b48; padding: 5px;")
        header.addWidget(title)
        header.addStretch(1)
        header.addWidget(self.state_label, 2)
        root.addLayout(header)

        note = QLabel(
            "استورد رابطًا يحوي ترجمة متاحة، أو ملف SRT/VTT/نص، أو ملف صوت/فيديو. "
            "قد يتطلب التفريغ والتحليل اتصالًا بالإنترنت ويستهلك رصيد API. لا يتم حفظ نسخة من ملف الوسائط نفسه."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: #b8c9e8; padding: 7px; background: #101a2b; border: 1px solid #283750; border-radius: 7px;")
        root.addWidget(note)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setChildrenCollapsible(False)
        root.addWidget(splitter, 1)

        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.setContentsMargins(0, 0, 4, 0)
        search_box = QLineEdit()
        self.search_input = search_box
        search_box.setPlaceholderText("بحث في الدروس والاستراتيجيات...")
        search_box.textChanged.connect(self.refresh_list)
        left_layout.addWidget(search_box)
        self.lessons_list = QListWidget()
        self.lessons_list.currentItemChanged.connect(self.on_lesson_selected)
        left_layout.addWidget(self.lessons_list, 1)
        left_actions = QHBoxLayout()
        self.new_button = QPushButton("درس جديد")
        self.delete_button = QPushButton("حذف")
        self.new_button.clicked.connect(self.new_lesson)
        self.delete_button.clicked.connect(self.remove_lesson)
        left_actions.addWidget(self.new_button)
        left_actions.addWidget(self.delete_button)
        left_layout.addLayout(left_actions)
        splitter.addWidget(left)

        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(4, 0, 0, 0)
        form_box = QGroupBox("مصدر الدرس")
        form = QFormLayout(form_box)
        self.title_input = QLineEdit()
        self.title_input.setPlaceholderText("مثال: استراتيجية كسر القمم وإعادة الاختبار")
        self.url_input = QLineEdit()
        self.url_input.setPlaceholderText("رابط YouTube أو TikTok أو Facebook (اختياري)")
        self.source_info = QLabel("المصدر: نص مباشر")
        self.source_info.setWordWrap(True)
        form.addRow("عنوان الدرس:", self.title_input)
        form.addRow("رابط الفيديو:", self.url_input)
        form.addRow("نوع المصدر:", self.source_info)
        right_layout.addWidget(form_box)

        transcript_box = QGroupBox("النص المستخرج / الترجمة")
        transcript_layout = QVBoxLayout(transcript_box)
        self.transcript_editor = QPlainTextEdit()
        self.transcript_editor.setPlaceholderText(
            "ألصق نص الشرح هنا، أو استورد ملف ترجمة، أو اجلب الترجمة المتاحة من رابط، أو فرّغ ملف صوت/فيديو."
        )
        self.transcript_editor.setMinimumHeight(130)
        transcript_layout.addWidget(self.transcript_editor)
        right_layout.addWidget(transcript_box, 2)

        import_controls = QHBoxLayout()
        action_controls = QHBoxLayout()
        self.import_text_btn = QPushButton("استيراد نص / ترجمة")
        self.fetch_caption_btn = QPushButton("جلب ترجمة الرابط")
        self.transcribe_btn = QPushButton("تفريغ ملف فيديو/صوت")
        self.save_btn = QPushButton("حفظ في الذاكرة")
        self.analyze_btn = QPushButton("استخراج الاستراتيجية بالذكاء الاصطناعي")
        for btn in (self.import_text_btn, self.fetch_caption_btn, self.transcribe_btn, self.save_btn, self.analyze_btn):
            btn.setMinimumHeight(34)
            btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        import_controls.addWidget(self.import_text_btn)
        import_controls.addWidget(self.fetch_caption_btn)
        import_controls.addWidget(self.transcribe_btn)
        action_controls.addWidget(self.save_btn, 1)
        action_controls.addWidget(self.analyze_btn, 2)
        self.import_text_btn.clicked.connect(self.import_text_file)
        self.fetch_caption_btn.clicked.connect(self.fetch_captions)
        self.transcribe_btn.clicked.connect(self.transcribe_media)
        self.save_btn.clicked.connect(self.save_current)
        self.analyze_btn.clicked.connect(self.analyze_current)
        right_layout.addLayout(import_controls)
        right_layout.addLayout(action_controls)

        analysis_box = QGroupBox("ما تعلّمه النظام من الدرس — مسودة تحتاج مراجعة")
        analysis_layout = QVBoxLayout(analysis_box)
        self.analysis_view = QPlainTextEdit()
        self.analysis_view.setReadOnly(True)
        self.analysis_view.setPlaceholderText("سيظهر هنا اسم الاستراتيجية وقواعد الدخول والخروج والمخاطر والنقاط الغامضة وخطة الاختبار.")
        analysis_layout.addWidget(self.analysis_view)
        right_layout.addWidget(analysis_box, 3)
        splitter.addWidget(right)
        splitter.setSizes([250, 820])

        footer = QHBoxLayout()
        self.status_line = QLabel("لم يتم اختيار درس. أضف رابطًا أو نصًا للبدء.")
        self.status_line.setWordWrap(True)
        close_btn = QPushButton("إغلاق")
        close_btn.clicked.connect(self.close)
        footer.addWidget(self.status_line, 1)
        footer.addWidget(close_btn)
        root.addLayout(footer)
        self.refresh_list()
        self.new_lesson()

    def _set_busy(self, busy: bool, message: str = "") -> None:
        self.state_label.setText(message or ("جاري العمل..." if busy else "ذاكرة محلية • الاستراتيجيات لا تؤثر في التوصيات الحالية"))
        for btn in (self.new_button, self.delete_button, self.import_text_btn, self.fetch_caption_btn,
                    self.transcribe_btn, self.save_btn, self.analyze_btn):
            btn.setEnabled(not busy)
        for widget in (self.title_input, self.url_input, self.transcript_editor, self.lessons_list, self.search_input):
            widget.setEnabled(not busy)

    def _start_worker(self, task: str, payload: dict) -> None:
        if self.worker is not None and self.worker.isRunning():
            QMessageBox.information(self, "المعالجة جارية", "انتظر انتهاء العملية الحالية قبل بدء عملية أخرى.")
            return
        self._working_task = task
        message = {
            "captions": "يحاول قراءة الترجمة المتاحة من الرابط دون تنزيل الفيديو نفسه...",
            "transcribe": "يجري تفريغ الكلام من الملف المحدد عبر خدمة API...",
            "analyze": "يجري تحويل شرح الدرس إلى قواعد منظمة ومراجعة نقاط الغموض...",
        }.get(task, "جاري العمل...")
        self._set_busy(True, message)
        self.worker = AcademyWorker(task, payload, self)
        self.worker.succeeded.connect(self._on_worker_success)
        self.worker.failed.connect(self._on_worker_failure)
        self.worker.finished.connect(self._on_worker_finished)
        self.worker.start()

    def _on_worker_success(self, task: str, result: object) -> None:
        data = result if isinstance(result, dict) else {}
        if task == "captions":
            self.transcript_editor.setPlainText(str(data.get("transcript", "")))
            title = str(data.get("title", "")).strip()
            if title and (not self.title_input.text().strip() or self.title_input.text().startswith("http")):
                self.title_input.setText(title)
            self._source_type_hint = "url"
            self._source_uri_hint = self.url_input.text().strip()
            self.source_info.setText("المصدر: ترجمة متاحة من الرابط — لم يتم تنزيل الفيديو")
            lesson_id = self.save_current(show_message=False)
            self.status_line.setText(f"تم استيراد الترجمة وحفظ الدرس رقم {lesson_id}. اضغط استخراج الاستراتيجية لتحليل القواعد.")
        elif task == "transcribe":
            self.transcript_editor.setPlainText(str(data.get("transcript", "")))
            self._source_type_hint = "media"
            self._source_uri_hint = str(data.get("path", ""))
            self.source_info.setText("المصدر: ملف محلي تم تفريغ الصوت منه؛ حُفظ النص فقط")
            lesson_id = self.save_current(show_message=False)
            self.status_line.setText(f"اكتمل التفريغ وحُفظ النص في الدرس رقم {lesson_id}. راجع النص ثم استخرج الاستراتيجية.")
        elif task == "analyze":
            lesson_id = int(data["lesson_id"])
            save_analysis(lesson_id, str(data.get("rendered", "")), data.get("strategy", {}), str(data.get("model", "")))
            self.analysis_view.setPlainText(_format_analysis(str(data.get("rendered", ""))))
            self.status_line.setText("اكتمل استخراج مسودة استراتيجية. راجع القواعد الناقصة والتحذيرات واختبرها تاريخيًا قبل استخدامها.")
            self.refresh_list(select_id=lesson_id)

    def _on_worker_failure(self, task: str, error: str) -> None:
        task_label = {"captions": "جلب الترجمة", "transcribe": "تفريغ الوسائط", "analyze": "تحليل الاستراتيجية"}.get(task, "المعالجة")
        self.status_line.setText(f"تعذر {task_label}: {error}")
        QMessageBox.warning(self, f"تعذر {task_label}", str(error))

    def _on_worker_finished(self) -> None:
        self._set_busy(False)
        finished_worker = self.worker
        self.worker = None
        if finished_worker is not None:
            finished_worker.deleteLater()

    def refresh_list(self, _text: str = "", select_id: int | None = None) -> None:
        if not hasattr(self, "lessons_list"):
            return
        term = self.search_input.text().strip()
        prior_id = select_id if select_id is not None else self.current_lesson_id
        self.lessons_list.blockSignals(True)
        self.lessons_list.clear()
        found_row = None
        for record in list_lessons(term):
            label = f"{record['title']}\n{STATUS_LABELS.get(record['status'], record['status'])} • #{record['id']}"
            item = QListWidgetItem(label)
            item.setData(Qt.ItemDataRole.UserRole, int(record["id"]))
            self.lessons_list.addItem(item)
            if prior_id is not None and int(record["id"]) == int(prior_id):
                found_row = item
        if found_row is not None:
            self.lessons_list.setCurrentItem(found_row)
        self.lessons_list.blockSignals(False)
        if found_row is not None:
            self.load_lesson(int(found_row.data(Qt.ItemDataRole.UserRole)))

    def new_lesson(self) -> None:
        self.current_lesson_id = None
        self._source_type_hint = "text"
        self._source_uri_hint = ""
        self.title_input.clear()
        self.url_input.clear()
        self.transcript_editor.clear()
        self.analysis_view.clear()
        self.source_info.setText("المصدر: نص مباشر")
        self.status_line.setText("درس جديد — أضف رابطًا أو استورد النص قبل التحليل.")
        self.lessons_list.blockSignals(True)
        self.lessons_list.clearSelection()
        self.lessons_list.setCurrentRow(-1)
        self.lessons_list.blockSignals(False)

    def on_lesson_selected(self, current, _previous) -> None:
        if current is None:
            return
        lesson_id = current.data(Qt.ItemDataRole.UserRole)
        if lesson_id is not None:
            self.load_lesson(int(lesson_id))

    def load_lesson(self, lesson_id: int) -> None:
        item = get_lesson(lesson_id)
        if not item:
            return
        self.current_lesson_id = int(lesson_id)
        self.title_input.setText(item.get("title", ""))
        source_type = str(item.get("source_type", "text"))
        source_uri = str(item.get("source_uri", ""))
        self.url_input.setText(source_uri if source_type == "url" else "")
        self._source_type_hint = source_type
        self._source_uri_hint = source_uri
        source_names = {"url": "رابط فيديو", "media": "ملف فيديو/صوت", "subtitle": "ملف ترجمة", "text": "نص مباشر"}
        self.source_info.setText(f"المصدر: {source_names.get(source_type, source_type)} — {source_uri or 'غير محدد'}")
        self.transcript_editor.setPlainText(item.get("transcript", ""))
        self.analysis_view.setPlainText(_format_analysis(item.get("analysis_text", "")))
        status = STATUS_LABELS.get(item.get("status", ""), item.get("status", ""))
        self.status_line.setText(f"الدرس #{lesson_id} • الحالة: {status} • آخر تحديث: {item.get('updated_at', '')}")

    def _current_source(self) -> tuple[str, str]:
        url = self.url_input.text().strip()
        if url:
            return "url", url
        if self._source_type_hint in ("media", "subtitle") and self._source_uri_hint:
            return self._source_type_hint, self._source_uri_hint
        return "text", self._source_uri_hint

    def save_current(self, show_message: bool = True) -> int:
        source_type, source_uri = self._current_source()
        title = self.title_input.text().strip()
        if not title:
            if source_uri:
                title = Path(source_uri).stem if source_type != "url" else source_uri.rsplit("/", 1)[-1][:120]
            else:
                title = "درس تداول جديد"
            self.title_input.setText(title)
        transcript = self.transcript_editor.toPlainText().strip()
        lesson_id = save_lesson(
            title=title, source_type=source_type, source_uri=source_uri,
            transcript=transcript, lesson_id=self.current_lesson_id,
        )
        self.current_lesson_id = lesson_id
        self.refresh_list(select_id=lesson_id)
        if show_message:
            self.status_line.setText(f"تم حفظ الدرس #{lesson_id} في الذاكرة المحلية. لا تزال الاستراتيجية غير مختبرة.")
        return lesson_id

    def import_text_file(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "استيراد نص أو ترجمة", "",
            "ملفات نص وترجمة (*.txt *.srt *.vtt *.md);;كل الملفات (*.*)"
        )
        if not path:
            return
        try:
            content = Path(path).read_text(encoding="utf-8-sig", errors="replace")
            if Path(path).suffix.lower() in (".srt", ".vtt"):
                content = parse_subtitle_text(content)
            self.transcript_editor.setPlainText(content.strip())
            self._source_type_hint = "subtitle" if Path(path).suffix.lower() in (".srt", ".vtt") else "text"
            self._source_uri_hint = path
            self.source_info.setText(f"المصدر: ملف نص/ترجمة — {path}")
            if not self.title_input.text().strip():
                self.title_input.setText(Path(path).stem)
            self.status_line.setText("تم تحميل النص إلى المحرر. احفظه ثم اطلب تحليل الاستراتيجية.")
        except OSError as exc:
            QMessageBox.warning(self, "تعذر قراءة الملف", str(exc))

    def fetch_captions(self) -> None:
        url = self.url_input.text().strip()
        if not url:
            QMessageBox.information(self, "رابط الفيديو", "ألصق رابط الفيديو أولًا.")
            return
        self._source_type_hint = "url"
        self._source_uri_hint = url
        self._start_worker("captions", {"url": url})

    def transcribe_media(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "اختيار فيديو أو ملف صوت", "",
            "فيديو وصوت (*.mp4 *.m4v *.mov *.webm *.mkv *.avi *.mp3 *.m4a *.wav *.ogg *.flac *.mpeg *.mpga);;كل الملفات (*.*)"
        )
        if not path:
            return
        settings = load_settings()
        api_key = get_api_key()
        if not api_key:
            QMessageBox.warning(
                self, "مفتاح API مطلوب",
                "تفريغ ملف الفيديو/الصوت يحتاج مفتاح API محفوظًا من نافذة الإعدادات، وقد يستهلك رصيدًا. "
                "يمكنك بدلًا من ذلك استيراد ملف الترجمة أو لصق النص يدويًا."
            )
            return
        self._source_type_hint = "media"
        self._source_uri_hint = path
        self.url_input.clear()
        self.source_info.setText(f"المصدر: ملف محلي — {path}")
        if not self.title_input.text().strip():
            self.title_input.setText(Path(path).stem)
        self._start_worker("transcribe", {
            "path": path,
            "api_key": api_key,
            "base_url": settings.get("ai_base_url", "https://api.openai.com/v1"),
        })

    def analyze_current(self) -> None:
        transcript = self.transcript_editor.toPlainText().strip()
        if len(transcript) < 80:
            QMessageBox.information(
                self, "النص غير كافٍ",
                "أضف تفريغًا أطول للدرس. لا يمكن استخراج قواعد موثوقة من عنوان الفيديو وحده."
            )
            return
        settings = load_settings()
        api_key = get_api_key()
        if not api_key:
            QMessageBox.warning(
                self, "مفتاح API مطلوب",
                "افتح الإعدادات وأضف مفتاح OpenAI API. سيتم إرسال نص الدرس إلى الموفّر عند الضغط على التحليل، وقد تترتب تكلفة."
            )
            return
        lesson_id = self.save_current(show_message=False)
        self._start_worker("analyze", {
            "lesson_id": lesson_id,
            "transcript": transcript,
            "api_key": api_key,
            "model": settings.get("ai_model", "gpt-4o-mini"),
            "base_url": settings.get("ai_base_url", "https://api.openai.com/v1"),
        })

    def closeEvent(self, event) -> None:
        if self.worker is not None and self.worker.isRunning():
            QMessageBox.warning(self, "المعالجة جارية", "انتظر اكتمال العملية الحالية قبل إغلاق نافذة الأكاديمية لتجنب فقدان النص أو تعطل البرنامج.")
            event.ignore()
            return
        super().closeEvent(event)

    def remove_lesson(self) -> None:
        if self.current_lesson_id is None:
            QMessageBox.information(self, "حذف الدرس", "اختر درسًا من المكتبة أولًا.")
            return
        response = QMessageBox.question(
            self, "تأكيد الحذف", "سيتم حذف الدرس والنص والتحليل المحفوظ من قاعدة الذاكرة المحلية. هل تريد المتابعة?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if response != QMessageBox.StandardButton.Yes:
            return
        delete_lesson(self.current_lesson_id)
        self.new_lesson()
        self.refresh_list()
        self.status_line.setText("تم حذف الدرس من المكتبة المحلية.")
