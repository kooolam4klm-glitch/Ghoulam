"""Pure presentation helpers for displaying recommendation status safely."""

from __future__ import annotations


def format_signal_badge(signal: object) -> str:
    """Format a recommendation badge without implying a win probability.

    When the engine is WAIT, show its strongest rule-alignment score as a
    diagnostic, not as a probability of profit.
    """
    data = signal if isinstance(signal, dict) else {}
    direction = str(data.get("direction", "WAIT") or "WAIT").upper()
    symbol = str(data.get("symbol", "—") or "—")
    confidence = data.get("confidence")

    score_text = ""
    if confidence is not None:
        if direction in ("BUY", "SELL"):
            score_text = f" • توافق القواعد {confidence}/100"
        else:
            score_text = f" • أعلى توافق للقواعد {confidence}/100"

    return f"{direction}{score_text} — {symbol}"
