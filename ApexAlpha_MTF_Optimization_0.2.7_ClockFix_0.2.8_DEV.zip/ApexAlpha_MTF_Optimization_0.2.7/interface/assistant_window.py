from __future__ import annotations
import threading
from PySide6.QtCore import QObject, Signal, Qt
from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPlainTextEdit, QLineEdit,
    QPushButton, QMessageBox
)
from config.app_settings import load_settings
from services.secure_store import get_api_key
from services.openai_client import chat_completion
from services.voice_language import detect_text_language

class _ReplySignals(QObject):
    finished = Signal(str, bool)

class AssistantWindow(QDialog):
    """On-demand AI chat grounded in the currently visible local MT5 analysis."""
    def __init__(self, context_provider, speech_callback=None, open_settings_callback=None, parent=None):
        super().__init__(parent)
        self.context_provider = context_provider
        self.speech_callback = speech_callback
        self.open_settings_callback = open_settings_callback
        self.setWindowTitle("Apex Alpha — مساعد الذكاء الاصطناعي")
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMinimizeButtonHint |
                            Qt.WindowType.WindowMaximizeButtonHint | Qt.WindowType.WindowSystemMenuHint)
        self.setSizeGripEnabled(True); self.resize(650, 650); self.setMinimumSize(400, 350)
        root = QVBoxLayout(self)
        title = QLabel("مساعد Apex Alpha · الإجابات معلوماتية وليست أوامر تداول")
        title.setStyleSheet("font-size: 16px; font-weight: 700; color: #a78bfa;")
        root.addWidget(title)
        self.transcript = QPlainTextEdit(); self.transcript.setReadOnly(True); self.transcript.setLineWrapMode(QPlainTextEdit.LineWrapMode.WidgetWidth)
        root.addWidget(self.transcript, 1)
        row = QHBoxLayout()
        self.input = QLineEdit(); self.input.setPlaceholderText("اسأل عن الاتجاه أو الإشارة أو حالة الحساب…")
        self.send_btn = QPushButton("إرسال")
        self.settings_btn = QPushButton("إعدادات API")
        row.addWidget(self.input, 1); row.addWidget(self.send_btn); row.addWidget(self.settings_btn)
        root.addLayout(row)
        self.note = QLabel("لا تُرسل بيانات الحساب إلى OpenAI إلا عند الإرسال. راجع أي معلومات حساسة قبل استخدامها.")
        self.note.setWordWrap(True); self.note.setStyleSheet("color: #d99b48;")
        root.addWidget(self.note)
        self._history = []
        self._signals = _ReplySignals(self); self._signals.finished.connect(self._handle_reply)
        self.send_btn.clicked.connect(self.send_prompt); self.input.returnPressed.connect(self.send_prompt)
        self.settings_btn.clicked.connect(self._open_settings)
        self._busy = False
        self.transcript.appendPlainText("Apex Alpha: مرحبًا. أستطيع شرح ملخص التحليل الذي يقرأه البوت، لكن لا أضمن نتيجة التداول ولا أنفّذ صفقات.")

    def _open_settings(self):
        if self.open_settings_callback:
            self.open_settings_callback()

    def send_prompt(self):
        if self._busy:
            return
        question = self.input.text().strip()
        if not question:
            return
        settings = load_settings()
        if not settings.get("ai_enabled", True):
            self.transcript.appendPlainText("النظام: مساعد الذكاء الاصطناعي معطّل من الإعدادات.")
            return
        if settings.get("ai_provider", "OpenAI") != "OpenAI":
            self.transcript.appendPlainText("النظام: موائم هذا المزوّد غير مفعّل في هذه النسخة. اختر OpenAI في الإعدادات.")
            return
        key = get_api_key()
        if not key:
            self.transcript.appendPlainText("النظام: أضف مفتاح OpenAI API من الإعدادات قبل إرسال الأسئلة.")
            self._open_settings()
            return
        try:
            context = str(self.context_provider() or "لا تتوفر بيانات سياق محلية.")
        except Exception:
            context = "تعذر الحصول على سياق محلي في هذه اللحظة."
        self.transcript.appendPlainText("أنت: " + question)
        self.transcript.appendPlainText("Apex Alpha: جارٍ التحليل…")
        self.input.clear(); self.send_btn.setEnabled(False); self._busy = True
        self._history.append({"role": "user", "content": question})
        voice_preference = settings.get("voice_language", "auto")
        response_language = voice_preference if voice_preference in ("ar", "en", "fr", "ru") else detect_text_language(question, settings.get("language", "ar"))
        messages = [{"role": "system", "content": (
            f"You are Apex Alpha, an assistant for technical market analysis. Reply in language code {response_language}. "
            "Use only the supplied context for claimed account/price facts; clearly state when something is missing. "
            "Distinguish recommendations from actual open broker positions. Do not claim a trade was placed. "
            "Do not promise profit or present analysis as certainty. Current local MT5 context:\n" + context
        )}] + self._history[-12:]
        model = settings.get("ai_model", "gpt-4o-mini")
        base = settings.get("ai_base_url", "https://api.openai.com/v1")
        def worker():
            try:
                response = chat_completion(key, model, base, messages)
                self._signals.finished.emit(response, True)
            except Exception as exc:
                self._signals.finished.emit(str(exc), False)
        threading.Thread(target=worker, daemon=True, name="ApexAIChat").start()

    def _handle_reply(self, response, ok):
        self._busy = False; self.send_btn.setEnabled(True)
        # Remove the transient "thinking" line without disturbing the question/history.
        text = self.transcript.toPlainText()
        marker = "Apex Alpha: جارٍ التحليل…"
        if marker in text:
            prefix, _, tail = text.rpartition(marker)
            self.transcript.setPlainText(prefix.rstrip() + "\nApex Alpha: " + (response if ok else "تعذر تنفيذ الطلب: " + response) + ("" if not tail else "\n" + tail))
        else:
            self.transcript.appendPlainText("Apex Alpha: " + (response if ok else "تعذر تنفيذ الطلب: " + response))
        if ok:
            self._history.append({"role": "assistant", "content": response})
            settings = load_settings()
            if settings.get("voice_enabled") and settings.get("voice_responses") and self.speech_callback:
                self.speech_callback(response)
