from datetime import datetime
import time
import threading
import os
from pathlib import Path
from PySide6.QtCore import QTimer, QObject, Signal, Qt
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QComboBox, QTableWidget, QTableWidgetItem, QMessageBox,
    QGroupBox, QFormLayout, QDialog, QHeaderView, QGridLayout,
    QPlainTextEdit, QScrollArea, QCheckBox, QFrame, QToolButton,
    QSizePolicy
)
from PySide6.QtGui import QColor
from mt5.connection import MT5Connection
from bridge.price_bridge import PriceBridgeServer
from bridge.indicator_signal_reader import read_indicator_snapshot, IndicatorSnapshotError
from intelligence.signal_engine import make_demo_signal
from intelligence.multi_timeframe import analyze_multi_timeframe, apply_multi_timeframe_gate
from intelligence.market_clock import TickClockTracker, gate_signal
from storage.database import record_event, recent_events
from storage.paper_journal import (
    record_shadow_signal, update_open_signals, signal_summary,
    recent_signals, set_user_decision,
)
from charting.chart_window import ChartWindow, CandleChart
from config.app_settings import load_settings, save_settings
from services.secure_store import get_api_key
from services.voice_notifier import VoiceNotifier
from services.voice_language import resolve_voice_language
from risk.risk_manager import calculate_position_size
from services.openai_client import chat_completion
from services.theme import apply_theme
from services.i18n import translate_widget_tree, translate
from interface.settings_dialog import SettingsDialog
from interface.assistant_window import AssistantWindow
from interface.signal_presentation import format_signal_badge
from interface.strategy_academy_window import StrategyAcademyWindow


APP_VERSION = (Path(__file__).resolve().parents[1] / "VERSION.txt").read_text(encoding="utf-8").strip()


class RecommendationWindow(QDialog):
    """Resizable, separate recommendations panel; recommendations are informational only."""
    def __init__(self, dashboard):
        super().__init__(dashboard)
        self.dashboard = dashboard
        self.setWindowTitle("Apex Alpha — نافذة التوصيات")
        # Keep native Windows title-bar controls so Windows 11 Snap Layouts
        # appear when hovering over the maximize button.
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMinimizeButtonHint |
                            Qt.WindowType.WindowMaximizeButtonHint | Qt.WindowType.WindowSystemMenuHint)
        self.setSizeGripEnabled(True)
        self.resize(560, 650)
        self.setMinimumSize(360, 320)
        root = QVBoxLayout(self)
        title = QLabel("التوصيات والتحليل — محاكاة فقط")
        title.setStyleSheet("font-size: 18px; font-weight: 700; color: #8bb8ff;")
        root.addWidget(title)
        self.signal_badge = QLabel("WAIT — بانتظار تحليل السوق")
        self.signal_badge.setStyleSheet("font-size: 16px; font-weight: 700; padding: 8px; border: 1px solid #454b55; border-radius: 5px;")
        root.addWidget(self.signal_badge)
        self.account_summary = QLabel("الحساب: في انتظار بيانات MT5")
        self.account_summary.setWordWrap(True)
        self.account_summary.setStyleSheet("font-size: 12px; padding: 7px; background: #101a2b; border: 1px solid #283750; border-radius: 6px;")
        root.addWidget(self.account_summary)
        self.details = QPlainTextEdit()
        self.details.setReadOnly(True)
        self.details.setLineWrapMode(QPlainTextEdit.LineWrapMode.WidgetWidth)
        root.addWidget(self.details, 1)
        row = QHBoxLayout()
        self.left_btn = QPushButton("تقسيم: التوصيات يسارًا")
        self.right_btn = QPushButton("تقسيم: التوصيات يمينًا")
        self.ai_btn = QPushButton("مساعد الذكاء الاصطناعي")
        self.left_btn.clicked.connect(lambda: self.snap_to_side("left"))
        self.right_btn.clicked.connect(lambda: self.snap_to_side("right"))
        self.ai_btn.clicked.connect(self.dashboard.show_assistant_window)
        row.addWidget(self.left_btn); row.addWidget(self.right_btn); row.addWidget(self.ai_btn)
        root.addLayout(row)
        decision_row = QHBoxLayout()
        self.approve_button = QPushButton("الموافقة على الإشارة (محاكاة)")
        self.reject_button = QPushButton("رفض الإشارة")
        self.approve_button.clicked.connect(self.dashboard.approve_simulation)
        self.reject_button.clicked.connect(self.dashboard.reject_signal)
        self.approve_button.setEnabled(False)
        self.reject_button.setEnabled(False)
        decision_row.addWidget(self.approve_button)
        decision_row.addWidget(self.reject_button)
        root.addLayout(decision_row)
        note = QLabel("للعرض والتحقق فقط؛ الموافقة تسجل قرار محاكاة ولا ترسل أوامر تداول حقيقية.")
        note.setWordWrap(True); note.setStyleSheet("color: #d99b48;")
        root.addWidget(note)

    def set_account_summary(self, text):
        self.account_summary.setText(str(text or "الحساب: في انتظار بيانات MT5"))

    def set_recommendation(self, text, signal=None):
        self.details.setPlainText(str(text or "لا توجد توصية بعد. اضغط تحديث السوق في النافذة الرئيسية."))
        direction = (signal or {}).get("direction", "WAIT") if isinstance(signal, dict) else "WAIT"
        color = "#45b881" if direction == "BUY" else "#f87171" if direction == "SELL" else "#d99b48"
        self.signal_badge.setText(format_signal_badge(signal))
        self.signal_badge.setStyleSheet(f"font-size: 16px; font-weight: 700; color: {color}; padding: 8px; border: 1px solid #454b55; border-radius: 5px;")
        actionable = bool(self.dashboard.pending_signal)
        self.approve_button.setEnabled(actionable)
        self.reject_button.setEnabled(actionable)

    def snap_to_side(self, side):
        screen = self.screen() or QApplication.primaryScreen()
        if screen is None:
            return
        area = screen.availableGeometry()
        half = area.width() // 2
        x = area.x() if side == "left" else area.x() + half
        self.setGeometry(x, area.y(), half, area.height())


class RecommendationPanel(QGroupBox):
    """Inline recommendation panel occupying the former market-reading position."""
    def __init__(self, dashboard, parent=None):
        super().__init__("التوصيات والتحليل", parent)
        self.dashboard = dashboard
        self.setObjectName("recommendationPanel")
        layout = QVBoxLayout(self)
        self.signal_badge = QLabel("WAIT — بانتظار تحليل السوق")
        self.signal_badge.setWordWrap(True)
        self.signal_badge.setStyleSheet("font-size: 17px; font-weight: 800; padding: 10px; border: 1px solid #283750; border-radius: 8px;")
        layout.addWidget(self.signal_badge)
        self.details = QPlainTextEdit()
        self.details.setReadOnly(True)
        self.details.setLineWrapMode(QPlainTextEdit.LineWrapMode.WidgetWidth)
        self.details.setPlaceholderText("ستظهر هنا التوصية وأسبابها بعد قراءة السوق.")
        layout.addWidget(self.details, 1)
        decision_row = QHBoxLayout()
        self.approve_btn = QPushButton("الموافقة على الإشارة (محاكاة)")
        self.reject_btn = QPushButton("رفض الإشارة")
        self.approve_btn.setEnabled(False)
        self.reject_btn.setEnabled(False)
        self.approve_btn.clicked.connect(dashboard.approve_simulation)
        self.reject_btn.clicked.connect(dashboard.reject_signal)
        decision_row.addWidget(self.approve_btn)
        decision_row.addWidget(self.reject_btn)
        layout.addLayout(decision_row)
        bottom_row = QHBoxLayout()
        self.journal_btn = QPushButton("سجل الإشارات ونتائجها")
        self.market_btn = QPushButton("قراءة السوق والتوقيتات")
        self.ai_btn = QPushButton("المساعد الذكي")
        self.journal_btn.clicked.connect(dashboard.show_signal_journal)
        self.market_btn.clicked.connect(dashboard.show_market_reading_window)
        self.ai_btn.clicked.connect(dashboard.show_assistant_window)
        bottom_row.addWidget(self.journal_btn)
        bottom_row.addWidget(self.market_btn)
        bottom_row.addWidget(self.ai_btn)
        layout.addLayout(bottom_row)
        note = QLabel("الموافقة تسجل قرارًا افتراضيًا فقط؛ لا يتم إرسال أوامر تداول حقيقية.")
        note.setWordWrap(True)
        note.setStyleSheet("color: #d99b48; padding: 3px;")
        layout.addWidget(note)

    def set_recommendation(self, text, signal=None):
        self.details.setPlainText(str(text or "لا توجد توصية بعد. اضغط اتصال / تحديث لقراءة السوق."))
        direction = (signal or {}).get("direction", "WAIT") if isinstance(signal, dict) else "WAIT"
        color = "#45b881" if direction == "BUY" else "#f87171" if direction == "SELL" else "#d99b48"
        self.signal_badge.setText(format_signal_badge(signal))
        self.signal_badge.setStyleSheet(f"font-size: 17px; font-weight: 800; color: {color}; padding: 10px; border: 1px solid #283750; border-radius: 8px;")
        actionable = bool(self.dashboard.pending_signal)
        self.approve_btn.setEnabled(actionable)
        self.reject_btn.setEnabled(actionable)


class DashboardSignals(QObject):
    bridge_tick = Signal(str, float, float, object, str)
    bridge_client_state = Signal(bool)
    ai_analysis_done = Signal(str, str)


class Dashboard(QMainWindow):
    def __init__(self):
        super().__init__()
        self.app_settings = load_settings()
        app = QApplication.instance()
        if app is not None:
            apply_theme(app, self.app_settings.get("theme", "dark"))
        self.setWindowTitle(f"Apex Alpha Intelligence Core — {APP_VERSION}")
        self.resize(1420, 940)
        self.setMinimumSize(1050, 720)
        self.mt5 = MT5Connection()
        self.voice = VoiceNotifier()
        self.settings_dialog = None
        self.assistant_window = None
        self.academy_window = None
        self._last_position_ids = None
        self._was_market_connected = None
        self._last_announced_signal_key = None
        self._auto_ai_signal_keys = set()
        self.clock_tracker = TickClockTracker(max_age_seconds=15)
        self.pending_signal = None
        self.latest_analysis_signal = None
        self.journal_dialog = None
        self.chart_window = None
        self.recommendation_window = None
        self.last_account = None
        self.current_digits = 2
        self.last_context_refresh = 0.0
        self.last_context_symbol = ""
        self.last_multi_timeframe_analysis = None
        self.ui_signals = DashboardSignals()
        self.ui_signals.bridge_tick.connect(self.on_bridge_tick)
        self.ui_signals.bridge_client_state.connect(self.on_bridge_client_state)
        self.ui_signals.ai_analysis_done.connect(self.apply_ai_signal_analysis)
        self.bridge = PriceBridgeServer(
            on_tick=lambda d: self.ui_signals.bridge_tick.emit(
                d["symbol"], d["bid"], d["ask"], d["time_msc"], d["received_local_label"]),
            on_client_state=lambda connected: self.ui_signals.bridge_client_state.emit(connected),
        )
        self.bridge_started = self.bridge.start()

        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(18, 15, 18, 15)
        layout.setSpacing(12)
        header = QHBoxLayout()
        title = QLabel("APEX ALPHA  |  INTELLIGENCE CORE")
        title.setStyleSheet("font-size: 23px; font-weight: 800; color: #a78bfa; padding: 4px 0;")
        self.status = QLabel("DISCONNECTED")
        self.status.setStyleSheet("font-weight: 700; color: #d99b48;")
        self.quick_chart_btn = QPushButton("فتح الشارت")
        self.quick_recommendations_btn = QPushButton("فتح التوصيات")
        self.assistant_btn = QPushButton("مساعد الذكاء الاصطناعي")
        self.settings_btn = QPushButton("الإعدادات")
        self.quick_chart_btn.clicked.connect(self.show_chart_window)
        self.quick_recommendations_btn.clicked.connect(self.show_recommendation_window)
        self.assistant_btn.clicked.connect(self.show_assistant_window)
        self.settings_btn.clicked.connect(self.show_settings_window)
        header.addWidget(title); header.addStretch()
        header.addWidget(self.quick_chart_btn); header.addWidget(self.quick_recommendations_btn)
        header.addWidget(self.assistant_btn); header.addWidget(self.settings_btn); header.addWidget(self.status)
        layout.addLayout(header)

        connection_box = QGroupBox("الاتصال والسوق")
        connection_layout = QHBoxLayout(connection_box)
        self.symbol = QLineEdit("BTCUSD")
        self.timeframe = QComboBox()
        self.timeframe.addItems(["M1", "M5", "M15", "M30", "H1", "H4", "D1"])
        self.timeframe.setCurrentText("M15")
        self.connect_btn = QPushButton("اتصال / تحديث الآن")
        self.auto_refresh = QPushButton("إيقاف التحديث التلقائي")
        self.connect_btn.clicked.connect(self.refresh_market)
        self.auto_refresh.clicked.connect(self.toggle_auto_refresh)
        connection_layout.addWidget(QLabel("Symbol")); connection_layout.addWidget(self.symbol)
        connection_layout.addWidget(QLabel("Timeframe")); connection_layout.addWidget(self.timeframe)
        connection_layout.addWidget(self.connect_btn); connection_layout.addWidget(self.auto_refresh)
        layout.addWidget(connection_box)

        account_box = QGroupBox("معلومات الحساب")
        account_form = QFormLayout(account_box)
        self.account_label = QLabel("غير متصل"); self.login_label = QLabel("—")
        self.balance_label = QLabel("—"); self.equity_label = QLabel("—")
        self.floating_pnl_label = QLabel("—"); self.today_pnl_label = QLabel("غير متاح")
        self.positions_count_label = QLabel("0"); self.margin_label = QLabel("—"); self.free_margin_label = QLabel("—")
        self.positions_label = QLabel("لا توجد بيانات مراكز بعد")
        self.positions_label.setWordWrap(True)
        self.server_label = QLabel("—")
        self.updated_label = QLabel("—")
        self.source_label = QLabel("等待数据源")
        self.bridge_status_label = QLabel("等待连接")
        self.raw_tick_label = QLabel("—")
        self.corrected_tick_label = QLabel("—")
        self.analysis_time_label = QLabel("—")
        account_form.addRow("نوع الحساب:", self.account_label)
        account_form.addRow("رقم الحساب:", self.login_label)
        account_form.addRow("الرصيد:", self.balance_label)
        account_form.addRow("Equity:", self.equity_label)
        account_form.addRow("الربح/الخسارة العائمة:", self.floating_pnl_label)
        account_form.addRow("النتيجة المحققة اليوم (UTC):", self.today_pnl_label)
        account_form.addRow("المراكز المفتوحة:", self.positions_count_label)
        account_form.addRow("الهامش / الهامش الحر:", self.margin_label)
        account_form.addRow("تفاصيل المراكز الفعلية:", self.positions_label)
        account_form.addRow("Server:", self.server_label)
        account_form.addRow("مصدر السعر المستخدم:", self.source_label)
        account_form.addRow("حالة جسر الأسعار المحلي:", self.bridge_status_label)
        account_form.addRow("وقت Tick من MT5 (UTC):", self.raw_tick_label)
        account_form.addRow("الوقت المحلي المكافئ لنفس Tick:", self.corrected_tick_label)
        account_form.addRow("وقت استلام البيانات (محلي):", self.updated_label)
        account_form.addRow("وقت حساب التحليل (محلي):", self.analysis_time_label)
        layout.addWidget(account_box)

        context_box = QGroupBox("السياق متعدد الأطر — تحليل إضافي للقراءة فقط")
        context_layout = QVBoxLayout(context_box)
        self.context_summary = QLabel(
            "بانتظار بيانات M15 وH1 وH4. هذا التحليل لا يغيّر إشارة التداول الأساسية."
        )
        self.context_summary.setWordWrap(True)
        self.context_summary.setStyleSheet("color: #b8c9e8; padding: 4px;")
        context_layout.addWidget(self.context_summary)
        context_actions = QHBoxLayout()
        self.context_refresh_btn = QPushButton("تحديث السياق متعدد الأطر")
        self.context_refresh_btn.clicked.connect(
            lambda: self.refresh_multi_timeframe_context(self.symbol.text().strip(), force=True)
        )
        self.chart_btn = QPushButton("فتح الشارت الداخلي والتحكم بالمؤشرات")
        self.chart_btn.clicked.connect(self.show_chart_window)
        context_actions.addWidget(self.context_refresh_btn)
        context_actions.addWidget(self.chart_btn)
        context_actions.addStretch()
        context_layout.addLayout(context_actions)
        layout.addWidget(context_box)

        signal_box = QGroupBox("قراءة السوق — المحاكاة فقط")
        signal_layout = QVBoxLayout(signal_box)
        self.market_state = QLabel("حالة الأسعار: لم يتم الفحص")
        self.market_state.setWordWrap(True)
        self.market_state.setStyleSheet("font-weight: 700; color: #d99b48; padding: 3px;")
        signal_layout.addWidget(self.market_state)
        self.live_tick_label = QLabel("الجسر المباشر: في انتظار EA لتمرير أول Tick.")
        self.live_tick_label.setWordWrap(True)
        self.live_tick_label.setStyleSheet("color: #8bb8ff; padding: 3px;")
        signal_layout.addWidget(self.live_tick_label)
        self.signal_summary = QLabel("اضغط اتصال / تحديث لقراءة السوق.")
        self.signal_summary.setWordWrap(True)
        signal_layout.addWidget(self.signal_summary)
        actions = QHBoxLayout()
        self.journal_btn = QPushButton("سجل الإشارات ونتائجها")
        self.journal_btn.clicked.connect(self.show_signal_journal)
        actions.addWidget(self.journal_btn)
        signal_layout.addLayout(actions)
        self.market_reading_dialog = QDialog(self)
        self.market_reading_dialog.setWindowTitle("Apex Alpha — قراءة السوق")
        self.market_reading_dialog.resize(900, 650)
        market_dialog_layout = QVBoxLayout(self.market_reading_dialog)
        market_dialog_layout.addWidget(signal_box)
        market_dialog_layout.addWidget(QLabel("هذه النافذة تعرض حالة الأسعار وتوقيتات MT5 وتشخيصات السوق؛ التوصيات وقرارات المستخدم في لوحة التوصيات."))
        self.market_reading_dialog.finished.connect(lambda *_: None)

        log_box = QGroupBox("سجل الأحداث المحلي")
        log_layout = QVBoxLayout(log_box)
        self.log = QTableWidget(0, 3)
        self.log.setHorizontalHeaderLabels(["الوقت", "الحدث", "التفاصيل"])
        self.log.horizontalHeader().setStretchLastSection(True)
        self.log.setAlternatingRowColors(True)
        log_layout.addWidget(self.log); layout.addWidget(log_box)
        note = QLabel("وضع آمن: قراءة بيانات فقط + محاكاة. لا تُرسل هذه النسخة أوامر تداول فعلية.")
        note.setStyleSheet("color: #d99b48; padding: 5px; font-weight: 600;")
        layout.addWidget(note)

        # Apex Alpha V2.6: detach the initial stacked layout before assembling the terminal shell.
        while layout.count():
            item = layout.takeAt(0)
            if item.layout() is not None:
                item.layout().setParent(None)
        # Single-window terminal with icon-only navigation, balanced chart/recommendation columns,
        # and a compact bottom account/positions strip.
        chart_box = QGroupBox("الشارت المباشر")
        chart_box.setObjectName("terminalChartCard")
        chart_box_layout = QVBoxLayout(chart_box)
        chart_toolbar = QHBoxLayout()
        chart_toolbar.addWidget(QLabel("الشموع والمؤشرات من بيانات MT5"))
        chart_toolbar.addStretch()
        self.chart_zoom_in_btn = QPushButton("تكبير +")
        self.chart_zoom_in_btn.setToolTip("إظهار عدد أقل من الشموع بحجم أكبر")
        self.chart_zoom_out_btn = QPushButton("تصغير −")
        self.chart_zoom_out_btn.setToolTip("إظهار عدد أكبر من الشموع")
        self.chart_zoom_reset_btn = QPushButton("إعادة الزوم")
        self.chart_zoom_in_btn.clicked.connect(lambda: self.terminal_chart.zoom_in())
        self.chart_zoom_out_btn.clicked.connect(lambda: self.terminal_chart.zoom_out())
        self.chart_zoom_reset_btn.clicked.connect(lambda: self.terminal_chart.reset_zoom())
        chart_toolbar.addWidget(self.chart_zoom_in_btn)
        chart_toolbar.addWidget(self.chart_zoom_out_btn)
        chart_toolbar.addWidget(self.chart_zoom_reset_btn)
        self.open_full_chart_btn = QPushButton("أدوات الشارت المتقدمة")
        self.open_full_chart_btn.clicked.connect(self.show_chart_window)
        chart_toolbar.addWidget(self.open_full_chart_btn)
        chart_box_layout.addLayout(chart_toolbar)
        self.terminal_chart = CandleChart(chart_box)
        self.terminal_chart.setMinimumSize(420, 320)
        chart_box_layout.addWidget(self.terminal_chart, 1)

        self.recommendation_panel = RecommendationPanel(self)
        self.approve_btn = self.recommendation_panel.approve_btn
        self.reject_btn = self.recommendation_panel.reject_btn

        # The main page keeps only essentials; detailed account, multi-timeframe,
        # and event log content is moved to dedicated windows opened from the rail.
        self.account_dialog = QDialog(self)
        self.account_dialog.setWindowTitle("Apex Alpha — معلومات الحساب")
        self.account_dialog.resize(760, 620)
        account_dialog_layout = QVBoxLayout(self.account_dialog)
        account_dialog_layout.addWidget(account_box)
        account_dialog_layout.addStretch()

        self.context_dialog = QDialog(self)
        self.context_dialog.setWindowTitle("Apex Alpha — التحليل متعدد الأطر")
        self.context_dialog.resize(680, 420)
        context_dialog_layout = QVBoxLayout(self.context_dialog)
        context_dialog_layout.addWidget(context_box)
        context_dialog_layout.addStretch()

        self.events_dialog = QDialog(self)
        self.events_dialog.setWindowTitle("Apex Alpha — سجل الأحداث المحلي")
        self.events_dialog.resize(900, 520)
        events_dialog_layout = QVBoxLayout(self.events_dialog)
        events_dialog_layout.addWidget(log_box)
        events_dialog_layout.addStretch()

        # Compact account summary cards. Detailed figures remain in account window.
        bottom_box = QGroupBox("ملخص الحساب")
        bottom_layout = QGridLayout(bottom_box)
        bottom_layout.setContentsMargins(8, 8, 8, 8)
        self.compact_balance = QLabel("الرصيد: —")
        self.compact_equity = QLabel("حقوق الحساب: —")
        self.compact_pnl = QLabel("العائم: —")
        self.compact_today = QLabel("نتيجة اليوم: —")
        for label in (self.compact_balance, self.compact_equity, self.compact_pnl, self.compact_today):
            label.setStyleSheet("padding: 7px 9px; border: 1px solid #283750; border-radius: 6px; font-weight: 600;")
            label.setMinimumWidth(120)
        bottom_layout.addWidget(self.compact_balance, 0, 0)
        bottom_layout.addWidget(self.compact_equity, 0, 1)
        bottom_layout.addWidget(self.compact_pnl, 0, 2)
        bottom_layout.addWidget(self.compact_today, 0, 3)

        positions_box = QGroupBox("المراكز المفتوحة — قراءة فقط")
        positions_layout = QVBoxLayout(positions_box)
        self.positions_table = QTableWidget(0, 6)
        self.positions_table.setHorizontalHeaderLabels(["الرمز", "الاتجاه", "الحجم", "سعر الفتح", "السعر الحالي", "الربح/الخسارة"])
        self.positions_table.setMaximumHeight(118)
        self.positions_table.setAlternatingRowColors(True)
        self.positions_table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.positions_table.verticalHeader().setVisible(False)
        positions_layout.addWidget(self.positions_table)

        # Icon-only left navigation rail. Tooltips provide names without taking space.
        rail = QFrame()
        rail.setObjectName("navigationRail")
        rail.setFixedWidth(58)
        rail_layout = QVBoxLayout(rail)
        rail_layout.setContentsMargins(5, 8, 5, 8)
        rail_layout.setSpacing(7)
        self.nav_buttons = []
        def add_nav(symbol_text, tooltip, callback):
            button = QToolButton(rail)
            button.setText(symbol_text)
            button.setToolTip(tooltip)
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.setFixedSize(44, 42)
            button.setStyleSheet("QToolButton { background:#101a2b; border:1px solid #283750; border-radius:8px; font-size:18px; color:#b8c9e8; } QToolButton:hover { background:#30265a; border-color:#8b5cf6; color:#ffffff; }")
            button.clicked.connect(callback)
            rail_layout.addWidget(button)
            self.nav_buttons.append(button)
            return button
        add_nav("⌂", "الرئيسية", lambda: None)
        add_nav("▥", "الشارت وأدواته", self.show_chart_window)
        add_nav("◈", "التوصيات", self.focus_recommendation_panel)
        add_nav("⌁", "قراءة السوق والتوقيتات", self.show_market_reading_window)
        add_nav("✧", "مساعد الذكاء الاصطناعي", self.show_assistant_window)
        add_nav("▤", "سجل الإشارات", self.show_signal_journal)
        add_nav("▧", "أكاديمية الاستراتيجيات", self.show_strategy_academy)
        add_nav("◫", "معلومات الحساب", self.show_account_window)
        add_nav("⌁", "التحليل متعدد الأطر", self.show_context_window)
        add_nav("≡", "سجل الأحداث المحلي", self.show_events_window)
        rail_layout.addStretch()
        add_nav("⚙", "الإعدادات", self.show_settings_window)

        # Header and connection controls stay compact at the top.
        header.setContentsMargins(2, 0, 2, 0)
        title.setStyleSheet("font-size: 20px; font-weight: 800; color: #a78bfa; padding: 4px 0;")
        # Keep the top bar uncluttered; navigation actions live in the icon rail.
        # Keep direct access to Recommendations and Settings visible. The former
        # was previously hidden while its sidebar action only focused the home
        # page, making the recommendation window appear broken to the user.
        self.quick_chart_btn.hide()
        self.assistant_btn.hide()
        self.quick_recommendations_btn.setText("التوصيات")
        self.settings_btn.setText("الإعدادات")

        # A balanced 50/50 main work area: chart and inline recommendation panel.
        workspace = QWidget()
        workspace_layout = QHBoxLayout(workspace)
        workspace_layout.setContentsMargins(0, 0, 0, 0)
        workspace_layout.setSpacing(10)
        chart_box.setMinimumWidth(420)
        signal_box.setMinimumWidth(350)
        workspace_layout.addWidget(chart_box, 6)
        workspace_layout.addWidget(self.recommendation_panel, 5)

        bottom_row = QHBoxLayout()
        bottom_row.setSpacing(10)
        bottom_row.addWidget(bottom_box, 4)
        bottom_row.addWidget(positions_box, 6)

        main_column = QVBoxLayout()
        main_column.setContentsMargins(0, 0, 0, 0)
        main_column.setSpacing(9)
        main_column.addLayout(header)
        main_column.addWidget(connection_box)
        main_column.addWidget(workspace, 1)
        main_column.addLayout(bottom_row)
        main_column.addWidget(note)

        shell = QHBoxLayout()
        shell.setContentsMargins(10, 8, 10, 8)
        shell.setSpacing(10)
        shell.addWidget(rail)
        shell.addLayout(main_column, 1)
        # Install the terminal shell into the now-empty central layout.
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addLayout(shell)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_market_silent)
        self.timer.start(1000)
        self.add_log("بدء التشغيل", f"{APP_VERSION} — التحديث التلقائي كل ثانية؛ التنفيذ الفعلي معطّل.")
        if self.bridge_started:
            self.bridge_status_label.setText("الخادم المحلي يعمل على 127.0.0.1:47831؛ افتح ApexPriceBridge على شارت الرمز.")
        else:
            self.bridge_status_label.setText("الجسر غير متاح؛ سيُستخدم اتصال MT5 Python كاحتياطي. " + str(self.bridge.error or ""))
        self.load_saved_events()
        translate_widget_tree(self, self.app_settings.get("language", "ar"))

    def signal_box_scroll_to_top(self):
        self.focus_recommendation_panel()

    def focus_recommendation_panel(self):
        self.showNormal()
        self.raise_()
        self.activateWindow()
        try:
            self.recommendation_panel.setFocus(Qt.FocusReason.OtherFocusReason)
        except (AttributeError, RuntimeError):
            pass

    def show_market_reading_window(self):
        self.market_reading_dialog.showNormal()
        self.market_reading_dialog.raise_()
        self.market_reading_dialog.activateWindow()

    def show_account_window(self):
        self.account_dialog.show(); self.account_dialog.raise_(); self.account_dialog.activateWindow()

    def show_context_window(self):
        self.context_dialog.show(); self.context_dialog.raise_(); self.context_dialog.activateWindow()
        self.refresh_multi_timeframe_context(self.symbol.text().strip(), force=False)

    def show_events_window(self):
        self.events_dialog.show(); self.events_dialog.raise_(); self.events_dialog.activateWindow()

    def update_compact_account(self, info=None):
        if not info:
            self.compact_balance.setText("الرصيد: غير متاح")
            self.compact_equity.setText("Equity: غير متاح")
            self.compact_pnl.setText("العائم: غير متاح")
            self.compact_today.setText("نتيجة اليوم: غير متاحة")
            return
        currency = str(info.get("currency", "") or "")
        self.compact_balance.setText(f'الرصيد: {float(info.get("balance", 0) or 0):,.2f} {currency}')
        self.compact_equity.setText(f'Equity: {float(info.get("equity", 0) or 0):,.2f} {currency}')
        floating = float(info.get("floating_pnl", 0) or 0)
        self.compact_pnl.setText(f'العائم: {floating:+,.2f} {currency}')
        self.compact_pnl.setStyleSheet("padding:7px 9px; border:1px solid #283750; border-radius:6px; font-weight:700; color:" + ("#45b881" if floating >= 0 else "#f87171") + ";")
        today = info.get("today_realized_pnl")
        self.compact_today.setText(f'نتيجة اليوم: {float(today):+,.2f} {currency}' if today is not None else "نتيجة اليوم: غير متاحة")

    def update_positions_table(self, positions=None, available=False, currency=""):
        if not hasattr(self, "positions_table"):
            return
        rows = list(positions or []) if available else []
        self.positions_table.setRowCount(0)
        if not available:
            self.positions_table.setRowCount(1)
            self.positions_table.setItem(0, 0, QTableWidgetItem("بيانات المراكز غير متاحة"))
            self.positions_table.setSpan(0, 0, 1, 6)
            return
        for position in rows[:8]:
            row = self.positions_table.rowCount(); self.positions_table.insertRow(row)
            pnl = float(position.get("profit", 0) or 0) + float(position.get("swap", 0) or 0)
            values = (position.get("symbol", "—"), position.get("direction", "—"),
                      f'{float(position.get("volume", 0) or 0):g}',
                      f'{float(position.get("price_open", 0) or 0):.5f}',
                      f'{float(position.get("price_current", 0) or 0):.5f}', f'{pnl:+,.2f} {currency}')
            for col, value in enumerate(values):
                cell = QTableWidgetItem(str(value))
                if col == 5:
                    cell.setForeground(QColor("#2dd4bf" if pnl >= 0 else "#fb7185"))
                self.positions_table.setItem(row, col, cell)
        if not rows:
            self.positions_table.setRowCount(1)
            self.positions_table.setItem(0, 0, QTableWidgetItem("لا توجد مراكز مفتوحة"))
            self.positions_table.setSpan(0, 0, 1, 6)

    def on_bridge_tick(self, symbol, bid, ask, time_msc, received_local_label):
        # Track shadow outcomes directly on each EA-pushed tick, not only on the
        # one-second GUI refresh. This remains a local simulation; no broker orders.
        try:
            outcomes = update_open_signals(symbol, bid, ask, time_msc)
            self.log_shadow_outcomes(outcomes)
        except Exception as exc:
            self.add_log("خطأ سجل المحاكاة", f"تعذر تحديث نتائج الإشارات: {exc}")
        if symbol.strip().casefold() != self.symbol.text().strip().casefold():
            return
        digits = max(0, min(10, int(self.current_digits)))
        self.live_tick_label.setText(
            f"الجسر المباشر LIVE — {symbol} | Bid={bid:.{digits}f} | Ask={ask:.{digits}f} "
            f"| وقت Tick(ms)={time_msc} | استلام محلي={received_local_label}"
        )
        self.bridge_status_label.setText("متصل — وصلت تحديثات من Expert Advisor")

    def on_bridge_client_state(self, connected):
        if connected:
            self.bridge_status_label.setText("متصل — يستقبل الجسر المحلي بيانات من MT5 Expert Advisor")
        elif self.bridge_started:
            self.bridge_status_label.setText("الخادم المحلي جاهز؛ في انتظار EA أو إعادة اتصاله")

    def add_log(self, event, details):
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        row = self.log.rowCount(); self.log.insertRow(row)
        for col, value in enumerate((now, str(event), str(details))):
            self.log.setItem(row, col, QTableWidgetItem(value))
        self.log.scrollToBottom()
        try:
            record_event(event, details)
        except Exception:
            pass

    def load_saved_events(self):
        try:
            for event in recent_events(100):
                row = self.log.rowCount(); self.log.insertRow(row)
                values = (event.get("created_at", ""), event.get("event", ""), event.get("details", ""))
                for col, value in enumerate(values):
                    self.log.setItem(row, col, QTableWidgetItem(str(value)))
            self.log.scrollToBottom()
        except Exception as exc:
            self.add_log("تنبيه قاعدة البيانات", exc)

    def refresh_market_silent(self):
        if self.symbol.text().strip():
            self.refresh_market(silent=True)

    def toggle_auto_refresh(self):
        if self.timer.isActive():
            self.timer.stop(); self.auto_refresh.setText(translate("تشغيل التحديث التلقائي", self.app_settings.get("language", "ar")))
            self.add_log("التحديث التلقائي", "تم الإيقاف يدويًا.")
        else:
            self.timer.start(1000); self.auto_refresh.setText(translate("إيقاف التحديث التلقائي", self.app_settings.get("language", "ar")))
            self.add_log("التحديث التلقائي", "تم التشغيل: كل ثانية.")

    def refresh_market(self, silent=False):
        symbol = self.symbol.text().strip()
        if not symbol:
            if not silent:
                QMessageBox.warning(self, "Symbol required", "أدخل رمز الأداة كما يظهر في MT5.")
            return
        result = self.mt5.connect_and_read(symbol, self.timeframe.currentText())
        if not result["ok"]:
            self._check_market_connection(False)
            self.status.setText("DISCONNECTED")
            self.status.setStyleSheet("font-weight: 700; color: #d9534f;")
            self.account_label.setText("تعذر الاتصال")
            self.last_account = None
            self.update_compact_account({})
            self.update_positions_table([], available=False)
            for value_label in (self.login_label, self.balance_label, self.equity_label, self.floating_pnl_label,
                                self.today_pnl_label, self.positions_count_label, self.margin_label, self.positions_label,
                                self.server_label):
                value_label.setText("غير متاح — انقطع الاتصال")
            unavailable_summary = "انقطع اتصال MT5؛ بيانات الحساب والأرباح المعروضة غير متاحة حاليًا. أعد الاتصال قبل الاعتماد على أي قيمة."
            if self.recommendation_window is not None:
                self.recommendation_window.set_account_summary(unavailable_summary)
            if self.chart_window is not None and hasattr(self.chart_window, "set_account_summary"):
                self.chart_window.set_account_summary(unavailable_summary)
            self.updated_label.setText(datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S (محلي) — فشلت القراءة"))
            self.raw_tick_label.setText("غير متاح")
            self.corrected_tick_label.setText("غير متاح")
            self.analysis_time_label.setText("لم يُحسب التحليل")
            self.market_state.setText("حالة الأسعار: تعذر الاتصال بـ MT5")
            self.market_state.setStyleSheet("font-weight: 700; color: #d9534f; padding: 3px;")
            try:
                self.terminal_chart.set_data([], symbol, self.timeframe.currentText(), self.current_digits)
                self.terminal_chart.set_signal_levels(None)
            except (AttributeError, RuntimeError):
                pass
            if not silent:
                self.add_log("خطأ اتصال", result["error"])
            self.signal_summary.setText("تعذر قراءة السوق. افتح MT5 وسجّل الدخول وتأكد من ظهور الرمز في Market Watch.")
            self.approve_btn.setEnabled(False); self.reject_btn.setEnabled(False)
            self.pending_signal = None
            self.update_recommendation_window(self.signal_summary.text(), None)
            return

        # Prefer the EA-pushed quote only when it is recent and not older than
        # the terminal Python API quote. Otherwise retain the API quote as fallback.
        data_source = "MT5 Python API (احتياطي)"
        bridge_payload = self.bridge.get_latest(symbol, max_age_seconds=3.0) if self.bridge_started else None
        api_tick = result.get("tick")
        if bridge_payload is not None:
            bridge_tick = bridge_payload.get("tick")
            try:
                api_time_msc = int(getattr(api_tick, "time_msc", 0) or 0)
                bridge_time_msc = int(getattr(bridge_tick, "time_msc", 0) or 0)
            except (TypeError, ValueError):
                api_time_msc, bridge_time_msc = 0, 0
            if bridge_tick is not None and bridge_time_msc >= api_time_msc:
                result["tick"] = bridge_tick
                result["read_received_epoch"] = bridge_payload["received_epoch"]
                result["read_received_local_label"] = bridge_payload["received_local_label"]
                data_source = "Apex Price Bridge (MT5 EA)"
        result["data_source"] = data_source

        self._check_market_connection(True)
        info = result.get("account") or {}
        self.last_account = dict(info)
        mode = info.get("trade_mode", "UNKNOWN")
        self.status.setText("CONNECTED — READ ONLY")
        self.status.setStyleSheet("font-weight: 700; color: #45b881;")
        mode_ar = {"DEMO": "تجريبي DEMO", "REAL": "حقيقي REAL — قراءة فقط",
                   "CONTEST": "مسابقة CONTEST", "UNKNOWN": "غير معروف"}.get(mode, mode)
        self.account_label.setText(mode_ar)
        self.login_label.setText(str(info.get("login", "—")))
        currency = info.get("currency", "")
        self.balance_label.setText(f'{info.get("balance", 0):,.2f} {currency}')
        self.equity_label.setText(f'{info.get("equity", 0):,.2f} {currency}')
        floating = float(info.get("floating_pnl", 0.0) or 0.0)
        self.floating_pnl_label.setText(f'{floating:+,.2f} {currency}')
        self.floating_pnl_label.setStyleSheet("font-weight: 700; color: #45b881;" if floating >= 0 else "font-weight: 700; color: #f87171;")
        today_pnl = info.get("today_realized_pnl")
        self.today_pnl_label.setText((f'{float(today_pnl):+,.2f} {currency}' if today_pnl is not None else "غير متاح من سجل الوسيط"))
        self.today_pnl_label.setStyleSheet(("font-weight: 700; color: #45b881;" if float(today_pnl or 0) >= 0 else "font-weight: 700; color: #f87171;") if today_pnl is not None else "color: #d99b48;")
        positions = info.get("open_positions", []) or []
        self.update_compact_account(info)
        self.update_positions_table(positions, bool(info.get("positions_available", False)), currency)
        self.positions_count_label.setText(str(len(positions)) if info.get("positions_available", False) else "غير متاح")
        margin = float(info.get("margin", 0.0) or 0.0); free_margin = float(info.get("margin_free", 0.0) or 0.0)
        self.margin_label.setText(f'{margin:,.2f} / {free_margin:,.2f} {currency}')
        self.positions_label.setText(self._format_positions(positions, currency, info.get("positions_available", False)))
        self.server_label.setText(str(info.get("server", "—")))
        if info.get("positions_available", False):
            self._check_position_alerts(positions)
        account_summary = self.account_summary_text(info)
        if self.recommendation_window is not None:
            self.recommendation_window.set_account_summary(account_summary)
        if self.chart_window is not None and hasattr(self.chart_window, "set_account_summary"):
            self.chart_window.set_account_summary(account_summary)
        self.source_label.setText(data_source)
        self.updated_label.setText(str(result.get("read_received_local_label", "غير متاح")))
        self.current_digits = int((result.get("symbol_info") or {}).get("digits", 2))
        try:
            self.terminal_chart.set_data(
                result.get("bars"), symbol, self.timeframe.currentText(), self.current_digits
            )
        except (AttributeError, RuntimeError):
            pass

        # Update the independent multi-timeframe context no more than every 30 s
        # (or immediately when the symbol changes / user presses its button).
        self.refresh_multi_timeframe_context(symbol, force=False)

        selected_tick = result.get("tick")
        selected_offset = (getattr(selected_tick, "broker_offset_seconds", None)
                           if data_source == "Apex Price Bridge (MT5 EA)" else None)
        freshness = self.clock_tracker.update(
            selected_tick, broker_offset_seconds=selected_offset
        )
        # Fallback path: evaluate outcomes from the Python API quote. If the EA
        # has already processed the same tick, the journal deduplicates by time_msc.
        if freshness["is_fresh"]:
            try:
                current_tick = result.get("tick")
                if current_tick is not None:
                    outcomes = update_open_signals(
                        symbol, getattr(current_tick, "bid", 0), getattr(current_tick, "ask", 0),
                        getattr(current_tick, "time_msc", 0))
                    self.log_shadow_outcomes(outcomes)
            except Exception as exc:
                if not silent:
                    self.add_log("خطأ سجل المحاكاة", f"تعذر تحديث نتائج الإشارات: {exc}")
        self.raw_tick_label.setText(str(freshness.get("raw_time_label", "غير متاح")))
        self.corrected_tick_label.setText(str(freshness.get("corrected_local_label", "لم يُحسم بعد")))
        if freshness["is_fresh"]:
            self.market_state.setText("حالة الأسعار: LIVE — " + freshness["message"])
            self.market_state.setStyleSheet("font-weight: 700; color: #45b881; padding: 3px;")
            self.status.setText("CONNECTED — LIVE DATA")
            self.status.setStyleSheet("font-weight: 700; color: #45b881;")
            self.bridge_status_label.setText("الجسر يستقبل بيانات حديثة" if bridge_payload is not None else "مصدر الأسعار: MT5 Python API")
        elif freshness["status"] in ("checking_clock",):
            self.market_state.setText("حالة الأسعار: جارٍ التحقق — " + freshness["message"])
            self.market_state.setStyleSheet("font-weight: 700; color: #d99b48; padding: 3px;")
            self.status.setText("CONNECTED — VERIFYING FEED")
            self.status.setStyleSheet("font-weight: 700; color: #d99b48;")
            self.bridge_status_label.setText("لم يتم تأكيد وصول أسعار حديثة بعد")
        else:
            self.market_state.setText("حالة الأسعار: غير مؤكدة/متوقفة — " + freshness["message"])
            self.market_state.setStyleSheet("font-weight: 700; color: #d9534f; padding: 3px;")
            self.status.setText("CONNECTED — NO LIVE DATA")
            self.status.setStyleSheet("font-weight: 700; color: #d9534f;")
            self.bridge_status_label.setText("توقف تدفق الأسعار — لا تعتمد على البيانات القديمة")

        signal = make_demo_signal(
            symbol, self.timeframe.currentText(), result.get("tick"), result.get("bars"),
            digits=(result.get("symbol_info") or {}).get("digits", 5)
        )
        # Higher-timeframe context now participates in the decision, rather than
        # being a decorative text panel only. Missing/conflicting context fails closed.
        context = (self.last_multi_timeframe_analysis
                   if self.last_context_symbol.casefold() == symbol.casefold() else None)
        signal = apply_multi_timeframe_gate(signal, context)
        # Optional read-only comparison with the MT5 chart indicator snapshot.
        # If the indicator disagrees, fail closed to WAIT; never treat its file as an order.
        common_files = Path(os.environ.get("APPDATA", str(Path.home() / "AppData" / "Roaming"))) / "MetaQuotes" / "Terminal" / "Common" / "Files"
        tf_label = self.timeframe.currentText().strip().upper()
        indicator_file = common_files / f"ApexAlphaSignal_{symbol.replace('.', '_').replace('#', '_').replace('/', '_').replace(chr(92), '_')}_{tf_label}.json"
        try:
            snap = read_indicator_snapshot(
                indicator_file, expected_symbol=symbol, expected_timeframe=tf_label,
                max_age_seconds=7200,
            )
            bot_direction = signal.get("direction", "WAIT")
            indicator_direction = snap["direction"]
            level_text = (f"MT5 مؤشر: {indicator_direction} | Entry {snap['entry']:.{self.current_digits}f} | "
                          f"SL {snap['stop_loss']:.{self.current_digits}f} | TP1 {snap['tp1']:.{self.current_digits}f} | TP2 {snap['tp2']:.{self.current_digits}f}"
                          if indicator_direction in ("BUY", "SELL") else "MT5 مؤشر: WAIT — لا توجد مستويات دخول معتمدة")
            if bot_direction != indicator_direction:
                signal["direction"] = "WAIT"
                signal["entry"] = signal["stop_loss"] = signal["take_profit"] = None
                signal.setdefault("warnings", []).append(
                    f"اختلاف بين محرك البوت ({bot_direction}) ومؤشر MT5 ({indicator_direction}); تم فرض WAIT للمراجعة اليدوية.")
                signal["summary"] += (f"\n\n{level_text}\nمقارنة الربط: اختلاف الإشارتين — تم إيقاف التوصية الاتجاهية مؤقتًا.")
            else:
                signal["summary"] += (f"\n\n{level_text}\nمقارنة الربط: اتجاه المؤشر والبوت متوافق حاليًا؛ هذا توافق قواعد وليس ضمان ربح.")
        except (IndicatorSnapshotError, OSError) as exc:
            # No snapshot is not a fatal app error, but explicitly disclose that the indicator isn't linked.
            signal["summary"] += f"\n\nربط مؤشر MT5: غير متاح/قديم ({exc}). المؤشر غير مستخدم لتأكيد التوصية."
        # Diagnostic comparison: MT5's newest Bid/Ask, last candle close, quote age,
        # and read time. Candle close and Bid can differ on symbols/charts that use
        # Last-price charting, so this is diagnostic rather than an automatic error.
        try:
            tick = result.get("tick")
            digits = int((result.get("symbol_info") or {}).get("digits", 5))
            bid = float(tick.bid)
            ask = float(tick.ask)
            bars = result.get("bars")
            last_close = float(bars[-1]["close"]) if bars is not None and len(bars) else None
            diff_text = (f" | Bid−إغلاق آخر شمعة: {bid - last_close:.{digits}f}"
                         if last_close is not None else "")
            age_text = (f"{max(0, int(freshness['age_seconds']))} ث" if freshness.get("age_seconds") is not None else "غير معروف")
            signal["summary"] += (f"\n\nتشخيص التحديث: Bid={bid:.{digits}f} | Ask={ask:.{digits}f}"
                                  f" | عمر tick={age_text}{diff_text}\n"
                                  "ملاحظة: للمقارنة الدقيقة، قارن Bid/Ask في Market Watch في اللحظة نفسها؛ قد يختلف إغلاق الشمعة عن السعر الحالي حسب إعداد رسم الرمز.")
        except Exception:
            pass
        signal = gate_signal(signal, freshness)
        # Informational position-size estimate only. Missing/invalid broker tick
        # economics fail closed and never prevent market analysis from displaying.
        signal_info = result.get("symbol_info") or {}
        if signal.get("direction") in ("BUY", "SELL") and signal.get("entry") is not None and signal.get("stop_loss") is not None:
            try:
                risk_estimate = calculate_position_size(
                    balance=float(info.get("balance", 0.0)),
                    risk_percent=float(self.app_settings.get("risk_percent", 1.0)),
                    entry=float(signal["entry"]), stop_loss=float(signal["stop_loss"]),
                    tick_size=float(signal_info.get("trade_tick_size", 0.0)),
                    tick_value=float(signal_info.get("trade_tick_value", 0.0)),
                    volume_min=float(signal_info.get("volume_min", 0.0)),
                    volume_max=float(signal_info.get("volume_max", 0.0)),
                    volume_step=float(signal_info.get("volume_step", 0.0)),
                )
                signal["risk_estimate"] = risk_estimate
                if risk_estimate.get("ok"):
                    signal["summary"] += (
                        f"\n\nتقدير المخاطر (معلوماتي فقط): حجم تقريبي {risk_estimate['volume']} لوت؛ "
                        f"مخاطرة تقديرية {risk_estimate['estimated_risk']:.2f} {currency} "
                        f"({risk_estimate['risk_percent_actual']:.3f}% من الرصيد).\n"
                        "التقدير يعتمد على قيمة tick التي يعرضها الوسيط ولا يشمل الانزلاق أو الرسوم أو فجوات الأسعار."
                    )
                else:
                    signal["summary"] += "\n\nلم يُقترح حجم: " + str(risk_estimate.get("reason", "بيانات المخاطر غير كافية"))
            except (ValueError, TypeError, OverflowError) as exc:
                signal["risk_estimate"] = {"ok": False, "reason": str(exc)}
                signal["summary"] += "\n\nحساب حجم المخاطر غير متاح: تحقق من tick size/value وحدود الحجم لدى الوسيط."
        journal_record = None
        if freshness["is_fresh"] and signal.get("direction") in ("BUY", "SELL"):
            current_tick = result.get("tick")
            try:
                journal_record = record_shadow_signal(
                    signal, symbol, self.timeframe.currentText(), signal.get("signal_bar_time"),
                    entry_tick_time_msc=getattr(current_tick, "time_msc", 0) if current_tick is not None else 0,
                    source=data_source,
                )
                if journal_record:
                    signal["journal_id"] = journal_record["id"]
                    signal["journal_decision"] = journal_record["user_decision"]
                    if journal_record["created"]:
                        self.add_log(
                            "إشارة افتراضية مسجلة",
                            f'{symbol}/{self.timeframe.currentText()} {signal["direction"]} — '
                            f'دخول={signal.get("entry")}، وقف={signal.get("stop_loss")}، هدف={signal.get("take_profit")}. '
                            "تتبّع ظلّي لا يرسل أوامر للوسيط.")
                        signal_key = f'{symbol}|{self.timeframe.currentText()}|{signal.get("direction")}|{signal.get("signal_bar_time")}'
                        if signal_key != self._last_announced_signal_key:
                            self._last_announced_signal_key = signal_key
                            if self.app_settings.get("voice_enabled") and self.app_settings.get("announce_signals"):
                                self._speak_with_preferences(self._signal_announcement(signal))
                        if self.app_settings.get("ai_enabled") and self.app_settings.get("ai_auto_analyze_signals"):
                            self._request_ai_signal_analysis(signal)
            except Exception as exc:
                if not silent:
                    self.add_log("خطأ سجل الإشارات", str(exc))
        analysis_finished_local = datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S (محلي)")
        self.analysis_time_label.setText(analysis_finished_local)
        self.pending_signal = (
            signal if freshness["is_fresh"] and signal.get("direction") in ("BUY", "SELL")
            and journal_record is not None and journal_record.get("user_decision") == "PENDING"
            else None
        )
        timing_diagnostics = (
            f'وقت Tick من MT5 (UTC): {freshness.get("raw_time_label", "غير متاح")}\n'
            f'عرض الوقت المحلي لنفس Tick: {freshness.get("corrected_local_label", "غير متاح")}\n'
            f'وقت استلام البيانات محليًا: {result.get("read_received_local_label", "غير متاح")}\n'
            f'وقت انتهاء حساب التحليل محليًا: {analysis_finished_local}\n\n'
        )
        journal_note = ""
        if journal_record:
            decision_labels = {"PENDING": "لم يُتخذ قرار يدوي بعد", "APPROVED": "سُجلت موافقة المحاكاة",
                               "REJECTED": "رُفضت يدويًا؛ يستمر تقييمها الظلّي لأغراض القياس"}
            journal_note = (f'\n\nسجل الإشارة المحلي #{journal_record["id"]}: '
                            f'{decision_labels.get(journal_record["user_decision"], journal_record["user_decision"])}. '
                            "النتيجة الافتراضية لا تمثل ربحًا/خسارة بالدولار.")
        self.latest_analysis_signal = dict(signal)
        try:
            self.terminal_chart.set_signal_levels(signal)
        except (AttributeError, RuntimeError):
            pass
        self.signal_summary.setText(timing_diagnostics + signal["summary"] + journal_note)
        self.update_recommendation_window(timing_diagnostics + signal["summary"] + journal_note, signal)
        if self.chart_window is not None:
            try:
                if self.chart_window.chart.symbol.casefold() == symbol.casefold():
                    self.chart_window.chart.set_signal_levels(signal)
            except RuntimeError:
                self.chart_window = None
        has_actionable_signal = self.pending_signal is not None
        self.approve_btn.setEnabled(has_actionable_signal)
        self.reject_btn.setEnabled(has_actionable_signal)
        self.update_recommendation_window(timing_diagnostics + signal["summary"] + journal_note, signal)
        if not silent:
            self.add_log("قراءة السوق", f'{symbol} / {self.timeframe.currentText()} — {freshness["status"]}; {freshness["message"]}')

    def _format_positions(self, positions, currency, available=True):
        if not available:
            return "تعذر قراءة المراكز المفتوحة من MT5؛ لا يُفترض أن العدد صفر."
        if not positions:
            return "لا توجد مراكز فعلية مفتوحة."
        lines = []
        for p in positions[:8]:
            pnl = float(p.get("profit", 0.0) or 0.0) + float(p.get("swap", 0.0) or 0.0)
            lines.append(f'{p.get("direction", "—")} {p.get("symbol", "—")} | حجم {p.get("volume", 0):g} | '
                         f'عائم {pnl:+,.2f} {currency} | تذكرة {p.get("ticket", "—")}')
        if len(positions) > 8:
            lines.append(f'... و{len(positions)-8} مراكز أخرى')
        return "\n".join(lines)

    def account_summary_text(self, info=None):
        info = info or self.last_account or {}
        currency = info.get("currency", "")
        pnl = float(info.get("floating_pnl", 0.0) or 0.0)
        today = info.get("today_realized_pnl")
        today_text = f'{float(today):+,.2f} {currency}' if today is not None else "غير متاح"
        return (f'الرصيد {float(info.get("balance", 0) or 0):,.2f} {currency} | '
                f'Equity {float(info.get("equity", 0) or 0):,.2f} {currency} | '
                f'عائم {pnl:+,.2f} {currency} | اليوم المحقق {today_text} | '
                f'مراكز فعلية مفتوحة: {int(info.get("positions_count", 0) or 0) if info.get("positions_available", False) else "غير متاح"}')

    def _check_market_connection(self, connected):
        previous = self._was_market_connected
        self._was_market_connected = bool(connected)
        if previous is None or previous == bool(connected):
            return
        if not (self.app_settings.get("voice_enabled") and self.app_settings.get("announce_connection")):
            return
        language = self._announcement_language()
        if connected:
            messages = {"ar":"عاد الاتصال بمنصة التداول.", "en":"The trading terminal connection is restored.",
                        "fr":"La connexion au terminal de trading est rétablie.", "ru":"Соединение с торговым терминалом восстановлено."}
        else:
            messages = {"ar":"تنبيه: انقطع الاتصال بمنصة التداول.", "en":"Warning: the trading terminal connection was lost.",
                        "fr":"Attention : la connexion au terminal de trading a été perdue.", "ru":"Внимание: соединение с торговым терминалом потеряно."}
        self._speak_with_preferences(messages.get(language, messages["ar"]))

    def _check_position_alerts(self, positions):
        current = {int(p.get("ticket", 0)): p for p in (positions or []) if int(p.get("ticket", 0) or 0) > 0}
        if self._last_position_ids is None:
            self._last_position_ids = set(current)
            if current and self.app_settings.get("voice_enabled") and self.app_settings.get("announce_positions"):
                language = self._announcement_language()
                for position in current.values():
                    self._speak_with_preferences(self._position_announcement(position, opened=True, language=language))
            return
        previous = self._last_position_ids
        opened = set(current) - previous
        closed = previous - set(current)
        self._last_position_ids = set(current)
        if not (self.app_settings.get("voice_enabled") and self.app_settings.get("announce_positions")):
            return
        language = self._announcement_language()
        for ticket in opened:
            self._speak_with_preferences(self._position_announcement(current[ticket], opened=True, language=language))
        for ticket in closed:
            messages = {"ar":f'تم إغلاق المركز رقم {ticket} في MT5.', "en":f'MT5 position {ticket} has closed.',
                        "fr":f'La position MT5 {ticket} est clôturée.', "ru":f'Позиция MT5 {ticket} закрыта.'}
            self._speak_with_preferences(messages.get(language, messages["ar"]))

    @staticmethod
    def _position_announcement(position, opened=True, language="ar"):
        side = position.get("direction", "")
        symbol = position.get("symbol", "")
        if language == "en": return f'You have an actual {side} position open on {symbol} in MT5.'
        if language == "fr": return f'Une position réelle {side} sur {symbol} est ouverte dans MT5.'
        if language == "ru": return f'В MT5 открыта реальная позиция {side} по {symbol}.'
        return f'لديك الآن صفقة فعلية مفتوحة على {symbol} باتجاه {"شراء" if side == "BUY" else "بيع"} في MT5.'

    def _announcement_language(self):
        preference = self.app_settings.get("voice_language", "auto")
        return preference if preference in ("ar", "en", "fr", "ru") else self.app_settings.get("language", "ar")

    def _signal_announcement(self, signal):
        symbol = signal.get("symbol", "instrument")
        direction = signal.get("direction", "WAIT")
        entry = signal.get("entry")
        lang = self._announcement_language()
        if lang == "en":
            price = f", simulated entry {entry}" if entry is not None else ""
            return f'A new {direction} recommendation appeared for {symbol}{price}. No trade was placed. Review risk levels before making any decision.'
        if lang == "fr":
            price = f", entrée simulée {entry}" if entry is not None else ""
            return f'Une nouvelle recommandation {direction} est apparue sur {symbol}{price}. Aucune transaction n’a été exécutée. Vérifiez les risques avant toute décision.'
        if lang == "ru":
            price = f", расчётный вход {entry}" if entry is not None else ""
            return f'Появилась новая рекомендация {direction} по {symbol}{price}. Сделка не открывалась. Проверьте риски перед принятием решения.'
        price = f'، سعر الدخول الافتراضي {entry}' if entry is not None else ""
        return f'ظهرت توصية {"شراء" if direction == "BUY" else "بيع"} محتملة على {symbol}{price}. لم يتم فتح صفقة حقيقية. راجع مستويات المخاطرة قبل اتخاذ القرار.'

    def show_settings_window(self):
        if self.settings_dialog is not None:
            try:
                self.settings_dialog.showNormal()
                self.settings_dialog.raise_()
                self.settings_dialog.activateWindow()
                return
            except RuntimeError:
                self.settings_dialog = None
        try:
            self.settings_dialog = SettingsDialog(self)
            self.settings_dialog.settings_saved.connect(self.apply_settings)
            self.settings_dialog.finished.connect(lambda *_: setattr(self, "settings_dialog", None))
            self.settings_dialog.show()
            self.settings_dialog.raise_()
            self.settings_dialog.activateWindow()
        except Exception as exc:
            self.settings_dialog = None
            self.add_log("خطأ فتح الإعدادات", str(exc))
            QMessageBox.critical(self, "تعذر فتح الإعدادات", f"حدث خطأ أثناء فتح نافذة الإعدادات:\n{exc}")

    def apply_settings(self, settings):
        self.app_settings = save_settings(settings)
        app = QApplication.instance()
        if app is not None:
            apply_theme(app, self.app_settings.get("theme", "dark"))
        language = self.app_settings.get("language", "ar")
        translate_widget_tree(self, language)
        for child_window in (self.chart_window, self.recommendation_window, self.assistant_window, self.academy_window, self.account_dialog, self.context_dialog, self.events_dialog, self.journal_dialog, self.market_reading_dialog):
            if child_window is not None:
                try: translate_widget_tree(child_window, language)
                except RuntimeError: pass
        self.add_log("الإعدادات", f'تم تطبيق اللغة {self.app_settings.get("language", "ar")} والمظهر {self.app_settings.get("theme", "dark")}.')

    def show_assistant_window(self):
        if self.assistant_window is not None:
            try:
                self.assistant_window.show(); self.assistant_window.raise_(); self.assistant_window.activateWindow()
                return
            except RuntimeError:
                self.assistant_window = None
        self.assistant_window = AssistantWindow(self.ai_context_text, self.speak_text, self.show_settings_window, self)
        translate_widget_tree(self.assistant_window, self.app_settings.get("language", "ar"))
        self.assistant_window.finished.connect(lambda *_: setattr(self, "assistant_window", None))
        self.assistant_window.show(); self.assistant_window.raise_(); self.assistant_window.activateWindow()

    def show_strategy_academy(self):
        """Open the local Strategy Academy without changing the trading engine."""
        if self.academy_window is not None:
            try:
                self.academy_window.showNormal()
                self.academy_window.raise_()
                self.academy_window.activateWindow()
                return
            except RuntimeError:
                self.academy_window = None
        try:
            self.academy_window = StrategyAcademyWindow(self)
            translate_widget_tree(self.academy_window, self.app_settings.get("language", "ar"))
            self.academy_window.finished.connect(lambda *_: setattr(self, "academy_window", None))
            self.academy_window.show()
            self.academy_window.raise_()
            self.academy_window.activateWindow()
        except Exception as exc:
            self.academy_window = None
            self.add_log("خطأ فتح أكاديمية الاستراتيجيات", str(exc))
            QMessageBox.critical(self, "تعذر فتح أكاديمية الاستراتيجيات", f"حدث خطأ أثناء فتح نافذة الأكاديمية:\n{exc}")

    def ai_context_text(self):
        signal = self.latest_analysis_signal or {}
        info = self.last_account or {}
        positions = info.get("open_positions", []) or []
        position_summary = "; ".join(
            f'{p.get("direction")} {p.get("symbol")} volume={p.get("volume")} floating_pnl={float(p.get("profit", 0) or 0) + float(p.get("swap", 0) or 0):.2f} {info.get("currency", "")}'
            for p in positions[:10]
        ) or ("No open positions reported." if info.get("positions_available", False) else "Open-position data unavailable from MT5.")
        return (f"Symbol: {self.symbol.text().strip()}\nTimeframe: {self.timeframe.currentText()}\n"
                f"Signal direction: {signal.get('direction', 'WAIT')}\nSignal summary: {signal.get('summary', 'No completed analysis yet.')}\n"
                f"Balance: {info.get('balance', 'unavailable')} {info.get('currency', '')}\n"
                f"Equity: {info.get('equity', 'unavailable')} {info.get('currency', '')}\n"
                f"Floating P/L: {info.get('floating_pnl', 'unavailable')} {info.get('currency', '')}\n"
                f"Today's realized P/L UTC: {info.get('today_realized_pnl', 'unavailable')}\nPositions: {position_summary}\n"
                "Application mode: READ ONLY; no trade execution enabled.")

    def _speak_with_preferences(self, text, settings=None):
        settings = settings or self.app_settings
        if not settings.get("voice_enabled", True):
            return False
        interface_language = settings.get("language", "ar")
        voice_language = resolve_voice_language(settings.get("voice_language", "auto"), text, interface_language)
        return self.voice.speak(text, voice_language, True)

    def speak_text(self, text):
        settings = self.app_settings
        if settings.get("voice_enabled"):
            spoken = str(text or "")
            if len(spoken) > 750:
                spoken = spoken[:750] + "…"
            self._speak_with_preferences(spoken, settings=settings)

    def _request_ai_signal_analysis(self, signal):
        signal_id = int(signal.get("journal_id", 0) or 0)
        if not signal_id or signal_id in self._auto_ai_signal_keys:
            return
        self._auto_ai_signal_keys.add(signal_id)
        api_key = get_api_key()
        if not api_key:
            self.add_log("تحليل AI", "التحليل التلقائي مفعّل لكن مفتاح OpenAI غير مُعد؛ افتح الإعدادات.")
            return
        settings = dict(self.app_settings)
        context = str(signal.get("summary", ""))
        def worker():
            try:
                response = chat_completion(api_key, settings.get("ai_model", "gpt-4o-mini"), settings.get("ai_base_url", "https://api.openai.com/v1"), [
                    {"role":"system", "content":"أنت مساعد تحليل فني. قيّم الإشارة بشكل متحفظ، لا تتنبأ بيقين ولا تقترح تنفيذًا تلقائيًا. اكتب بالعربية، اذكر عوامل التأييد والتعارض وحدود البيانات، ولا تدّعِ أن صفقة حقيقية فُتحت."},
                    {"role":"user", "content":f'حلّل الإشارة التالية كمعلومة مساعدة فقط، واذكر ما ينبغي التحقق منه قبل أي قرار يدوي:\n{context}'}])
                self.ui_signals.ai_analysis_done.emit(str(signal_id), response)
            except Exception as exc:
                self.ui_signals.ai_analysis_done.emit(str(signal_id), "تعذر تحليل AI: " + str(exc))
        threading.Thread(target=worker, daemon=True, name="ApexSignalAI").start()

    def apply_ai_signal_analysis(self, signal_id, response):
        text = self.signal_summary.text() + "\n\nمراجعة OpenAI (مساعدة فقط):\n" + str(response)
        self.signal_summary.setText(text)
        signal = self.latest_analysis_signal or self.pending_signal
        self.update_recommendation_window(text, signal)
        self.add_log("مراجعة AI", f'اكتملت مراجعة مساعدة للإشارة #{signal_id}; لا تنفّذ أوامر تداول.')
        if self.assistant_window is not None:
            self.assistant_window.transcript.appendPlainText("\nمراجعة إشارة: " + str(response))

    def show_recommendation_window(self):
        if self.recommendation_window is None:
            self.recommendation_window = RecommendationWindow(self)
            translate_widget_tree(self.recommendation_window, self.app_settings.get("language", "ar"))
            self.recommendation_window.finished.connect(self._on_recommendation_window_closed)
            self.recommendation_window.set_recommendation(self.signal_summary.text(), self.latest_analysis_signal or self.pending_signal)
            if self.last_account:
                self.recommendation_window.set_account_summary(self.account_summary_text(self.last_account))
        self.recommendation_window.show()
        self.recommendation_window.raise_()
        self.recommendation_window.activateWindow()

    def update_recommendation_window(self, text, signal=None):
        if hasattr(self, "recommendation_panel"):
            try:
                self.recommendation_panel.set_recommendation(text, signal)
            except RuntimeError:
                pass
        if self.recommendation_window is not None:
            try:
                self.recommendation_window.set_recommendation(text, signal)
            except RuntimeError:
                self.recommendation_window = None

    def _on_recommendation_window_closed(self, *_):
        self.recommendation_window = None

    def show_chart_window(self):
        symbol = self.symbol.text().strip() or "BTCUSD"
        timeframe = self.timeframe.currentText()
        if self.chart_window is not None:
            try:
                self.chart_window.set_selection(symbol, timeframe)
                self.chart_window.show(); self.chart_window.raise_(); self.chart_window.activateWindow()
                return
            except RuntimeError:
                self.chart_window = None
        self.chart_window = ChartWindow(self.mt5, symbol, timeframe, self)
        translate_widget_tree(self.chart_window, self.app_settings.get("language", "ar"))
        self.chart_window.finished.connect(self._on_chart_window_closed)
        self.chart_window.chart.set_signal_levels(self.latest_analysis_signal)
        if self.last_account and hasattr(self.chart_window, "set_account_summary"):
            self.chart_window.set_account_summary(self.account_summary_text(self.last_account))
        self.chart_window.show()

    def _on_chart_window_closed(self, *_):
        self.chart_window = None

    def refresh_multi_timeframe_context(self, symbol, force=False):
        symbol = str(symbol or "").strip()
        if not symbol:
            self.context_summary.setText("أدخل رمز الأداة أولًا.")
            return
        now = time.monotonic()
        if symbol.casefold() != self.last_context_symbol.casefold():
            # Never re-use a different symbol's timeframe state after a symbol change.
            self.last_multi_timeframe_analysis = None
        if (not force and symbol.casefold() == self.last_context_symbol.casefold()
                and now - self.last_context_refresh < 30):
            return
        self.context_refresh_btn.setEnabled(False)
        self.context_summary.setText("جارٍ جلب شموع M15 وH1 وH4 المغلقة...")
        try:
            response = self.mt5.read_context_frames(symbol, ("M15", "H1", "H4"), count=120)
            if not response.get("ok"):
                self.last_multi_timeframe_analysis = None
                self.context_summary.setText("تعذر تحديث السياق متعدد الأطر: " + str(response.get("error", "خطأ غير معروف")))
                self.last_context_refresh = now - 20  # retry soon rather than waiting a full interval
                self.last_context_symbol = symbol
                return
            analysis = analyze_multi_timeframe(response.get("frames", {}))
            self.last_multi_timeframe_analysis = analysis
            lines = [f"{symbol} — {analysis['overall']}"]
            for tf in ("M15", "H1", "H4"):
                item = analysis["timeframes"].get(tf, {})
                if item.get("ok"):
                    lines.append(
                        f"{tf}: {item['bias']} | RSI(14)={item['rsi14']:.1f} | "
                        f"{item['regime']} | ATR={item['atr14']:.5f}"
                    )
                else:
                    lines.append(f"{tf}: {item.get('message', 'بيانات غير متاحة')}")
            stamp = datetime.now().astimezone().strftime("%H:%M:%S محليًا")
            lines.append(f"آخر تحديث للسياق: {stamp} — {analysis['note']}")
            self.context_summary.setText("\n".join(lines))
            self.context_summary.setStyleSheet("color: #b8c9e8; padding: 4px;")
            self.last_context_refresh = now
            self.last_context_symbol = symbol
        except Exception as exc:
            self.last_multi_timeframe_analysis = None
            self.context_summary.setText(f"تعذر حساب السياق متعدد الأطر: {exc}")
            self.last_context_refresh = now - 20
            self.last_context_symbol = symbol
        finally:
            self.context_refresh_btn.setEnabled(True)

    def approve_simulation(self):
        if not self.pending_signal:
            return
        signal = self.pending_signal
        changed = set_user_decision(signal.get("journal_id", 0), "APPROVED")
        if not changed:
            self.add_log("تنبيه محاكاة", "لم يُسجَّل القرار؛ ربما حُسمت هذه الإشارة سابقًا.")
            self.pending_signal = None
            self.approve_btn.setEnabled(False); self.reject_btn.setEnabled(False)
            return
        self.add_log("موافقة محاكاة", f'المستخدم وافق على تقييم الإشارة #{signal["journal_id"]} لـ {signal["symbol"]}. لم يُرسل أي أمر للوسيط.')
        self.signal_summary.setText("تم تسجيل الموافقة على التقييم الافتراضي فقط. تُتابَع نتيجة الإشارة في السجل؛ لا توجد صفقة حقيقية.")
        self.update_recommendation_window(self.signal_summary.text(), signal)
        self.pending_signal = None
        self.approve_btn.setEnabled(False); self.reject_btn.setEnabled(False)
        self.update_recommendation_window(self.signal_summary.text(), signal)
        if self.journal_dialog is not None:
            self.refresh_journal_dialog()

    def reject_signal(self):
        if self.pending_signal:
            signal = self.pending_signal
            changed = set_user_decision(signal.get("journal_id", 0), "REJECTED")
            if changed:
                self.add_log("رفض الإشارة", f'تم رفض الإشارة #{signal["journal_id"]} لـ {signal["symbol"]} يدويًا. ستظل نتيجتها الظلّية قيد التقييم، دون أوامر تداول.')
            else:
                self.add_log("رفض الإشارة", f'تعذر تسجيل قرار الإشارة #{signal.get("journal_id", "—")}.')
        self.pending_signal = None
        self.signal_summary.setText("تم تسجيل الرفض اليدوي. يستمر التقييم الافتراضي لقياس الإشارة فقط؛ لا تُرسل أي أوامر.")
        self.update_recommendation_window(self.signal_summary.text(), None)
        self.approve_btn.setEnabled(False); self.reject_btn.setEnabled(False)
        if self.journal_dialog is not None:
            self.refresh_journal_dialog()

    def log_shadow_outcomes(self, outcomes):
        for item in outcomes or []:
            status_text = "وصل إلى الهدف الافتراضي" if item["status"] == "TP_HIT" else "وصل إلى وقف الخسارة الافتراضي"
            self.add_log("نتيجة إشارة افتراضية",
                         f'#{item["id"]} {item["symbol"]}/{item["timeframe"]} {item["direction"]}: '
                         f'{status_text} عند {item["exit_price"]:.8f}؛ النتيجة {item["r_multiple"]:+.2f}R. '
                         "مقياس سعري افتراضي، وليس ربحًا/خسارة بالدولار.")
        if outcomes and self.journal_dialog is not None:
            self.refresh_journal_dialog()

    def show_signal_journal(self):
        if self.journal_dialog is not None:
            self.journal_dialog.show(); self.journal_dialog.raise_(); self.journal_dialog.activateWindow()
            self.refresh_journal_dialog()
            return
        dialog = QDialog(self)
        dialog.setWindowTitle("Apex Alpha — سجل الإشارات الافتراضية ونتائجها")
        dialog.setWindowFlags(dialog.windowFlags() | Qt.WindowType.WindowMinimizeButtonHint |
                              Qt.WindowType.WindowMaximizeButtonHint | Qt.WindowType.WindowSystemMenuHint)
        dialog.setSizeGripEnabled(True)
        dialog.resize(1100, 580)
        layout = QVBoxLayout(dialog)
        stats_label = QLabel("يتم تحميل الإحصاءات المحلية...")
        stats_label.setWordWrap(True)
        layout.addWidget(stats_label)
        table = QTableWidget(0, 8)
        table.setHorizontalHeaderLabels(["وقت التسجيل (UTC)", "الرمز", "الإطار", "الاتجاه", "الدخول الافتراضي", "الحالة", "القرار اليدوي", "النتيجة (R)"])
        table.setAlternatingRowColors(True)
        table.setSortingEnabled(False)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(table)
        note = QLabel("هذه محاكاة ظلّية تسجل نتيجة كل إشارة عبر أسعار Bid/Ask؛ لا تنشئ صفقة أو ربحًا بالدولار. البيانات محفوظة محليًا على هذا الجهاز.")
        note.setWordWrap(True)
        note.setStyleSheet("color: #d99b48; padding: 5px;")
        layout.addWidget(note)
        buttons = QHBoxLayout()
        refresh_btn = QPushButton("تحديث السجل")
        close_btn = QPushButton("إغلاق")
        buttons.addWidget(refresh_btn); buttons.addStretch(); buttons.addWidget(close_btn)
        layout.addLayout(buttons)
        self.journal_dialog = dialog
        self._journal_widgets = (stats_label, table)
        refresh_btn.clicked.connect(self.refresh_journal_dialog)
        close_btn.clicked.connect(dialog.close)
        dialog.finished.connect(self._on_journal_dialog_closed)
        self.refresh_journal_dialog()
        dialog.show()

    def refresh_journal_dialog(self):
        if self.journal_dialog is None or not hasattr(self, "_journal_widgets"):
            return
        stats_label, table = self._journal_widgets
        try:
            stats = signal_summary()
            win_rate = f'{stats["win_rate"]:.1f}%' if stats["win_rate"] is not None else "غير متاح بعد"
            avg_r = f'{stats["avg_r"]:+.2f}R' if stats["avg_r"] is not None else "غير متاح بعد"
            sample_note = " — عينة أولية صغيرة؛ لا يُستنتج منها أداء موثوق" if stats["resolved"] < 20 else ""
            stats_label.setText(
                f'الإشارات المسجلة: {stats["total"]} | قيد المتابعة: {stats["open"]} | '
                f'وصلت للهدف: {stats["wins"]} | وصلت لوقف الخسارة: {stats["losses"]} | '
                f'نسبة نجاح الإشارات المحسومة: {win_rate} ({stats["resolved"]} محسومة) | '
                f'متوسط النتيجة: {avg_r}{sample_note}'
            )
            rows = recent_signals(500)
            table.setRowCount(0)
            status_labels = {"OPEN": "قيد المتابعة", "TP_HIT": "هدف", "SL_HIT": "وقف خسارة"}
            decision_labels = {"PENDING": "بانتظار قرار", "APPROVED": "مقبولة للمحاكاة", "REJECTED": "مرفوضة يدويًا"}
            for item in rows:
                row_idx = table.rowCount(); table.insertRow(row_idx)
                result_r = "—" if item["r_multiple"] is None else f'{float(item["r_multiple"]):+.2f}R'
                entry_text = f'{float(item["entry"]):.8f}'.rstrip("0").rstrip(".")
                values = (
                    item["created_at"], item["symbol"], item["timeframe"], item["direction"], entry_text,
                    status_labels.get(item["status"], item["status"]),
                    decision_labels.get(item["user_decision"], item["user_decision"]), result_r,
                )
                for col_idx, value in enumerate(values):
                    table.setItem(row_idx, col_idx, QTableWidgetItem(str(value)))
        except Exception as exc:
            stats_label.setText(f"تعذر قراءة سجل الإشارات المحلي: {exc}")

    def _on_journal_dialog_closed(self, *_):
        self.journal_dialog = None
        self._journal_widgets = None

    def closeEvent(self, event):
        if self.academy_window is not None:
            worker = getattr(self.academy_window, "worker", None)
            if worker is not None and worker.isRunning():
                QMessageBox.warning(self, "أكاديمية الاستراتيجيات مشغولة", "انتظر اكتمال العملية الحالية قبل إغلاق البوت.")
                event.ignore()
                return
        for child_window in (self.chart_window, self.recommendation_window, self.assistant_window, self.academy_window, self.settings_dialog, self.journal_dialog, self.market_reading_dialog):
            try:
                if child_window is not None:
                    child_window.close()
            except Exception:
                pass
        try:
            self.bridge.stop()
        except Exception:
            pass
        try:
            if self.mt5.mt5 is not None and self.mt5.initialized:
                self.mt5.mt5.shutdown()
                self.mt5.initialized = False
        except Exception:
            pass
        super().closeEvent(event)
