"""Optional quick local integration test: python test_bridge_server.py"""
import json
import socket
import time

from bridge.price_bridge import PriceBridgeServer


def main():
    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()
    server = PriceBridgeServer(port=port)
    assert server.start(), server.error
    client = socket.create_connection(("127.0.0.1", port), timeout=2)
    packet = {"type": "tick", "symbol": "BTCUSD", "time": int(time.time()),
              "time_msc": int(time.time() * 1000), "bid": 80000.0, "ask": 80005.0}
    client.sendall((json.dumps(packet) + "\n").encode("utf-8"))
    deadline = time.time() + 2
    quote = None
    while time.time() < deadline:
        quote = server.get_latest("BTCUSD")
        if quote:
            break
        time.sleep(0.02)
    client.close()
    server.stop()
    assert quote is not None and quote["tick"].bid == 80000.0
    print("Bridge local socket test: PASS")


if __name__ == "__main__":
    main()
