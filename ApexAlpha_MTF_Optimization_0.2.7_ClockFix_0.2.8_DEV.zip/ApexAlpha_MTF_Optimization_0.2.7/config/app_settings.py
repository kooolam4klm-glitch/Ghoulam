"""Local application preferences for Apex Alpha.

Non-secret preferences live next to this project in config/settings.json.
API secrets are deliberately stored elsewhere using Windows DPAPI (see
services.secure_store) and are never serialized as clear text here.
"""
from __future__ import annotations
import json
import os
import tempfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
SETTINGS_PATH = Path(__file__).with_name("settings.json")
DEFAULTS: dict[str, Any] = {
    "default_symbol": "BTCUSD",
    "default_timeframe": "M15",
    "poll_interval_seconds": 1,
    "quote_max_age_seconds": 15,
    "risk_percent": 1.0,
    "simulation_only": True,
    "live_order_execution": False,
    "language": "ar",
    "theme": "dark",
    "ai_enabled": True,
    "ai_auto_analyze_signals": False,
    "ai_provider": "OpenAI",
    "ai_model": "gpt-4o-mini",
    "ai_base_url": "https://api.openai.com/v1",
    "voice_enabled": True,
    "voice_language": "auto",
    "voice_responses": True,
    "announce_signals": True,
    "announce_positions": True,
    "announce_connection": False,
}


def load_settings() -> dict[str, Any]:
    data = dict(DEFAULTS)
    try:
        with SETTINGS_PATH.open("r", encoding="utf-8") as handle:
            loaded = json.load(handle)
        if isinstance(loaded, dict):
            data.update({k: v for k, v in loaded.items() if k in DEFAULTS})
    except (OSError, json.JSONDecodeError):
        pass
    # Safety-critical switches cannot be enabled from a preferences file.
    data["simulation_only"] = True
    data["live_order_execution"] = False
    if data.get("language") not in ("ar", "en", "fr", "ru"):
        data["language"] = "ar"
    if data.get("theme") not in ("dark", "light", "system"):
        data["theme"] = "dark"
    if data.get("voice_language") not in ("auto", "ar", "en", "fr", "ru"):
        data["voice_language"] = "auto"
    try:
        data["risk_percent"] = float(data.get("risk_percent", 1.0))
    except (TypeError, ValueError):
        data["risk_percent"] = 1.0
    if not 0 < data["risk_percent"] <= 5:
        data["risk_percent"] = 1.0
    return data


def save_settings(settings: dict[str, Any]) -> dict[str, Any]:
    current = load_settings()
    current.update({k: v for k, v in settings.items() if k in DEFAULTS})
    current["simulation_only"] = True
    current["live_order_execution"] = False
    SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix="settings_", suffix=".tmp", dir=str(SETTINGS_PATH.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(current, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
        os.replace(temp_name, SETTINGS_PATH)
    finally:
        if os.path.exists(temp_name):
            try: os.unlink(temp_name)
            except OSError: pass
    return current
