"""Research utilities for Apex Alpha. No live trading actions."""
