"""Chronological comparison of conservative Apex Alpha backtest variants.

The holdout segment is evaluated only after a fixed chronological split. The
runner reports every variant and deliberately does not declare a winner: using
the holdout to select a winner would turn it into another training set.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Iterable, Mapping

from intelligence.backtest import run_backtest


@dataclass(frozen=True)
class ExperimentConfig:
    name: str
    stop_atr: float = 1.5
    reward_risk: float = 2.0
    risk_fraction: float = 0.01
    cost_per_trade: float = 0.0
    spread_point_size: float | None = None


def compare_experiments(
    rates: Iterable[Any],
    configs: Iterable[ExperimentConfig],
    *,
    train_fraction: float = 0.70,
    min_bars: int = 100,
    starting_equity: float = 10_000.0,
    higher_timeframes: Mapping[str, Iterable[Any]] | None = None,
    base_timeframe: str = "M1",
) -> dict[str, Any]:
    """Run each parameter variant on train and unseen chronological holdout.

    Signal warmup uses historical bars before the holdout boundary, but no
    trade can be opened from a signal before ``split_index`` in holdout runs.
    MTF frames, when supplied, are filtered by the backtest engine as-of each
    decision time. Cost conversion remains the caller's responsibility.
    """
    rows = list(rates or [])
    configs = list(configs)
    if not 0.5 <= float(train_fraction) <= 0.9:
        raise ValueError("train_fraction must be between 0.5 and 0.9")
    if len(rows) < int(min_bars):
        return {"ok": False, "error": f"Need at least {int(min_bars)} chronological bars.", "results": []}
    if not configs:
        return {"ok": False, "error": "At least one experiment configuration is required.", "results": []}
    times = []
    for row in rows:
        try:
            times.append(int(row["time"]))
        except (TypeError, KeyError, IndexError, ValueError):
            try:
                times.append(int(row.time))
            except (TypeError, ValueError, AttributeError):
                times = []
                break
    if times and any(a >= b for a, b in zip(times, times[1:])):
        return {"ok": False, "error": "Bars must be strictly chronological with no duplicate timestamps.", "results": []}

    split = int(len(rows) * float(train_fraction))
    if split < max(60, int(min_bars) // 2) or len(rows) - split < 35:
        return {"ok": False, "error": "Not enough bars in train/holdout segments; provide a longer history or adjust min_bars.", "results": []}

    results = []
    for config in configs:
        common = {
            "starting_equity": starting_equity,
            "risk_fraction": config.risk_fraction,
            "stop_atr": config.stop_atr,
            "reward_risk": config.reward_risk,
            "cost_per_trade": config.cost_per_trade,
            "spread_point_size": config.spread_point_size,
            "min_bars": min(60, max(35, split // 3)),
            "higher_timeframes": higher_timeframes,
            "base_timeframe": base_timeframe,
        }
        train = run_backtest(rows[:split], **common)
        holdout = run_backtest(rows, start_index=split, **common)
        results.append({
            "config": asdict(config),
            "train": train.get("metrics", {}),
            "holdout": holdout.get("metrics", {}),
            "train_ok": bool(train.get("ok")),
            "holdout_ok": bool(holdout.get("ok")),
            "train_error": train.get("error"),
            "holdout_error": holdout.get("error"),
            "train_trades": train.get("trades", []),
            "holdout_trades": holdout.get("trades", []),
        })
    return {
        "ok": all(r["train_ok"] and r["holdout_ok"] for r in results),
        "bar_count": len(rows),
        "split_index": split,
        "train_bar_count": split,
        "holdout_bar_count": len(rows) - split,
        "train_fraction": float(train_fraction),
        "results": results,
        "warning": (
            "Research only. Do not select a strategy from a single holdout result; "
            "reserve a final untouched period and perform forward demo testing. "
            "Fixed costs are only as realistic as cost_per_trade supplied by the user. "
            "Historical MT5 spread costs are approximate and require the correct SYMBOL_POINT; "
            "spread alone does not model commission, slippage, or contract-specific execution."
        ),
    }
