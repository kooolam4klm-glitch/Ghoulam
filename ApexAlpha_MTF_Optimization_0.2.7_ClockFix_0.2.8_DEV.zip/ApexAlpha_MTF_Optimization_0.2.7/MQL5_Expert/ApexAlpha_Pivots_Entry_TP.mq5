//+------------------------------------------------------------------+
//| ApexAlpha_Pivots_Entry_TP.mq5                                    |
//| Read-only chart indicator + Common\Files JSON signal snapshot.   |
//| NO trading functions.                                            |
//+------------------------------------------------------------------+
#property strict
#property version   "1.10"
#property indicator_chart_window
#property indicator_buffers 2
#property indicator_plots   2
#property indicator_label1  "Confirmed Pivot High"
#property indicator_type1   DRAW_ARROW
#property indicator_color1  clrTomato
#property indicator_width1  2
#property indicator_label2  "Confirmed Pivot Low"
#property indicator_type2   DRAW_ARROW
#property indicator_color2  clrDeepSkyBlue
#property indicator_width2  2

input int    PivotLeftBars  = 3;
input int    PivotRightBars = 2;
input int    FastEMAPeriod  = 20;
input int    SlowEMAPeriod  = 50;
input int    RSIPeriod      = 14;
input int    ATRPeriod      = 14;
input double StopATRMult    = 1.5;
input double TP1_R          = 1.0;
input double TP2_R          = 2.0;
input bool   ExportCommonFile = true;
input bool   ShowStatusPanel = true;

 double PivotHighBuffer[];
 double PivotLowBuffer[];
 int hFast = INVALID_HANDLE, hSlow = INVALID_HANDLE, hRSI = INVALID_HANDLE, hATR = INVALID_HANDLE;
 datetime lastBarExported = 0;
 string prefix = "ApexAlphaMT5_";

string SafeName(string value)
  {
   StringReplace(value, ".", "_"); StringReplace(value, "#", "_");
   StringReplace(value, "/", "_"); StringReplace(value, "\\", "_");
   return value;
  }

string TFName(ENUM_TIMEFRAMES tf)
  {
   string s=EnumToString(tf); StringReplace(s,"PERIOD_",""); return s;
  }

bool IsPivotHigh(const double &high[], int i, int left, int right, int total)
  {
   // Series arrays: i-k are newer candles; i+k are older candles.
   if(i-right < 1 || i+left >= total) return false;
   for(int k=1;k<=left;k++) if(high[i] <= high[i+k]) return false;
   for(int k=1;k<=right;k++) if(high[i] < high[i-k]) return false;
   return true;
  }

bool IsPivotLow(const double &low[], int i, int left, int right, int total)
  {
   // Series arrays: i-k are newer candles; i+k are older candles.
   if(i-right < 1 || i+left >= total) return false;
   for(int k=1;k<=left;k++) if(low[i] >= low[i+k]) return false;
   for(int k=1;k<=right;k++) if(low[i] > low[i-k]) return false;
   return true;
  }

void DrawHLine(string name, double price, color clr, ENUM_LINE_STYLE style=STYLE_SOLID)
  {
   if(price<=0 || !MathIsValidNumber(price)) { ObjectDelete(0,name); return; }
   if(ObjectFind(0,name)<0) ObjectCreate(0,name,OBJ_HLINE,0,0,price);
   ObjectSetDouble(0,name,OBJPROP_PRICE,price);
   ObjectSetInteger(0,name,OBJPROP_COLOR,clr);
   ObjectSetInteger(0,name,OBJPROP_STYLE,style);
   ObjectSetInteger(0,name,OBJPROP_WIDTH,1);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false);
   ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
  }

void RemoveLevels()
  {
   ObjectDelete(0,prefix+"ENTRY"); ObjectDelete(0,prefix+"SL");
   ObjectDelete(0,prefix+"TP1"); ObjectDelete(0,prefix+"TP2");
  }

void DrawLabel(string name, string text, int y, color clr)
  {
   if(ObjectFind(0,name)<0) ObjectCreate(0,name,OBJ_LABEL,0,0,0);
   ObjectSetInteger(0,name,OBJPROP_CORNER,CORNER_LEFT_UPPER);
   ObjectSetInteger(0,name,OBJPROP_XDISTANCE,12); ObjectSetInteger(0,name,OBJPROP_YDISTANCE,y);
   ObjectSetInteger(0,name,OBJPROP_COLOR,clr); ObjectSetInteger(0,name,OBJPROP_FONTSIZE,9);
   ObjectSetString(0,name,OBJPROP_FONT,"Arial"); ObjectSetString(0,name,OBJPROP_TEXT,text);
   ObjectSetInteger(0,name,OBJPROP_SELECTABLE,false); ObjectSetInteger(0,name,OBJPROP_HIDDEN,true);
  }

void ExportSnapshot(string direction, int score, datetime barTime, double bid, double ask,
                    double atr, double entry, double sl, double tp1, double tp2,
                    double pivotHigh, double pivotLow)
  {
   if(!ExportCommonFile) return;
   string fileName="ApexAlphaSignal_"+SafeName(_Symbol)+"_"+TFName((ENUM_TIMEFRAMES)_Period)+".json";
   int fh=FileOpen(fileName,FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_COMMON);
   if(fh==INVALID_HANDLE) { Print("ApexAlpha indicator: unable to write Common Files snapshot. Error=",GetLastError()); return; }
   int digits=(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS);
   string payload="{\"schema\":1,\"source\":\"ApexAlpha_MT5_Indicator\",\"symbol\":\""+_Symbol+
      "\",\"timeframe\":\""+TFName((ENUM_TIMEFRAMES)_Period)+"\",\"direction\":\""+direction+
      "\",\"score\":"+IntegerToString(score)+",\"bar_time\":"+IntegerToString((long)barTime)+
      ",\"bid\":"+DoubleToString(bid,digits)+",\"ask\":"+DoubleToString(ask,digits)+
      ",\"atr\":"+DoubleToString(atr,digits)+",\"entry\":"+DoubleToString(entry,digits)+
      ",\"stop_loss\":"+DoubleToString(sl,digits)+",\"tp1\":"+DoubleToString(tp1,digits)+
      ",\"tp2\":"+DoubleToString(tp2,digits)+",\"pivot_high\":"+DoubleToString(pivotHigh,digits)+
      ",\"pivot_low\":"+DoubleToString(pivotLow,digits)+",\"trading_enabled\":false}";
   FileWriteString(fh,payload); FileClose(fh);
  }

int OnInit()
  {
   SetIndexBuffer(0,PivotHighBuffer,INDICATOR_DATA); SetIndexBuffer(1,PivotLowBuffer,INDICATOR_DATA);
   ArraySetAsSeries(PivotHighBuffer,true); ArraySetAsSeries(PivotLowBuffer,true);
   PlotIndexSetInteger(0,PLOT_ARROW,234); PlotIndexSetInteger(1,PLOT_ARROW,233);
   PlotIndexSetDouble(0,PLOT_EMPTY_VALUE,EMPTY_VALUE); PlotIndexSetDouble(1,PLOT_EMPTY_VALUE,EMPTY_VALUE);
   hFast=iMA(_Symbol,_Period,FastEMAPeriod,0,MODE_EMA,PRICE_CLOSE);
   hSlow=iMA(_Symbol,_Period,SlowEMAPeriod,0,MODE_EMA,PRICE_CLOSE);
   hRSI=iRSI(_Symbol,_Period,RSIPeriod,PRICE_CLOSE); hATR=iATR(_Symbol,_Period,ATRPeriod);
   if(hFast==INVALID_HANDLE || hSlow==INVALID_HANDLE || hRSI==INVALID_HANDLE || hATR==INVALID_HANDLE) return INIT_FAILED;
   IndicatorSetString(INDICATOR_SHORTNAME,"Apex Alpha Pivots + Levels (Read Only)");
   return INIT_SUCCEEDED;
  }

void OnDeinit(const int reason)
  {
   if(hFast!=INVALID_HANDLE) IndicatorRelease(hFast); if(hSlow!=INVALID_HANDLE) IndicatorRelease(hSlow);
   if(hRSI!=INVALID_HANDLE) IndicatorRelease(hRSI); if(hATR!=INVALID_HANDLE) IndicatorRelease(hATR);
   ObjectDelete(0,prefix+"STATUS"); RemoveLevels();
  }

int OnCalculate(const int rates_total,const int prev_calculated,const datetime &time[],
                const double &open[],const double &high[],const double &low[],const double &close[],
                const long &tick_volume[],const long &volume[],const int &spread[])
  {
   if(rates_total < SlowEMAPeriod+PivotLeftBars+PivotRightBars+5) return 0;
   ArraySetAsSeries(time,true); ArraySetAsSeries(high,true); ArraySetAsSeries(low,true); ArraySetAsSeries(close,true);
   int start=(prev_calculated==0 ? rates_total-PivotLeftBars-1 : MathMin(rates_total-prev_calculated+PivotRightBars+2, rates_total-PivotLeftBars-1));
   if(start<1) start=1;
   for(int i=start;i>=PivotRightBars;i--)
     {
      PivotHighBuffer[i]=EMPTY_VALUE; PivotLowBuffer[i]=EMPTY_VALUE;
      if(IsPivotHigh(high,i,PivotLeftBars,PivotRightBars,rates_total)) PivotHighBuffer[i]=high[i]+(high[i]-low[i])*0.12;
      if(IsPivotLow(low,i,PivotLeftBars,PivotRightBars,rates_total)) PivotLowBuffer[i]=low[i]-(high[i]-low[i])*0.12;
     }
   PivotHighBuffer[0]=EMPTY_VALUE; PivotLowBuffer[0]=EMPTY_VALUE; // never confirm a pivot on the forming candle

   if(time[1]==lastBarExported) return rates_total;
   lastBarExported=time[1];
   double fast[],slow[],rsi[],atr[]; ArraySetAsSeries(fast,true); ArraySetAsSeries(slow,true); ArraySetAsSeries(rsi,true); ArraySetAsSeries(atr,true);
   if(CopyBuffer(hFast,0,0,3,fast)<3 || CopyBuffer(hSlow,0,0,3,slow)<3 || CopyBuffer(hRSI,0,0,3,rsi)<3 || CopyBuffer(hATR,0,0,3,atr)<3) return rates_total;
   MqlTick tick; if(!SymbolInfoTick(_Symbol,tick)) return rates_total;
   string dir="WAIT"; int score=0; double entry=0,sl=0,tp1=0,tp2=0; double a=atr[1];
   bool buy=(close[1]>fast[1] && fast[1]>slow[1] && rsi[1]>=52.0 && rsi[1]<75.0);
   bool sell=(close[1]<fast[1] && fast[1]<slow[1] && rsi[1]<=48.0 && rsi[1]>25.0);
   if(buy) { dir="BUY"; score=70; entry=tick.ask; sl=entry-StopATRMult*a; tp1=entry+(entry-sl)*TP1_R; tp2=entry+(entry-sl)*TP2_R; }
   else if(sell) { dir="SELL"; score=70; entry=tick.bid; sl=entry+StopATRMult*a; tp1=entry-(sl-entry)*TP1_R; tp2=entry-(sl-entry)*TP2_R; }
   double ph=0,pl=0;
   for(int i=PivotRightBars+1;i<MathMin(rates_total,200);i++)
     { if(ph==0 && PivotHighBuffer[i]!=EMPTY_VALUE) ph=high[i]; if(pl==0 && PivotLowBuffer[i]!=EMPTY_VALUE) pl=low[i]; if(ph>0 && pl>0) break; }
   if(dir=="WAIT") RemoveLevels(); else { DrawHLine(prefix+"ENTRY",entry,clrGold); DrawHLine(prefix+"SL",sl,clrTomato,STYLE_DASH); DrawHLine(prefix+"TP1",tp1,clrLimeGreen,STYLE_DASH); DrawHLine(prefix+"TP2",tp2,clrMediumSeaGreen,STYLE_DASH); }
   string status=_Symbol+" | "+TFName((ENUM_TIMEFRAMES)_Period)+" | "+dir+" | توافق قواعد "+IntegerToString(score)+"/100 (ليس احتمال ربح)";
   if(ShowStatusPanel) DrawLabel(prefix+"STATUS",status,18,(dir=="BUY"?clrLimeGreen:dir=="SELL"?clrTomato:clrGold));
   ExportSnapshot(dir,score,time[1],tick.bid,tick.ask,a,entry,sl,tp1,tp2,ph,pl);
   return rates_total;
  }
