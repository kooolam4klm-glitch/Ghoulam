//+------------------------------------------------------------------+
//| ApexPriceBridge.mq5                                              |
//| Read-only quote bridge from MT5 to local Apex Alpha dashboard.   |
//| NO trading functions are used.                                   |
//+------------------------------------------------------------------+
#property strict
#property version   "1.70"
#property description "Apex Alpha local price bridge: streams ticks to 127.0.0.1; does not trade."

input string BridgeHost = "127.0.0.1";
input uint   BridgePort = 47831;
input int    ReconnectSeconds = 2;

int g_socket = INVALID_HANDLE;
string g_symbol = "";
ulong g_last_connect_attempt = 0;

string JsonEscape(const string source)
  {
   string value = source;
   StringReplace(value, "\\", "\\\\");
   StringReplace(value, "\"", "\\\"");
   StringReplace(value, "\r", "");
   StringReplace(value, "\n", "");
   return value;
  }

void CloseBridgeSocket()
  {
   if(g_socket != INVALID_HANDLE)
     {
      SocketClose(g_socket);
      g_socket = INVALID_HANDLE;
     }
  }

bool ConnectBridge()
  {
   CloseBridgeSocket();
   g_last_connect_attempt = GetTickCount64();
   ResetLastError();
   g_socket = SocketCreate();
   if(g_socket == INVALID_HANDLE)
     {
      Print("ApexPriceBridge: SocketCreate failed. Error=", GetLastError());
      return false;
     }
   if(!SocketConnect(g_socket, BridgeHost, BridgePort, 500))
     {
      Print("ApexPriceBridge: cannot connect to ", BridgeHost, ":", BridgePort,
            ". Start Apex Alpha first and allow the local address in MT5. Error=", GetLastError());
      CloseBridgeSocket();
      return false;
     }
   Print("ApexPriceBridge: connected to local Apex Alpha receiver at ", BridgeHost, ":", BridgePort,
         " for symbol ", g_symbol, ". Read-only; no trading enabled.");
   return true;
  }

bool EnsureConnected()
  {
   if(g_socket != INVALID_HANDLE && SocketIsConnected(g_socket))
      return true;
   ulong now = GetTickCount64();
   ulong interval = (ulong)MathMax(1, ReconnectSeconds) * 1000;
   if(g_last_connect_attempt != 0 && now - g_last_connect_attempt < interval)
      return false;
   return ConnectBridge();
  }

bool SendTick()
  {
   if(!EnsureConnected())
      return false;

   MqlTick tick;
   if(!SymbolInfoTick(g_symbol, tick))
      return false;
   if(tick.time_msc <= 0 || tick.bid <= 0 || tick.ask <= 0)
      return false;

   int digits = (int)SymbolInfoInteger(g_symbol, SYMBOL_DIGITS);
   long server_time = (long)TimeTradeServer();
   long gmt_time = (long)TimeGMT();
   long server_utc_offset_seconds = server_time - gmt_time;
   // Reject implausible values at source; Python validates again.
   if(MathAbs((double)server_utc_offset_seconds) > 14.0 * 3600.0)
      return false;
   string message = "{\"type\":\"tick\",\"symbol\":\"" + JsonEscape(g_symbol) +
                    "\",\"time\":" + IntegerToString((long)tick.time) +
                    ",\"time_msc\":" + IntegerToString((long)tick.time_msc) +
                    ",\"server_time\":" + IntegerToString(server_time) +
                    ",\"gmt_time\":" + IntegerToString(gmt_time) +
                    ",\"server_utc_offset_seconds\":" + IntegerToString(server_utc_offset_seconds) +
                    ",\"bid\":" + DoubleToString(tick.bid, digits) +
                    ",\"ask\":" + DoubleToString(tick.ask, digits) +
                    ",\"last\":" + DoubleToString(tick.last, digits) +
                    ",\"volume\":" + IntegerToString((long)tick.volume) +
                    ",\"flags\":" + IntegerToString((int)tick.flags) +
                    ",\"volume_real\":" + DoubleToString(tick.volume_real, 8) + "}\n";

   char bytes[];
   int count = StringToCharArray(message, bytes, 0, WHOLE_ARRAY, CP_UTF8);
   if(count <= 1)
      return false;
   int to_send = count - 1; // omit StringToCharArray's terminating NUL; newline is retained
   ResetLastError();
   int sent = SocketSend(g_socket, bytes, to_send);
   if(sent != to_send)
     {
      Print("ApexPriceBridge: SocketSend failed/partial. Sent=", sent, " expected=", to_send,
            " Error=", GetLastError());
      CloseBridgeSocket();
      return false;
     }
   return true;
  }

int OnInit()
  {
   g_symbol = _Symbol;
   if(g_symbol == "")
      return INIT_FAILED;
   EventSetTimer((int)MathMax(1, ReconnectSeconds));
   ConnectBridge();
   Print("ApexPriceBridge initialized for ", g_symbol,
         ". Attach to the same symbol as the bot. This EA transmits prices only and never places orders.");
   return INIT_SUCCEEDED;
  }

void OnTick()
  {
   // Each received quote on this chart symbol is forwarded to the local bridge.
   SendTick();
  }

void OnTimer()
  {
   EnsureConnected();
  }

void OnDeinit(const int reason)
  {
   EventKillTimer();
   CloseBridgeSocket();
   Print("ApexPriceBridge stopped. No trades were sent by this EA.");
  }
