from charting.indicators import atr_series, atr_wilder_series

def test_wilder_atr_starts_with_simple_seed_and_smooths_recursively():
    rows = []
    for i, tr in enumerate([2.0, 4.0, 6.0, 8.0]):
        rows.append({"high": tr, "low": 0.0, "close": tr})
    values = atr_wilder_series(rows, 3)
    assert values[:2] == [None, None]
    assert values[2] == 4.0
    assert values[3] == (4.0 * 2 + 8.0) / 3

def test_legacy_atr_remains_available_for_comparison():
    rows = [{"high": 2.0, "low": 0.0, "close": 1.0} for _ in range(20)]
    assert atr_series(rows, 14)[-1] == 2.0
    assert atr_wilder_series(rows, 14)[-1] == 2.0
