import pytest
from risk.risk_manager import calculate_position_size, validate_trade_proposal


def test_execution_disabled():
    result = validate_trade_proposal({"symbol": "BTCUSD", "side": "BUY"})
    assert result["ok"] is False
    assert "disabled" in result["reason"].lower()


def test_position_size_respects_risk_budget_and_volume_step():
    result = calculate_position_size(balance=10_000, risk_percent=1, entry=110,
        stop_loss=100, tick_size=1, tick_value=1, volume_min=0.1,
        volume_max=100, volume_step=0.1)
    assert result["ok"] is True
    assert result["volume"] == 10
    assert result["estimated_risk"] == 100
    assert result["risk_percent_actual"] == 1


def test_position_size_does_not_round_up_to_broker_minimum():
    result = calculate_position_size(balance=100, risk_percent=0.1, entry=110,
        stop_loss=100, tick_size=1, tick_value=1, volume_min=0.1,
        volume_max=100, volume_step=0.1)
    assert result["ok"] is False
    assert result["volume"] is None


@pytest.mark.parametrize("kwargs", [
    {"balance": 0, "risk_percent": 1, "entry": 10, "stop_loss": 9, "tick_size": 1, "tick_value": 1},
    {"balance": 100, "risk_percent": 6, "entry": 10, "stop_loss": 9, "tick_size": 1, "tick_value": 1},
    {"balance": 100, "risk_percent": 1, "entry": 10, "stop_loss": 10, "tick_size": 1, "tick_value": 1},
])
def test_position_size_rejects_invalid_risk_inputs(kwargs):
    with pytest.raises(ValueError):
        calculate_position_size(**kwargs)
