import json
from pathlib import Path

from academy import strategy_library as library
from academy.strategy_library import parse_subtitle_text
from academy.strategy_analyzer import _extract_json, analyze_transcript
from academy.ingestion import transcribe_media_file


def test_subtitle_parser_removes_timestamps_and_tags():
    raw = """WEBVTT

00:00:01.000 --> 00:00:03.000
Buy after <b>the breakout</b>.

00:00:03.000 --> 00:00:05.000
Buy after the breakout.

00:00:05.000 --> 00:00:07.000
Stop loss below the last low.
"""
    text = parse_subtitle_text(raw)
    assert "00:00" not in text
    assert "<b>" not in text
    assert text.count("Buy after the breakout.") == 1
    assert "Stop loss below the last low." in text


def test_library_persists_lesson_and_analysis(tmp_path, monkeypatch):
    monkeypatch.setattr(library, "DB_PATH", tmp_path / "academy.sqlite3")
    lesson_id = library.save_lesson("Breakout lesson", "text", "", "A transcript explaining a breakout strategy.")
    original = library.get_lesson(lesson_id)
    assert original["title"] == "Breakout lesson"
    assert original["status"] == "draft"
    strategy = {"strategy_name": "Breakout", "buy_rules": ["Wait for close above resistance"]}
    library.save_analysis(lesson_id, json.dumps(strategy), strategy, "test-model")
    saved = library.get_lesson(lesson_id)
    assert saved["status"] == "draft_untested"
    assert saved["strategy"]["strategy_name"] == "Breakout"
    assert library.list_lessons("resistance")[0]["id"] == lesson_id


def test_editing_transcript_invalidates_previous_analysis(tmp_path, monkeypatch):
    monkeypatch.setattr(library, "DB_PATH", tmp_path / "academy.sqlite3")
    lesson_id = library.save_lesson("Lesson", transcript="Original transcript with enough useful details.")
    library.save_analysis(lesson_id, '{"strategy_name":"old"}', {"strategy_name": "old"}, "test")
    library.save_lesson("Lesson", transcript="Changed transcript; this needs a new analysis now.", lesson_id=lesson_id)
    item = library.get_lesson(lesson_id)
    assert item["analysis_text"] == ""
    assert item["strategy"] == {}
    assert item["status"] == "draft"
    assert item["model"] == ""


def test_delete_lesson(tmp_path, monkeypatch):
    monkeypatch.setattr(library, "DB_PATH", tmp_path / "academy.sqlite3")
    lesson_id = library.save_lesson("To remove")
    assert library.delete_lesson(lesson_id)
    assert library.get_lesson(lesson_id) is None


def test_json_parser_accepts_fenced_json():
    parsed = _extract_json('```json\n{"strategy_name":"Pullback","buy_rules":["close confirmation"]}\n```')
    assert parsed["strategy_name"] == "Pullback"
    assert parsed["buy_rules"] == ["close confirmation"]


def test_analyzer_rejects_short_transcript_without_network():
    try:
        analyze_transcript("too short", "", "gpt-4o-mini", "https://api.openai.com/v1")
    except ValueError as exc:
        assert "قصير" in str(exc)
    else:
        raise AssertionError("short transcripts should not be sent to the API")


def test_transcription_requires_existing_file_and_https_key(tmp_path):
    fake = tmp_path / "sample.mp3"
    fake.write_bytes(b"not-audio")
    try:
        transcribe_media_file(str(fake), "", "https://api.openai.com/v1")
    except ValueError as exc:
        assert "مفتاح API" in str(exc)
    else:
        raise AssertionError("transcription must require explicit API configuration")
