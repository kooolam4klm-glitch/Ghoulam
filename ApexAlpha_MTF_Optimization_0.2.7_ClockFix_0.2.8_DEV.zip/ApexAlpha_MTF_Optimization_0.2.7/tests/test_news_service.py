from services.news_service import parse_rss, fetch_market_news


def test_parse_rss_normalizes_articles_and_strips_html():
    xml = b'''<?xml version="1.0"?><rss version="2.0"><channel><item>
    <title>Bitcoin &amp; markets</title><link>https://example.com/a</link>
    <description><![CDATA[<p>Market <b>update</b></p>]]></description>
    <pubDate>Fri, 23 Oct 2026 10:00:00 GMT</pubDate>
    </item></channel></rss>'''
    items = parse_rss(xml, "Example")
    assert len(items) == 1
    assert items[0]["title"] == "Bitcoin & markets"
    assert items[0]["summary"] == "Market update"
    assert items[0]["source"] == "Example"
    assert items[0]["url"] == "https://example.com/a"
    assert items[0]["published"].startswith("2026-10-23T10:00:00")


def test_news_fetch_reports_failure_without_faking_articles(monkeypatch):
    import services.news_service as news
    monkeypatch.setattr(news, "fetch_feed", lambda *a, **k: {"source": "Fake", "ok": False, "items": [], "error": "offline"})
    result = fetch_market_news(feeds=(("Fake", "https://example.invalid/rss"),))
    assert result["ok"] is False
    assert result["items"] == []
    assert result["errors"][0]["error"] == "offline"
