from intelligence.backtest import run_backtest
import random


def rows_with_trend(n=100):
    rows = []
    price = 100.0
    for i in range(n):
        # Smooth trend with small ranges; enough deterministic data to exercise the walk-forward engine.
        price += 0.3 if i < 65 else -0.25
        rows.append({"open": price - 0.05, "high": price + 0.25, "low": price - 0.25, "close": price, "time": i})
    return rows


def test_backtest_is_walk_forward_and_returns_metrics():
    random.seed(3)
    rows = []
    price = 100.0
    for i in range(200):
        delta = (0.05 if i < 100 else -0.04) + random.uniform(-0.35, 0.35)
        previous = price
        price += delta
        rows.append({"open": (price + previous) / 2, "high": max(price, previous) + 0.25,
                     "low": min(price, previous) - 0.25, "close": price, "time": i})
    result = run_backtest(rows, min_bars=60)
    assert result["ok"] is True
    assert result["metrics"]["trade_count"] > 0
    assert "max_drawdown_percent" in result["metrics"]
    assert "not a guarantee" in result["note"]


def test_backtest_rejects_too_few_bars_and_bad_risk():
    assert run_backtest(rows_with_trend(40))["ok"] is False
    try:
        run_backtest(rows_with_trend(), risk_fraction=0.2)
    except ValueError:
        pass
    else:
        raise AssertionError("risk_fraction above 5% must be rejected")


def test_backtest_uses_shared_live_signal_engine(monkeypatch):
    import intelligence.backtest as backtest_module

    calls = {"count": 0}

    def always_wait(*args, **kwargs):
        calls["count"] += 1
        return {"direction": "WAIT", "atr": 1.0, "confidence": 0,
                "strategy_id": "TEST_SHARED_ENGINE"}

    monkeypatch.setattr(backtest_module, "make_demo_signal", always_wait)
    result = backtest_module.run_backtest(rows_with_trend(100), min_bars=60)
    assert result["ok"] is True
    assert calls["count"] > 0
    assert result["metrics"]["trade_count"] == 0


def test_backtest_trade_records_rule_score_and_expectancy():
    import intelligence.backtest as backtest_module
    result = backtest_module.run_backtest(rows_with_trend(100), min_bars=60)
    assert result["ok"] is True
    assert "expectancy_cash_per_trade" in result["metrics"]
    for trade in result["trades"]:
        assert "signal_strategy_id" in trade
        assert 0 <= trade["signal_rule_score"] <= 100


def test_mtf_backtest_blocks_actionable_signal_when_context_is_missing(monkeypatch):
    import intelligence.backtest as backtest_module

    def always_buy(*args, **kwargs):
        return {"direction": "BUY", "atr": 1.0, "confidence": 82,
                "strategy_id": "TEST_MTF", "summary": "test signal"}

    monkeypatch.setattr(backtest_module, "make_demo_signal", always_buy)
    rows = []
    start = 1_800_000_000
    for i in range(100):
        close = 100 + i * 0.1
        rows.append({"time": start + i * 60, "open": close, "high": close + 0.2,
                     "low": close - 0.2, "close": close})
    result = backtest_module.run_backtest(
        rows, min_bars=60, higher_timeframes={"M15": [], "H1": [], "H4": []},
        base_timeframe="M1"
    )
    assert result["ok"] is True
    assert result["metrics"]["mtf_contexts_evaluated"] > 0
    assert result["metrics"]["mtf_blocked_signals"] > 0
    assert result["metrics"]["trade_count"] == 0
    assert "aligned by UTC bar-close time" in result["note"]


def test_mtf_snapshot_excludes_higher_timeframe_bars_not_yet_closed():
    from intelligence.backtest import _mtf_snapshot

    start = 1_800_000_000
    frames = {}
    for timeframe, seconds in (("M15", 900), ("H1", 3600), ("H4", 14400)):
        frames[timeframe] = [
            {"time": start + i * seconds, "open": 100 + i, "high": 101 + i,
             "low": 99 + i, "close": 100.5 + i}
            for i in range(60)
        ]
    decision_time = start + 55 * 3600
    result = _mtf_snapshot(frames, decision_time)
    # At least two contexts should be usable from the past; no future bar may be used.
    assert result["timeframes"]["M15"]["ok"] is True
    assert result["timeframes"]["H1"]["ok"] is True
    last_m15_open = max(row["time"] for row in frames["M15"] if row["time"] + 900 <= decision_time)
    assert last_m15_open + 900 <= decision_time
    # Extreme future bars must not change the as-of snapshot.
    future_frames = {tf: list(rows) + [{"time": decision_time + 10_000_000,
                                        "open": 1.0, "high": 2.0,
                                        "low": 0.5, "close": 1.0}]
                     for tf, rows in frames.items()}
    future_result = _mtf_snapshot(future_frames, decision_time)
    assert future_result["overall_code"] == result["overall_code"]
    for tf in ("M15", "H1", "H4"):
        assert future_result["timeframes"][tf].get("close") == result["timeframes"][tf].get("close")


def test_mtf_backtest_requires_base_timestamps_when_mtf_is_enabled():
    from intelligence.backtest import run_backtest
    rows = [{k: v for k, v in row.items() if k != "time"} for row in rows_with_trend(100)]
    result = run_backtest(rows, min_bars=60,
                          higher_timeframes={"M15": [], "H1": [], "H4": []})
    assert result["ok"] is False
    assert "UTC epoch-second timestamps" in result["error"]


def test_historical_spread_cost_is_applied_when_supplied(monkeypatch):
    import intelligence.backtest as bt

    def buy_signal(*args, **kwargs):
        return {"direction": "BUY", "atr": 0.2, "confidence": 80,
                "strategy_id": "TEST", "multi_timeframe_gate": "NOT_USED"}

    monkeypatch.setattr(bt, "make_demo_signal", buy_signal)
    rows = rows_with_trend(240)
    for row in rows:
        row["spread_points"] = 10.0
    no_cost = run_backtest(rows, min_bars=60, start_index=120,
                           stop_atr=1.5, reward_risk=1.0)
    with_spread = run_backtest(rows, min_bars=60, start_index=120,
                               stop_atr=1.5, reward_risk=1.0,
                               spread_point_size=0.01)
    assert no_cost["ok"] and with_spread["ok"]
    assert with_spread["metrics"]["spread_cost_total"] > 0
    assert with_spread["metrics"]["total_costs"] == with_spread["metrics"]["spread_cost_total"]
    assert with_spread["metrics"]["net_pnl"] < no_cost["metrics"]["net_pnl"]
