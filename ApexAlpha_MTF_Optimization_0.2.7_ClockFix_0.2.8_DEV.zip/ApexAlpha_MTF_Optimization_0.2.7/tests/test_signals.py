from intelligence.signal_engine import make_demo_signal

class Tick:
    bid = 1.1000
    ask = 1.1002


def bars_from_closes(closes):
    return [{"open": c, "high": c + 0.0005, "low": c - 0.0005, "close": c} for c in closes]


def test_signal_is_read_only_and_has_technical_metrics():
    closes = [1.0 + i * 0.001 for i in range(40)]
    signal = make_demo_signal("EURUSD", "M15", Tick(), bars_from_closes(closes))
    assert signal["symbol"] == "EURUSD"
    assert "لم يُرسل أي أمر" in signal["summary"] or "لا يُرسل أي أمر تداول" in signal["summary"]
    assert "RSI(14)" in signal["summary"]
    assert signal["direction"] in {"BUY", "SELL", "WAIT"}


def test_insufficient_data_waits():
    signal = make_demo_signal("EURUSD", "M15", Tick(), bars_from_closes([1.0] * 5))
    assert signal["bias"] == "بيانات غير كافية"
    assert signal["direction"] == "WAIT"
    assert signal["entry"] is None


def test_buy_levels_have_positive_risk_reward():
    # Strong but not extreme uptrend, which satisfies the demonstration BUY filter.
    closes = [1.0 + i * 0.0002 for i in range(40)]
    signal = make_demo_signal("EURUSD", "M15", Tick(), bars_from_closes(closes))
    if signal["direction"] == "BUY":
        assert signal["stop_loss"] < signal["entry"] < signal["take_profit"]


def test_signal_has_closed_bar_timestamp_when_rates_include_live_bar():
    rows = []
    base = 1_800_000_000
    for i in range(40):
        c = 1.0 + i * 0.0001
        rows.append({"time": base + i * 900, "open": c, "high": c + 0.0005,
                     "low": c - 0.0005, "close": c})
    signal = make_demo_signal("EURUSD", "M15", Tick(), rows)
    # The most recent row is the still-forming bar; the signal key uses the prior close.
    assert signal["signal_bar_time"] == rows[-2]["time"]
    assert signal["strategy_id"] == "STRUCTURE_TREND_MOMENTUM_V2"


def test_confidence_is_explicitly_a_score_not_win_probability():
    closes = [1.0 + i * 0.0002 for i in range(80)]
    signal = make_demo_signal("EURUSD", "M15", Tick(), bars_from_closes(closes))
    assert 0 <= signal["confidence"] <= 100
    assert "ليست احتمال ربح" in signal["confidence_label"]
    assert signal["direction"] in {"BUY", "SELL", "WAIT"}


def test_engine_waits_when_history_is_short_for_long_term_trend():
    closes = [1.0 + i * 0.0002 for i in range(40)]
    signal = make_demo_signal("EURUSD", "M15", Tick(), bars_from_closes(closes))
    assert signal["direction"] == "WAIT"
    assert "RSI(14)" in signal["summary"]


def test_engine_does_not_short_into_a_recent_rebound_without_confirmation():
    # A declining history followed by a sharp multi-bar rebound should not be
    # sold solely because the slower averages still lag the recovery.
    closes = [1.20 - i * 0.001 for i in range(65)]
    closes += [closes[-1] + step * 0.0008 for step in range(1, 7)]
    signal = make_demo_signal("EURUSD", "M15", Tick(), bars_from_closes(closes))
    assert signal["direction"] != "SELL"
    assert any("ارتداد صاعد" in warning for warning in signal["warnings"]) or signal["direction"] == "WAIT"


def test_signal_rejects_non_monotonic_bar_time_order():
    rows = []
    base = 1_800_000_000
    for i in range(65):
        c = 1.0 + i * 0.0001
        rows.append({"time": base + i * 60, "open": c, "high": c + 0.0005,
                     "low": c - 0.0005, "close": c})
    rows[25], rows[26] = rows[26], rows[25]
    signal = make_demo_signal("EURUSD", "M1", Tick(), rows)
    assert signal["direction"] == "WAIT"
    assert signal["bias"] == "ترتيب زمني غير صالح"


def test_signal_rsi_matches_shared_wilder_rsi_for_the_same_closed_bars():
    from charting.indicators import rsi as shared_rsi
    from intelligence.signal_engine import _rsi

    closes = [1.0 + i * 0.0004 + ((i % 7) - 3) * 0.00017 for i in range(100)]
    assert abs(_rsi(closes, 14) - shared_rsi(closes, 14)[-1]) < 1e-12


def test_signal_flags_a_bullish_close_breakout_and_does_not_sell_into_it():
    # Decline then a decisive close above the prior 20-bar high, followed by a
    # synthetic live bar. The confirmed close is the penultimate input row.
    closes = [1.20 - i * 0.001 for i in range(80)]
    closes += [1.24, 1.24]
    signal = make_demo_signal("EURUSD", "M15", Tick(), bars_from_closes(closes))
    assert signal["bullish_breakout"] is True
    assert signal["direction"] != "SELL"
    assert any("اختراق صاعد" in warning for warning in signal["warnings"])
