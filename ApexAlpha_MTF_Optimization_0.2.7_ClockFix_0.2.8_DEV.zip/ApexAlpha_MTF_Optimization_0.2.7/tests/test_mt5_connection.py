from types import SimpleNamespace
from mt5.connection import MT5Connection


class FakeMT5:
    TIMEFRAME_M15 = 15
    ACCOUNT_TRADE_MODE_DEMO = 0
    ACCOUNT_TRADE_MODE_CONTEST = 2
    ACCOUNT_TRADE_MODE_REAL = 1

    def __init__(self):
        self.events = []
        self.init_count = 0
        self.tick = SimpleNamespace(bid=100.0, ask=100.2, time=1_800_000_000,
                                    time_msc=1_800_000_000_000)
        self.account = SimpleNamespace(login=123, balance=200.0, equity=200.0,
                                       currency="USD", server="DEMO",
                                       trade_mode=self.ACCOUNT_TRADE_MODE_DEMO)

    def initialize(self):
        self.events.append("initialize")
        self.init_count += 1
        return True

    def terminal_info(self):
        return SimpleNamespace(connected=True)

    def account_info(self):
        return self.account

    def symbol_select(self, symbol, enabled):
        self.events.append("select")
        return True

    def copy_rates_from_pos(self, symbol, timeframe, start, count):
        self.events.append("bars")
        return [1, 2]

    def symbol_info_tick(self, symbol):
        self.events.append("tick")
        return self.tick

    def symbol_info(self, symbol):
        return SimpleNamespace(digits=2, point=0.01)

    def last_error(self):
        return (1, "Success")


def test_latest_tick_is_requested_after_bars_and_connection_is_reused():
    connection = MT5Connection()
    fake = FakeMT5()
    connection.mt5 = fake

    first = connection.connect_and_read("BTCUSD", "M15")
    second = connection.connect_and_read("BTCUSD", "M15")

    assert first["ok"] and second["ok"]
    assert fake.init_count == 1
    assert fake.events.index("bars") < fake.events.index("tick")
    assert first["tick"].bid == 100.0
    assert first["read_received_epoch"] > 0
    assert "(محلي)" in first["read_received_local_label"]


def test_read_only_account_snapshot_includes_positions_and_daily_result():
    connection = MT5Connection()
    fake = FakeMT5()
    fake.account.profit = 12.5
    fake.account.margin = 25.0
    fake.account.margin_free = 175.0
    fake.POSITION_TYPE_BUY = 0
    fake.positions_get = lambda: [SimpleNamespace(
        ticket=77, symbol="BTCUSD", type=0, volume=0.1, price_open=80000.0,
        price_current=80125.0, profit=12.5, swap=0.0, sl=79000.0, tp=82000.0
    )]
    fake.history_deals_get = lambda start, end: [SimpleNamespace(
        profit=5.0, commission=-0.5, swap=0.3, fee=-0.1
    )]
    connection.mt5 = fake
    result = connection.connect_and_read("BTCUSD", "M15")
    assert result["ok"]
    account = result["account"]
    assert account["floating_pnl"] == 12.5
    assert account["margin"] == 25.0
    assert account["margin_free"] == 175.0
    assert account["positions_count"] == 1
    assert account["open_positions"][0]["ticket"] == 77
    assert abs(account["today_realized_pnl"] - 4.7) < 1e-9
    assert account["today_pnl_available"] is True


def test_disconnected_terminal_fails_closed_even_if_cached_account_exists():
    connection = MT5Connection()
    fake = FakeMT5()
    fake.terminal_info = lambda: SimpleNamespace(connected=False)
    connection.mt5 = fake

    result = connection.connect_and_read("BTCUSD", "M15")

    assert result["ok"] is False
    assert "اتصالها بخادم الوسيط منقطع" in result["error"]
    assert "bars" not in fake.events
    assert "tick" not in fake.events


def test_context_reader_rejects_disconnected_terminal_before_fetching_bars():
    connection = MT5Connection()
    fake = FakeMT5()
    fake.terminal_info = lambda: SimpleNamespace(connected=False)
    connection.mt5 = fake

    result = connection.read_context_frames("BTCUSD")

    assert result["ok"] is False
    assert "اتصالها بخادم الوسيط منقطع" in result["error"]
    assert "bars" not in fake.events


def test_chart_reader_rejects_disconnected_terminal_before_fetching_bars():
    connection = MT5Connection()
    fake = FakeMT5()
    fake.terminal_info = lambda: SimpleNamespace(connected=False)
    connection.mt5 = fake

    result = connection.read_chart_data("BTCUSD", "M15")

    assert result["ok"] is False
    assert "اتصالها بخادم الوسيط منقطع" in result["error"]
    assert "bars" not in fake.events
