from intelligence.momentum_volatility import analyze_momentum_volatility


def make_rates(count=100, step=8.0):
    rows=[]
    for i in range(count):
        c=50000+i*step
        rows.append({"time": 1_800_000_000+i*900, "open":c-step/3,
                     "high":c+4, "low":c-4, "close":c, "tick_volume":100})
    return rows


def test_reports_momentum_volatility_without_trade_signal():
    result=analyze_momentum_volatility(make_rates())
    assert result["status"] == "VALID"
    assert result["momentum"] in {"BULLISH", "BEARISH", "MIXED", "NEUTRAL", "UNKNOWN"}
    assert result["volatility"] in {"EXPANDED", "CONTRACTED", "NORMAL", "UNKNOWN"}
    assert "signal" not in result and "order" not in result


def test_excludes_forming_bar_from_calculation():
    rates=make_rates()
    first=analyze_momentum_volatility(rates)
    rates[-1]["close"] = 1.0e9
    second=analyze_momentum_volatility(rates)
    assert first["rsi14"] == second["rsi14"]
    assert first["atr14"] == second["atr14"]


def test_insufficient_history_is_explicit():
    result=analyze_momentum_volatility(make_rates(30))
    assert result["status"] == "INSUFFICIENT"
    assert result["momentum"] == "UNKNOWN"
