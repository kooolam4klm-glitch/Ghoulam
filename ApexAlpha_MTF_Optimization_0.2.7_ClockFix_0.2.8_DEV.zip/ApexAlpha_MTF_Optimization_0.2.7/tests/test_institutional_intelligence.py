from intelligence.institutional_intelligence import analyze_institutional_context
from intelligence.analysis_arm import build_analysis_report


def make_rates(count=80):
    rows = []
    for i in range(count):
        c = 100.0 + (i % 7) * 0.15 + i * 0.02
        rows.append({"time": 1_800_000_000 + i * 900, "open": c - 0.1,
                     "high": c + 0.2, "low": c - 0.2, "close": c,
                     "tick_volume": 100})
    return rows


def test_institutional_context_is_read_only_and_never_emits_trade_action():
    result = analyze_institutional_context(make_rates())
    assert result["status"] == "VALID"
    assert "BUY" not in result
    assert "SELL" not in result
    assert "orders" not in result


def test_institutional_context_excludes_forming_candle():
    rows = make_rates()
    baseline = analyze_institutional_context(rows)
    rows[-1] = {"time": rows[-1]["time"], "open": 9999, "high": 10000,
                "low": 1, "close": 9999, "tick_volume": 999}
    changed = analyze_institutional_context(rows)
    assert changed == baseline


def test_insufficient_history_is_explicit():
    result = analyze_institutional_context(make_rates(20))
    assert result["status"] == "INSUFFICIENT"
    assert result["liquidity_sweeps"] == []


def test_analysis_report_includes_institutional_context_per_timeframe():
    rows = make_rates(100)
    report = build_analysis_report({"M15": rows, "H1": rows, "H4": rows})
    assert report["version"] == "0.2.6"
    assert report["timeframes"]["M15"]["institutional"]["status"] == "VALID"
    assert report["trading_enabled"] is False


def test_closed_bar_dataset_can_be_used_without_dropping_last_bar():
    rows = make_rates(40)
    result = analyze_institutional_context(rows, forming_candle=False)
    assert result["last_closed_candle_time"] == rows[-1]["time"]


def test_invalid_lookback_is_insufficient():
    result = analyze_institutional_context(make_rates(50), lookback=10)
    assert result["status"] == "INSUFFICIENT"

