from intelligence.multi_timeframe import apply_multi_timeframe_gate


def signal(direction):
    return {
        "symbol": "BTCUSD", "direction": direction, "confidence": 80,
        "entry": 100.0, "stop_loss": 95.0, "take_profit": 110.0,
        "warnings": [], "summary": "test summary",
    }


def context(code, bullish=0, bearish=0, neutral=0, usable=3):
    return {
        "overall_code": code, "overall": code,
        "counts": {"bullish": bullish, "bearish": bearish,
                  "neutral": neutral, "usable": usable},
    }


def test_sell_is_blocked_when_higher_timeframes_align_bullish():
    result = apply_multi_timeframe_gate(signal("SELL"), context("BULLISH_ALIGNMENT", bullish=3, usable=3))
    assert result["direction"] == "WAIT"
    assert result["entry"] is None and result["stop_loss"] is None and result["take_profit"] is None
    assert "رفض البيع" in result["warnings"][-1]


def test_buy_is_blocked_when_higher_timeframes_align_bearish():
    result = apply_multi_timeframe_gate(signal("BUY"), context("BEARISH_ALIGNMENT", bearish=3, usable=3))
    assert result["direction"] == "WAIT"
    assert result["entry"] is None
    assert "رفض الشراء" in result["warnings"][-1]


def test_conflicting_or_missing_context_never_approves_direction():
    for ctx in (context("CONFLICT", bullish=1, bearish=1, neutral=1), None,
                context("INSUFFICIENT", usable=0)):
        result = apply_multi_timeframe_gate(signal("SELL"), ctx)
        assert result["direction"] == "WAIT"
        assert result["entry"] is None


def test_aligned_signal_is_not_blocked():
    result = apply_multi_timeframe_gate(signal("BUY"), context("BULLISH_ALIGNMENT", bullish=3, usable=3))
    assert result["direction"] == "BUY"
    assert result["entry"] == 100.0
