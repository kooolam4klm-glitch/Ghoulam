from interface.signal_presentation import format_signal_badge


def test_wait_badge_shows_highest_rule_alignment_score():
    text = format_signal_badge({"direction": "WAIT", "confidence": 63, "symbol": "BTCUSD"})
    assert text == "WAIT • أعلى توافق للقواعد 63/100 — BTCUSD"
    assert "%" not in text


def test_buy_badge_labels_score_as_rule_alignment():
    text = format_signal_badge({"direction": "BUY", "confidence": 72, "symbol": "EURUSD"})
    assert text == "BUY • توافق القواعد 72/100 — EURUSD"


def test_missing_confidence_does_not_invent_a_score():
    text = format_signal_badge({"direction": "WAIT", "symbol": "BTCUSD"})
    assert text == "WAIT — BTCUSD"


def test_non_dict_signal_is_safe():
    assert format_signal_badge(None) == "WAIT — —"
