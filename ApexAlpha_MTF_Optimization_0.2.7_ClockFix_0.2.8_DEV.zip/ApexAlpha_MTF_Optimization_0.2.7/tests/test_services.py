from services.openai_client import chat_completion
from services.voice_notifier import VoiceNotifier


def test_openai_client_rejects_non_https_before_network():
    try:
        chat_completion("not-a-real-key", "gpt-4o-mini", "http://example.test/v1", [])
    except ValueError as exc:
        assert "https://" in str(exc)
    else:
        raise AssertionError("non-HTTPS API URL should be rejected")


def test_voice_notifier_respects_disabled_setting():
    notifier = VoiceNotifier()
    assert notifier.speak("This should not speak", language="en", enabled=False) is False
