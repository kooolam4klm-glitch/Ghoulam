import time

from bridge.price_bridge import PriceBridgeServer


def test_bridge_accepts_valid_local_tick():
    server = PriceBridgeServer()
    seen = []
    server.on_tick = seen.append
    now_ms = int(time.time() * 1000)
    server._accept_message({
        "type": "tick", "symbol": "BTCUSD", "time": now_ms // 1000,
        "time_msc": now_ms, "bid": 80000.0, "ask": 80005.0,
        "last": 0, "volume": 0, "flags": 2, "volume_real": 0.0,
    })
    latest = server.get_latest("BTCUSD", max_age_seconds=2)
    assert latest is not None
    assert latest["tick"].bid == 80000.0
    assert latest["tick"].ask == 80005.0
    assert seen and seen[0]["symbol"] == "BTCUSD"


def test_bridge_rejects_invalid_quote():
    server = PriceBridgeServer()
    server._accept_message({
        "type": "tick", "symbol": "BTCUSD", "time": 1,
        "time_msc": 1, "bid": 80000.0, "ask": 79999.0,
    })
    assert server.get_latest("BTCUSD") is None


def test_bridge_requires_type_and_symbol():
    server = PriceBridgeServer()
    now_ms = int(time.time() * 1000)
    server._accept_message({"type": "other", "symbol": "BTCUSD", "time_msc": now_ms,
                            "bid": 1.0, "ask": 2.0})
    server._accept_message({"type": "tick", "symbol": "", "time_msc": now_ms,
                            "bid": 1.0, "ask": 2.0})
    assert server.get_latest("BTCUSD") is None


def test_bridge_preserves_explicit_server_offset_metadata():
    server = PriceBridgeServer()
    now_ms = int(time.time() * 1000)
    server._accept_message({
        "type": "tick", "symbol": "BTCUSD", "time": now_ms // 1000,
        "time_msc": now_ms, "bid": 80000.0, "ask": 80005.0,
        "server_time": now_ms // 1000 + 7200,
        "gmt_time": now_ms // 1000,
        "server_utc_offset_seconds": 7200,
    })
    latest = server.get_latest("BTCUSD", max_age_seconds=2)
    assert latest is not None
    assert latest["tick"].broker_offset_seconds == 7200
    assert latest["broker_offset_seconds"] == 7200


def test_bridge_rejects_implausible_server_offset():
    server = PriceBridgeServer()
    now_ms = int(time.time() * 1000)
    server._accept_message({
        "type": "tick", "symbol": "BTCUSD", "time": now_ms // 1000,
        "time_msc": now_ms, "bid": 80000.0, "ask": 80005.0,
        "server_utc_offset_seconds": 99 * 3600,
    })
    assert server.get_latest("BTCUSD") is None
