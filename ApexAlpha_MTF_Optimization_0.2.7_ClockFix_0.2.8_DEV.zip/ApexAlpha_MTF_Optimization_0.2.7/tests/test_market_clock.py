from intelligence.market_clock import TickClockTracker, gate_signal


class Tick:
    def __init__(self, timestamp=None, time_msc=None):
        self.time = timestamp or 0
        self.time_msc = time_msc or 0


def test_standard_epoch_tick_is_fresh():
    tracker = TickClockTracker(max_age_seconds=180)
    status = tracker.update(Tick(time_msc=1_800_000_000_000), now_epoch=1_800_000_002, monotonic_now=10)
    assert status["status"] == "fresh"
    assert status["is_fresh"] is True
    assert status["offset_seconds"] == 0


def test_old_tick_is_not_fresh():
    tracker = TickClockTracker(max_age_seconds=180)
    status = tracker.update(Tick(time_msc=1_800_000_000_000), now_epoch=1_800_000_400, monotonic_now=10)
    assert status["status"] == "stale"
    assert status["is_fresh"] is False


def test_future_tick_is_not_silently_timezone_corrected():
    tracker = TickClockTracker(max_age_seconds=180)
    now = 1_800_000_000.0
    future = tracker.update(
        Tick(time_msc=int((now + 3 * 3600) * 1000)),
        now_epoch=now, monotonic_now=10,
    )
    assert future["status"] == "clock_ahead"
    assert future["is_fresh"] is False
    assert future["offset_seconds"] == 0
    assert future["corrected_timestamp"] == future["raw_timestamp"]
    assert "لم يتم اختراع فرق توقيت" in future["message"]

def test_unconfirmed_or_stale_market_forces_wait_and_clears_levels():
    signal = {"direction": "BUY", "entry": 100.0, "stop_loss": 95.0,
              "take_profit": 110.0, "summary": "test summary", "symbol": "BTCUSD"}
    safe = gate_signal(signal, {"is_fresh": False, "message": "clock unresolved"})
    assert safe["direction"] == "WAIT"
    assert safe["entry"] is None
    assert safe["stop_loss"] is None
    assert safe["take_profit"] is None
    assert "clock unresolved" in safe["summary"]


def test_timestamp_has_explicit_utc_and_local_views_without_guessing_offset():
    tracker = TickClockTracker(max_age_seconds=180)
    now = 1_800_000_002.0
    result = tracker.update(Tick(time_msc=1_800_000_000_000), now_epoch=now, monotonic_now=10)
    assert result["is_fresh"] is True
    assert result["offset_seconds"] == 0
    assert result["corrected_timestamp"] == result["raw_timestamp"]
    assert result["raw_time_label"].endswith("UTC")
    assert result["corrected_utc_label"].endswith("UTC")
    assert "(محلي)" in result["corrected_local_label"]

def test_standard_tick_has_matching_raw_and_corrected_epochs():
    tracker = TickClockTracker(max_age_seconds=180)
    now = 1_800_000_002.0
    result = tracker.update(Tick(time_msc=1_800_000_000_000),
                            now_epoch=now, monotonic_now=10)
    assert result["is_fresh"] is True
    assert result["offset_seconds"] == 0
    assert result["corrected_timestamp"] == result["raw_timestamp"]


def test_explicit_broker_offset_normalizes_server_epoch_to_utc():
    tracker = TickClockTracker(max_age_seconds=180)
    now = 1_800_000_000.0
    server_tick = Tick(time_msc=int((now + 2 * 3600) * 1000))
    result = tracker.update(server_tick, now_epoch=now + 2,
                            broker_offset_seconds=2 * 3600)
    assert result["status"] == "fresh"
    assert result["is_fresh"] is True
    assert result["offset_seconds"] == 7200
    assert result["corrected_timestamp"] == now + 2 * 3600 - 7200


def test_invalid_broker_offset_fails_closed():
    tracker = TickClockTracker(max_age_seconds=180)
    now = 1_800_000_000.0
    result = tracker.update(Tick(time_msc=int(now * 1000)), now_epoch=now,
                            broker_offset_seconds=99 * 3600)
    assert result["status"] == "clock_offset_invalid"
    assert result["is_fresh"] is False


def test_missing_broker_offset_does_not_guess_timezone():
    tracker = TickClockTracker(max_age_seconds=180)
    now = 1_800_000_000.0
    result = tracker.update(Tick(time_msc=int((now + 7200) * 1000)), now_epoch=now)
    assert result["status"] == "clock_ahead"
    assert result["offset_seconds"] == 0
