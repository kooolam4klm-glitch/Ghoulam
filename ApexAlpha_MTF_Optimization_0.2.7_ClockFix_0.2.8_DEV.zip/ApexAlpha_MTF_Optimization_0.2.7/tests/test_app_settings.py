import json
from pathlib import Path

from config import app_settings


def test_settings_defaults_keep_live_execution_disabled():
    data = dict(app_settings.DEFAULTS)
    data["live_order_execution"] = True
    data["simulation_only"] = False
    assert app_settings.load_settings.__name__ == "load_settings"
    # The reader hard-forces safety switches regardless of file contents.
    temporary = app_settings.SETTINGS_PATH
    try:
        app_settings.SETTINGS_PATH = Path(__file__).with_name("_settings_test_temp.json")
        app_settings.SETTINGS_PATH.write_text(json.dumps(data), encoding="utf-8")
        loaded = app_settings.load_settings()
        assert loaded["simulation_only"] is True
        assert loaded["live_order_execution"] is False
        assert loaded["language"] == "ar"
        assert loaded["theme"] == "dark"
        assert loaded["ai_enabled"] is True
        assert loaded["voice_language"] == "auto"
        assert loaded["risk_percent"] == 1.0
    finally:
        app_settings.SETTINGS_PATH.unlink(missing_ok=True)
        app_settings.SETTINGS_PATH = temporary


def test_save_settings_never_serializes_api_key_field(tmp_path):
    temporary = app_settings.SETTINGS_PATH
    try:
        app_settings.SETTINGS_PATH = tmp_path / "settings.json"
        result = app_settings.save_settings({"language": "fr", "theme": "dark", "voice_language": "ru", "risk_percent": 0.8, "api_key": "SECRET_SHOULD_NOT_BE_STORED"})
        text = app_settings.SETTINGS_PATH.read_text(encoding="utf-8")
        assert result["language"] == "fr"
        assert result["voice_language"] == "ru"
        assert result["risk_percent"] == 0.8
        assert "SECRET_SHOULD_NOT_BE_STORED" not in text
        assert "api_key" not in text
        assert result["live_order_execution"] is False
    finally:
        app_settings.SETTINGS_PATH = temporary
