from intelligence.analysis_arm import build_analysis_report


def rates(direction=1, count=121):
    rows = []
    base = 70000.0
    for i in range(count):
        close = base + direction * i * 10.0
        rows.append({
            "time": 1_800_000_000 + i * 900,
            "open": close - direction,
            "high": close + 5.0,
            "low": close - 5.0,
            "close": close,
            "tick_volume": 100 + i % 10,
        })
    return rows


def test_report_is_read_only_and_contains_mtf_indicator_and_structure_context():
    report = build_analysis_report({"M15": rates(), "H1": rates(), "H4": rates()}, symbol="BTCUSD")
    assert report["status"] == "READY"
    assert report["read_only"] is True
    assert report["trading_enabled"] is False
    assert report["valid_timeframes"] == 3
    assert report["multi_timeframe"]["overall_code"] == "BULLISH_ALIGNMENT"
    assert report["timeframes"]["M15"]["indicators"]["rsi14"] is not None
    assert report["timeframes"]["M15"]["structure"]["code"] in {
        "BULLISH_STRUCTURE", "BEARISH_STRUCTURE", "MIXED_STRUCTURE", "INSUFFICIENT_SWINGS"
    }


def test_invalid_time_order_is_excluded_and_report_warns():
    broken = rates()
    broken[20], broken[21] = broken[21], broken[20]
    report = build_analysis_report({"M15": broken, "H1": rates(), "H4": rates()})
    assert report["timeframes"]["M15"]["data_quality"] == "INVALID_OR_INSUFFICIENT"
    assert report["timeframes"]["M15"]["indicators"] is None
    assert any("ترتيب زمني" in warning for warning in report["warnings"])


def test_insufficient_frames_never_claim_ready():
    report = build_analysis_report({"M15": rates(count=30), "H1": [], "H4": []})
    assert report["status"] == "INSUFFICIENT_DATA"
    assert report["trading_enabled"] is False


def test_bad_ohlc_is_rejected():
    broken = rates()
    broken[10]["high"] = broken[10]["low"] - 1
    report = build_analysis_report({"M15": broken, "H1": rates(), "H4": rates()})
    assert report["timeframes"]["M15"]["data_quality"] == "INVALID_OR_INSUFFICIENT"
