import json
import pytest
from bridge.indicator_signal_reader import read_indicator_snapshot, IndicatorSnapshotError

def payload(**overrides):
    d = {"schema":1,"source":"ApexAlpha_MT5_Indicator","symbol":"BTCUSD","timeframe":"M15",
         "direction":"WAIT","score":40,"bar_time":1000,"bid":65000.0,"ask":65001.0,
         "atr":100.0,"entry":0.0,"stop_loss":0.0,"tp1":0.0,"tp2":0.0,
         "pivot_high":65100.0,"pivot_low":64900.0,"trading_enabled":False}
    d.update(overrides); return d

def test_reads_valid_snapshot(tmp_path):
    p=tmp_path/"snapshot.json"; p.write_text(json.dumps(payload()),encoding="utf-8")
    out=read_indicator_snapshot(p,expected_symbol="BTCUSD",expected_timeframe="M15",now_epoch=1005)
    assert out["direction"] == "WAIT" and out["read_only"] is True and out["age_seconds"] == 5

@pytest.mark.parametrize("updates", [
    {"symbol":"EURUSD"}, {"timeframe":"H1"}, {"direction":"TRADE"},
    {"trading_enabled":True}, {"score":101}, {"ask":64000}, {"bar_time":1}
])
def test_rejects_mismatched_or_unsafe_snapshot(tmp_path, updates):
    p=tmp_path/"snapshot.json"; p.write_text(json.dumps(payload(**updates)),encoding="utf-8")
    with pytest.raises(IndicatorSnapshotError):
        read_indicator_snapshot(p,expected_symbol="BTCUSD",expected_timeframe="M15",max_age_seconds=100,now_epoch=1005)
