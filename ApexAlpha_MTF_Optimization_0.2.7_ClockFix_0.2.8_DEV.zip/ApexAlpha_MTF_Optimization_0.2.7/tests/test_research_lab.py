import random
from research.experiment_runner import ExperimentConfig, compare_experiments
from intelligence.backtest import run_backtest


def make_rows(n=240):
    rng = random.Random(44)
    price = 100.0
    rows = []
    for i in range(n):
        drift = 0.08 if i < n // 2 else -0.025
        old = price
        price += drift + rng.uniform(-0.28, 0.28)
        rows.append({"time": 1_800_000_000 + i * 60,
                     "open": (old + price) / 2,
                     "high": max(old, price) + 0.18,
                     "low": min(old, price) - 0.18,
                     "close": price})
    return rows


def test_backtest_start_index_keeps_holdout_trades_after_boundary(monkeypatch):
    import intelligence.backtest as bt

    def buy_signal(*args, **kwargs):
        return {"direction": "BUY", "atr": 0.2, "confidence": 80,
                "strategy_id": "TEST", "multi_timeframe_gate": "NOT_USED"}

    monkeypatch.setattr(bt, "make_demo_signal", buy_signal)
    rows = make_rows(180)
    boundary = 120
    result = run_backtest(rows, min_bars=60, start_index=boundary,
                          stop_atr=1.0, reward_risk=1.0)
    assert result["ok"]
    assert all(t["entry_index"] > boundary for t in result["trades"])


def test_compare_experiments_reports_train_and_holdout_separately():
    rows = make_rows()
    configs = [
        ExperimentConfig("rr15", stop_atr=1.5, reward_risk=1.5),
        ExperimentConfig("rr20", stop_atr=1.5, reward_risk=2.0),
    ]
    result = compare_experiments(rows, configs, train_fraction=0.7, min_bars=100)
    assert result["ok"]
    assert result["train_bar_count"] == 168
    assert result["holdout_bar_count"] == 72
    assert len(result["results"]) == 2
    for item in result["results"]:
        assert item["train_ok"] and item["holdout_ok"]
        assert "expectancy_cash_per_trade" in item["holdout"]
        assert "single holdout" in result["warning"]


def test_compare_experiments_rejects_nonchronological_rows():
    rows = make_rows(160)
    rows[80], rows[81] = rows[81], rows[80]
    result = compare_experiments(rows, [ExperimentConfig("one")], min_bars=100)
    assert not result["ok"]
    assert "strictly chronological" in result["error"]


def test_compare_experiments_requires_configs_and_sufficient_history():
    rows = make_rows(80)
    assert not compare_experiments(rows, [ExperimentConfig("one")], min_bars=100)["ok"]
    assert not compare_experiments(make_rows(180), [], min_bars=100)["ok"]
