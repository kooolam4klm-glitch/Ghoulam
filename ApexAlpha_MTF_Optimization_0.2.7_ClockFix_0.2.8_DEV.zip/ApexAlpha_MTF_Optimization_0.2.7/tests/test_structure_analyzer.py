from intelligence.structure_analyzer import analyze_market_structure


def make_rates(count=150):
    rows=[]
    for i in range(count):
        # Deterministic stair-step swings with enough range for ATR and pivots.
        base=100 + i*0.12 + (8 if (i//8)%2 else -8)
        rows.append({"time": 1_800_000_000+i*900, "open":base-0.3,
                     "high":base+1.0, "low":base-1.0, "close":base,
                     "tick_volume":100})
    return rows


def test_structure_output_is_read_only_context_and_has_confirmed_swings():
    result=analyze_market_structure(make_rates())
    assert result["status"] == "VALID"
    assert result["bias"] in {"BULLISH", "BEARISH", "MIXED"}
    assert result["swings"]
    assert "institutional" in result["explanation"] or "مؤسسية" in result["explanation"]


def test_insufficient_data_is_not_fabricated():
    result=analyze_market_structure(make_rates(10))
    assert result["status"] == "INSUFFICIENT"
    assert result["events"] == []


def test_latest_forming_candle_is_excluded_from_swings():
    rows=make_rates()
    before=analyze_market_structure(rows)
    rows[-1]["high"] = 1_000_000
    after=analyze_market_structure(rows)
    assert before["swings"] == after["swings"]
