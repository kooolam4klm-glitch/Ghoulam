from charting.indicators import (
    sma, ema, bollinger, rsi, macd, support_resistance,
    atr_series, latest_indicator_values, recommend_chart_tools, evaluate_enabled_indicators,
)


def synthetic_rates(n=100):
    rows = []
    price = 100.0
    for i in range(n):
        price += 0.3 + ((i % 5) - 2) * 0.04
        rows.append({
            "time": 1_700_000_000 + i * 60,
            "open": price - 0.2,
            "high": price + 0.7,
            "low": price - 0.8,
            "close": price,
            "tick_volume": 100 + (i % 17),
        })
    return rows


def test_sma_ema_have_expected_warmup_and_values():
    values = [1.0, 2.0, 3.0, 4.0, 5.0]
    assert sma(values, 3) == [None, None, 2.0, 3.0, 4.0]
    output = ema(values, 3)
    assert output[:2] == [None, None]
    assert output[2] == 2.0
    assert output[-1] is not None and output[-1] > output[-2]


def test_bollinger_bounds_surround_middle_for_rising_series():
    values = [float(i) for i in range(30)]
    middle, upper, lower = bollinger(values, 5, 2.0)
    assert middle[-1] == 27.0
    assert upper[-1] > middle[-1] > lower[-1]


def test_rsi_is_bounded():
    values = [float(i) for i in range(40)]
    values_rsi = rsi(values, 14)
    assert values_rsi[13] is None
    assert values_rsi[-1] == 100.0
    assert all(v is None or 0 <= v <= 100 for v in values_rsi)


def test_macd_outputs_are_aligned_with_input():
    values = [100 + i * 0.2 for i in range(80)]
    line, signal, hist = macd(values)
    assert len(line) == len(signal) == len(hist) == len(values)
    assert line[24] is None
    assert line[-1] is not None and signal[-1] is not None and hist[-1] is not None


def test_atr_positive_and_same_length():
    rates = synthetic_rates(80)
    result = atr_series(rates, 14)
    assert len(result) == len(rates)
    assert result[12] is None
    assert result[-1] is not None and result[-1] > 0


def test_support_resistance_use_previous_closed_candles():
    rates = synthetic_rates(30)
    support, resistance = support_resistance(rates, 20)
    assert support is not None and resistance is not None
    assert support < resistance
    # An extreme high on the final forming candle should be ignored.
    rates[-1]["high"] = 100000
    _, resistance2 = support_resistance(rates, 20)
    assert resistance2 == resistance


def test_latest_indicator_values_expose_auto_tool_metrics():
    values = latest_indicator_values(synthetic_rates(100))
    assert values["sma10"] is not None
    assert values["sma30"] is not None
    assert values["ema20"] is not None
    assert values["rsi14"] is not None
    assert values["atr14"] is not None and values["atr14"] > 0
    assert values["atr_ratio"] is not None
    assert values["trend_spread_atr"] is not None


def test_auto_tool_recommendation_has_explicit_volatility_preset():
    preset, reason = recommend_chart_tools(1.8, 0.2)
    assert preset["bollinger"] is True
    assert preset["rsi"] is True
    assert preset["macd"] is False
    assert "تقلب مرتفع" in reason


def test_auto_tool_recommendation_has_trend_preset():
    preset, reason = recommend_chart_tools(1.0, 0.8)
    assert preset["ema20"] is True
    assert preset["macd"] is True
    assert preset["bollinger"] is False
    assert "تباعد المتوسطين" in reason


def test_auto_tool_recommendation_handles_missing_metrics():
    preset, reason = recommend_chart_tools(None, None)
    assert preset["sma10"] is True and preset["sr"] is True
    assert "الاتجاه غير قوي" in reason


def test_enabled_indicator_analysis_returns_context_not_order():
    rates = synthetic_rates(120)
    result = evaluate_enabled_indicators(rates, {
        "sma10": True, "sma30": True, "ema20": True, "rsi": True,
        "macd": True, "bollinger": True, "sr": True, "atr": True, "volume": True,
    })
    assert result["status"] in {"BULLISH_CONTEXT", "BEARISH_CONTEXT", "MIXED_CONTEXT", "NO_VOTES", "INSUFFICIENT"}
    assert "تداول" not in result["label"] or result["label"]
    assert isinstance(result["votes"], list)


def test_disabling_directional_indicators_removes_votes():
    result = evaluate_enabled_indicators(synthetic_rates(100), {"sma10": False, "sma30": False, "ema20": False, "rsi": False, "macd": False})
    assert result["status"] == "NO_VOTES"
    assert result["votes"] == []


def test_confirmed_swing_points_report_when_the_pivot_became_confirmed():
    from charting.indicators import confirmed_swing_points

    rows = []
    highs = [3, 4, 7, 10, 8, 6, 5, 6, 7]
    lows = [1, 2, 3, 4, 3, 2, 1, 2, 3]
    for i, (high, low) in enumerate(zip(highs, lows)):
        rows.append({"time": 1_700_000_000 + i * 60, "open": (high + low) / 2,
                     "high": high, "low": low, "close": (high + low) / 2})
    points = confirmed_swing_points(rows, left_bars=2, right_bars=2)
    high_point = next(point for point in points if point["kind"] == "HIGH")
    assert high_point["index"] == 3
    assert high_point["price"] == 10
    assert high_point["confirmed_at_index"] == 5
    assert high_point["confirmed_at_time"] == rows[5]["time"]


def test_equal_highs_do_not_create_ambiguous_swing_top_labels():
    from charting.indicators import confirmed_swing_points

    highs = [1, 2, 5, 5, 4, 3, 2]
    rows = [{"open": h - 0.2, "high": h, "low": h - 1, "close": h - 0.1} for h in highs]
    assert not [point for point in confirmed_swing_points(rows, 1, 1) if point["kind"] == "HIGH"]


def test_latest_indicator_values_exclude_the_forming_bar():
    rows = synthetic_rates(50)
    before = latest_indicator_values(rows)
    rows[-1]["close"] = rows[-1]["high"]
    rows[-1]["high"] = rows[-1]["close"] + 1000
    after = latest_indicator_values(rows)
    # An extreme live candle must not contaminate closed-bar indicators.
    assert after["close"] == before["close"]
    assert after["rsi14"] == before["rsi14"]
    assert after["sma10"] == before["sma10"]


def test_latest_indicator_support_resistance_uses_exactly_last_20_closed_bars():
    rows = synthetic_rates(26)
    # The final row is treated as forming and must not affect closed-bar levels.
    rows[-1]["high"] = 1_000_000
    rows[-1]["low"] = -1_000_000
    values = latest_indicator_values(rows)
    closed_window = rows[5:25]
    assert values["support20"] == min(row["low"] for row in closed_window)
    assert values["resistance20"] == max(row["high"] for row in closed_window)


def test_confirmed_swing_requires_right_side_closed_bars():
    from charting.indicators import confirmed_swing_points

    highs = [1, 2, 5, 3, 2]
    rows = [{"time": 1_700_000_000 + i * 60, "open": h - 0.2,
             "high": h, "low": h - 1, "close": h - 0.1}
            for i, h in enumerate(highs)]
    points = confirmed_swing_points(rows, left_bars=1, right_bars=2)
    assert any(point["kind"] == "HIGH" and point["index"] == 2
               and point["confirmed_at_index"] == 4 for point in points)
    assert not any(point["kind"] == "HIGH" and point["index"] == 3 for point in points)
