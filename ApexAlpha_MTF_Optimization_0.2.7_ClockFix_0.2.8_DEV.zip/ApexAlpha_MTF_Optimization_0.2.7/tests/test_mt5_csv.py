import csv
from pathlib import Path

from run_research_lab import load_csv


def test_load_native_mt5_tab_separated_export(tmp_path: Path):
    path = tmp_path / "rates.csv"
    path.write_text(
        "<DATE>\t<TIME>\t<OPEN>\t<HIGH>\t<LOW>\t<CLOSE>\t<TICKVOL>\t<VOL>\t<SPREAD>\n"
        "2026.10.26\t00:00:00\t80383.30\t80417.56\t80341.69\t80382.31\t4341\t0\t500\n"
        "2026.10.26\t00:15:00\t80382.32\t80422.54\t80270.37\t80414.46\t5676\t0\t500\n",
        encoding="utf-8",
    )
    rows = load_csv(path)
    assert len(rows) == 2
    assert rows[0]["open"] == 80383.30
    assert rows[0]["close"] == 80382.31
    assert rows[1]["time"] - rows[0]["time"] == 15 * 60
    assert rows[0]["spread_points"] == 500.0


def test_load_normalized_csv_still_works(tmp_path: Path):
    path = tmp_path / "normalized.csv"
    path.write_text(
        "time,open,high,low,close\n1800000000,100,102,99,101\n1800000060,101,103,100,102\n",
        encoding="utf-8",
    )
    rows = load_csv(path)
    assert rows == [
        {"time": 1800000000, "open": 100.0, "high": 102.0, "low": 99.0, "close": 101.0},
        {"time": 1800000060, "open": 101.0, "high": 103.0, "low": 100.0, "close": 102.0},
    ]
