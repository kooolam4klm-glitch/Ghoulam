from intelligence.multi_timeframe import analyze_timeframe, analyze_multi_timeframe


def bars_for_trend(direction=1, count=121):
    rows = []
    base = 70000.0
    for i in range(count):
        close = base + direction * i * 10.0
        rows.append({
            "time": 1_800_000_000 + i * 900,
            "open": close - direction * 1.0,
            "high": close + 5.0,
            "low": close - 5.0,
            "close": close,
        })
    return rows


def test_uptrend_context_is_bullish_and_uses_closed_candles():
    rows = bars_for_trend(1)
    result = analyze_timeframe("M15", rows)
    assert result["ok"] is True
    assert result["bias_code"] == "BULLISH"
    assert result["close"] == rows[-2]["close"]
    assert "تقلب" in result["regime"]


def test_downtrend_context_is_bearish():
    result = analyze_timeframe("H1", bars_for_trend(-1))
    assert result["ok"] is True
    assert result["bias_code"] == "BEARISH"


def test_insufficient_candles_are_not_guessed():
    result = analyze_timeframe("H4", bars_for_trend(1, count=40))
    assert result["ok"] is False
    assert result["bias_code"] == "UNKNOWN"


def test_multi_timeframe_alignment_is_context_not_order():
    frames = {
        "M15": bars_for_trend(1),
        "H1": bars_for_trend(1),
        "H4": bars_for_trend(1),
    }
    result = analyze_multi_timeframe(frames)
    assert result["overall_code"] == "BULLISH_ALIGNMENT"
    assert "فلتر أمان" in result["note"]
    assert "order" not in result


def test_conflicting_timeframes_are_flagged():
    frames = {
        "M15": bars_for_trend(1),
        "H1": bars_for_trend(-1),
        "H4": bars_for_trend(1),
    }
    result = analyze_multi_timeframe(frames)
    assert result["overall_code"] == "CONFLICT"


def test_multi_timeframe_rejects_non_monotonic_bar_order():
    rows = bars_for_trend(1)
    rows[30], rows[31] = rows[31], rows[30]
    result = analyze_timeframe("H1", rows)
    assert result["ok"] is False
    assert result["bias_code"] == "UNKNOWN"
    assert "مرتبة" in result["message"]
