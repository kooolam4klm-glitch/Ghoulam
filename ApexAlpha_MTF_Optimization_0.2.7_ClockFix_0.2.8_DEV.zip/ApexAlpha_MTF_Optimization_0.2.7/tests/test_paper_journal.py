from storage import paper_journal as journal


def _signal(direction="BUY", entry=100.0, stop=95.0, target=110.0, bar_time=123):
    return {
        "direction": direction,
        "entry": entry,
        "stop_loss": stop,
        "take_profit": target,
        "strategy_id": "TEST_STRATEGY",
        "signal_bar_time": bar_time,
    }


def test_signal_is_recorded_once_per_bar_and_decision_is_persisted(tmp_path, monkeypatch):
    monkeypatch.setattr(journal, "DB_PATH", tmp_path / "journal.sqlite3")
    first = journal.record_shadow_signal(_signal(), "BTCUSD", "M15", 123, 100, "TEST")
    second = journal.record_shadow_signal(_signal(), "BTCUSD", "M15", 123, 100, "TEST")
    assert first is not None and first["created"] is True
    assert second["id"] == first["id"]
    assert second["created"] is False
    assert journal.set_user_decision(first["id"], "APPROVED") is True
    assert journal.set_user_decision(first["id"], "REJECTED") is False
    row = journal.recent_signals(10)[0]
    assert row["user_decision"] == "APPROVED"


def test_buy_shadow_signal_closes_at_take_profit_using_bid(tmp_path, monkeypatch):
    monkeypatch.setattr(journal, "DB_PATH", tmp_path / "journal.sqlite3")
    saved = journal.record_shadow_signal(_signal(), "BTCUSD", "M15", 123, 100, "TEST")
    assert journal.update_open_signals("BTCUSD", 109.0, 109.5, 100) == []  # same tick
    outcomes = journal.update_open_signals("BTCUSD", 110.0, 110.5, 200)
    assert len(outcomes) == 1
    assert outcomes[0]["id"] == saved["id"]
    assert outcomes[0]["status"] == "TP_HIT"
    assert round(outcomes[0]["r_multiple"], 2) == 2.0
    summary = journal.signal_summary()
    assert summary["wins"] == 1 and summary["open"] == 0
    assert summary["win_rate"] == 100.0


def test_sell_shadow_signal_closes_at_stop_using_ask(tmp_path, monkeypatch):
    monkeypatch.setattr(journal, "DB_PATH", tmp_path / "journal.sqlite3")
    signal = _signal(direction="SELL", entry=100.0, stop=105.0, target=90.0, bar_time=456)
    journal.record_shadow_signal(signal, "BTCUSD", "M15", 456, 100, "TEST")
    outcomes = journal.update_open_signals("BTCUSD", 104.9, 105.0, 200)
    assert len(outcomes) == 1
    assert outcomes[0]["status"] == "SL_HIT"
    assert round(outcomes[0]["r_multiple"], 2) == -1.0
    summary = journal.signal_summary()
    assert summary["losses"] == 1 and summary["win_rate"] == 0.0


def test_bad_quote_does_not_change_open_signal(tmp_path, monkeypatch):
    monkeypatch.setattr(journal, "DB_PATH", tmp_path / "journal.sqlite3")
    journal.record_shadow_signal(_signal(), "BTCUSD", "M15", 123, 100, "TEST")
    assert journal.update_open_signals("BTCUSD", 110.0, 109.0, 200) == []
    row = journal.recent_signals(10)[0]
    assert row["status"] == "OPEN"
