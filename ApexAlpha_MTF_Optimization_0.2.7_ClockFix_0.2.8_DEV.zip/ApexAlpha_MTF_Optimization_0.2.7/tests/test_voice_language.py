from services.voice_language import detect_text_language, resolve_voice_language


def test_detects_arabic_and_russian_scripts():
    assert detect_text_language("السوق يتحرك صعودًا", "en") == "ar"
    assert detect_text_language("Рынок растёт", "en") == "ru"


def test_detects_common_french_response():
    assert detect_text_language("Bonjour, le marché est ouvert", "en") == "fr"
    assert detect_text_language("Hello, what is the market trend?", "ar") == "en"


def test_auto_voice_language_follows_response_and_explicit_choice_wins():
    assert resolve_voice_language("auto", "Merci, le marché est ouvert", "ar") == "fr"
    assert resolve_voice_language("en", "السوق يتحرك", "ar") == "en"


def test_auto_uses_interface_language_as_fallback():
    assert resolve_voice_language("auto", "12345", "ru") == "ru"
