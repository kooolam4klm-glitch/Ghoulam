"""Read-only momentum and volatility context; deliberately not a trade signal."""
from __future__ import annotations
from math import isfinite
from typing import Any, Iterable

from charting.indicators import atr_series, bollinger, rate_series, rsi, macd


def analyze_momentum_volatility(rates: Iterable[Any]) -> dict[str, Any]:
    source = list(rates)
    rows = source[:-1] if len(source) > 1 else source  # exclude forming MT5 candle
    if len(rows) < 35:
        return {"status": "INSUFFICIENT", "momentum": "UNKNOWN", "volatility": "UNKNOWN",
                "rsi14": None, "macd_histogram": None, "atr14": None,
                "atr_ratio": None, "bollinger_width_pct": None,
                "explanation": "يلزم 35 شمعة مكتملة على الأقل لهذا الفحص."}
    closes = rate_series(rows, "close")
    atrs = atr_series(rows, 14)
    rsis = rsi(closes, 14)
    macd_line, signal_line, hist = macd(closes)
    _, upper, lower = bollinger(closes, 20, 2.0)
    atr_now = atrs[-1]
    valid_atr = [float(x) for x in atrs if x is not None and isfinite(float(x))]
    baseline = valid_atr[-31:-1]
    atr_ratio = (float(atr_now) / (sum(baseline) / len(baseline))) if atr_now and baseline and sum(baseline) > 0 else None
    rsi_now = rsis[-1]
    hist_now = hist[-1]
    macd_now = macd_line[-1]
    signal_now = signal_line[-1]
    votes = []
    if rsi_now is not None:
        votes.append("BULLISH" if rsi_now >= 55 else "BEARISH" if rsi_now <= 45 else "NEUTRAL")
    if hist_now is not None:
        votes.append("BULLISH" if hist_now > 0 else "BEARISH" if hist_now < 0 else "NEUTRAL")
    if macd_now is not None and signal_now is not None:
        votes.append("BULLISH" if macd_now > signal_now else "BEARISH" if macd_now < signal_now else "NEUTRAL")
    bullish, bearish = votes.count("BULLISH"), votes.count("BEARISH")
    if len(votes) < 2:
        momentum = "UNKNOWN"
    elif bullish >= 2 and bearish == 0:
        momentum = "BULLISH"
    elif bearish >= 2 and bullish == 0:
        momentum = "BEARISH"
    elif bullish and bearish:
        momentum = "MIXED"
    else:
        momentum = "NEUTRAL"
    if atr_ratio is None:
        volatility = "UNKNOWN"
    elif atr_ratio >= 1.35:
        volatility = "EXPANDED"
    elif atr_ratio <= 0.75:
        volatility = "CONTRACTED"
    else:
        volatility = "NORMAL"
    width = None
    if upper[-1] is not None and lower[-1] is not None and closes[-1] != 0:
        width = (float(upper[-1]) - float(lower[-1])) / abs(closes[-1]) * 100.0
    return {
        "status": "VALID", "momentum": momentum, "momentum_votes": votes,
        "volatility": volatility, "rsi14": float(rsi_now) if rsi_now is not None else None,
        "macd_histogram": float(hist_now) if hist_now is not None else None,
        "atr14": float(atr_now) if atr_now is not None else None,
        "atr_ratio": float(atr_ratio) if atr_ratio is not None else None,
        "bollinger_width_pct": float(width) if width is not None else None,
        "explanation": "الزخم يجمع RSI وMACD؛ التقلب يقارن ATR الحالي بمتوسطه السابق. هذه أوصاف سياقية وليست إشارة دخول.",
    }
