"""Conservative MT5 tick freshness validation.

The MetaTrader 5 Python integration documents tick/bar timestamps as UTC.
This module therefore does NOT infer or subtract a guessed broker timezone
from future-looking timestamps. A timestamp that is too old or too far in the
future fails closed and blocks actionable signals until the clock/data is fixed.
"""
from datetime import datetime, timezone
import time


class TickClockTracker:
    def __init__(self, max_age_seconds=180, future_tolerance_seconds=10, **_ignored):
        self.max_age_seconds = max(1, int(max_age_seconds))
        self.future_tolerance_seconds = max(0, int(future_tolerance_seconds))
        # Retained for backwards compatibility with older callers/tests. UTC
        # timestamps are never adjusted using an inferred broker offset.
        self.offset_seconds = 0

    @staticmethod
    def timestamp_from_tick(tick):
        if tick is None:
            return None
        try:
            time_msc = float(getattr(tick, "time_msc", 0) or 0)
            if time_msc > 0 and time_msc == time_msc and abs(time_msc) != float("inf"):
                return time_msc / 1000.0
        except (TypeError, ValueError, OverflowError):
            pass
        try:
            seconds = float(getattr(tick, "time", 0) or 0)
            return seconds if seconds > 0 and seconds == seconds and abs(seconds) != float("inf") else None
        except (TypeError, ValueError, OverflowError):
            return None

    @staticmethod
    def _utc_label(timestamp):
        if timestamp is None:
            return "غير متاح"
        try:
            return datetime.fromtimestamp(timestamp, timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        except (ValueError, OSError, OverflowError):
            return "غير متاح"

    @staticmethod
    def _local_label(timestamp):
        if timestamp is None:
            return "غير متاح"
        try:
            return datetime.fromtimestamp(timestamp, timezone.utc).astimezone().strftime("%Y-%m-%d %H:%M:%S (محلي)")
        except (ValueError, OSError, OverflowError):
            return "غير متاح"

    @staticmethod
    def _format_age(age):
        if age is None:
            return "غير معروف"
        age = abs(int(age))
        if age < 60:
            return f"{age} ثانية"
        if age < 3600:
            return f"{age // 60} دقيقة و{age % 60} ثانية"
        return f"{age // 3600} ساعة و{(age % 3600) // 60} دقيقة"

    def update(self, tick, now_epoch=None, monotonic_now=None, broker_offset_seconds=None):
        # monotonic_now is accepted for API compatibility, but no clock learning
        # happens; monotonic time cannot identify an external timezone offset.
        now_epoch = time.time() if now_epoch is None else float(now_epoch)
        raw_ts = self.timestamp_from_tick(tick)
        if raw_ts is None:
            return {
                "status": "error", "is_fresh": False, "age_seconds": None,
                "raw_timestamp": None, "raw_time_label": "غير متاح",
                "corrected_timestamp": None, "corrected_utc_label": "غير متاح",
                "corrected_local_label": "غير متاح", "offset_seconds": 0,
                "message": "تعذرت قراءة توقيت Tick صالح من MT5؛ أُوقفت التوصية."
            }

        # MT5 EA ticks use broker-server epoch. Normalize only when the EA
        # explicitly supplies server_time - GMT; never guess a timezone.
        offset = 0
        corrected_ts = raw_ts
        if broker_offset_seconds is not None:
            try:
                candidate = int(broker_offset_seconds)
                if abs(candidate) > 14 * 3600 or candidate % 60 != 0:
                    raise ValueError("invalid broker UTC offset")
                offset = candidate
                corrected_ts = raw_ts - offset
            except (TypeError, ValueError, OverflowError):
                return {
                    "status": "clock_offset_invalid", "is_fresh": False,
                    "age_seconds": None, "raw_timestamp": raw_ts,
                    "raw_time_label": self._utc_label(raw_ts),
                    "corrected_timestamp": None, "corrected_utc_label": "غير متاح",
                    "corrected_local_label": "غير متاح", "offset_seconds": 0,
                    "message": "فرق توقيت خادم MT5 غير صالح؛ أُوقفت التوصية حتى تصحيح بيانات الساعة."
                }
        age = now_epoch - corrected_ts
        if age < -self.future_tolerance_seconds:
            status, fresh = "clock_ahead", False
            message = (
                f"طابع MT5 يسبق ساعة الجهاز بنحو {self._format_age(age)}. "
                "لم يتم اختراع فرق توقيت لتصحيحه؛ تحقق من ساعة Windows وتوقيت بيانات MT5. "
                "لن تُعتمد إشارة حتى يصبح الطابع الزمني متسقًا."
            )
        elif age > self.max_age_seconds:
            status, fresh = "stale", False
            message = (
                f"آخر Tick قديم بعمر {self._format_age(age)} (الحد {self.max_age_seconds} ثانية). "
                "تحقق من الاتصال والسوق؛ لن تُعتمد إشارة."
            )
        else:
            status, fresh = "fresh", True
            message = f"وقت Tick متسق؛ عمر آخر تحديث {self._format_age(age)}."

        return {
            "status": status, "is_fresh": fresh,
            "age_seconds": age if age < 0 else max(0, age),
            "raw_timestamp": raw_ts,
            "raw_time_label": self._utc_label(raw_ts),
            "corrected_timestamp": corrected_ts,
            "corrected_utc_label": self._utc_label(corrected_ts),
            "corrected_local_label": self._local_label(corrected_ts),
            "offset_seconds": offset,
            "message": message,
        }


def gate_signal(signal, market_status):
    """Force WAIT if freshness is unconfirmed; never retain stale price levels."""
    if market_status and market_status.get("is_fresh"):
        return signal
    safe = dict(signal)
    prior_direction = safe.get("direction", "WAIT")
    safe["summary"] = str(safe.get("summary", "")).replace(
        f"الاتجاه المقترح: {prior_direction}", f"الإشارة الأولية المحجوبة بسبب الوقت: {prior_direction}", 1
    ) if prior_direction in ("BUY", "SELL") else str(safe.get("summary", ""))
    safe["direction"] = "WAIT"
    safe["entry"] = None
    safe["stop_loss"] = None
    safe["take_profit"] = None
    safe["blocked_direction"] = prior_direction if prior_direction in ("BUY", "SELL") else None
    banner = (market_status or {}).get("message", "لم يتم التأكد من حداثة الأسعار.")
    safe["warnings"] = list(safe.get("warnings", []))
    safe["warnings"].append("حُجبت الإشارة لأن حداثة السعر غير مؤكدة.")
    safe["summary"] = "حالة الأسعار: " + banner + "\n\n" + str(safe.get("summary", ""))
    return safe
