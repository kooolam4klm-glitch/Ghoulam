"""Explainable, read-only market-structure context for Apex Alpha.

Uses confirmed pivots from completed candles only. BOS/CHOCH are descriptive
close-based events; equal-high/low clusters are potential liquidity pools,
not evidence of institutional orders or guaranteed stop locations.
"""
from __future__ import annotations
from math import isfinite
from typing import Any, Iterable

from charting.indicators import atr_series, confirmed_swing_points, field


def analyze_market_structure(rates: Iterable[Any], *, left_bars: int = 2,
                             right_bars: int = 2, lookback: int = 120,
                             equal_tolerance_atr: float = 0.15) -> dict[str, Any]:
    source = list(rates)
    # Exclude the active candle before pivot confirmation and event detection.
    rows = source[:-1] if len(source) > 1 else source
    if len(rows) < max(20, left_bars + right_bars + 5):
        return {"status": "INSUFFICIENT", "bias": "UNKNOWN", "events": [],
                "liquidity_pools": [], "swings": [], "explanation": "完成K线数量不足。"}

    window = rows[-lookback:]
    pivots = confirmed_swing_points(window, left_bars=left_bars, right_bars=right_bars)
    highs = [p for p in pivots if p["kind"] == "HIGH"]
    lows = [p for p in pivots if p["kind"] == "LOW"]
    close = field(window[-1], "close")
    atr_values = atr_series(window, 14)
    atr = atr_values[-1] if atr_values else None
    atr = float(atr) if atr is not None and isfinite(float(atr)) else 0.0

    def sequence(points):
        if len(points) < 2:
            return "UNKNOWN"
        return ("HH" if points[-1]["price"] > points[-2]["price"] else "LH") if points[-1]["kind"] == "HIGH" else ("HL" if points[-1]["price"] > points[-2]["price"] else "LL")

    high_seq = "HH" if len(highs) >= 2 and highs[-1]["price"] > highs[-2]["price"] else "LH" if len(highs) >= 2 else "UNKNOWN"
    low_seq = "HL" if len(lows) >= 2 and lows[-1]["price"] > lows[-2]["price"] else "LL" if len(lows) >= 2 else "UNKNOWN"
    bias = "BULLISH" if high_seq == "HH" and low_seq == "HL" else "BEARISH" if high_seq == "LH" and low_seq == "LL" else "MIXED"

    events = []
    # Close-based breaks of the latest confirmed opposite swing; no intrabar assumptions.
    if highs and close > highs[-1]["price"]:
        events.append({"code": "BULLISH_BOS" if bias == "BULLISH" else "BULLISH_CHOCH",
                       "level": highs[-1]["price"], "close": close,
                       "description": "إغلاق مكتمل فوق آخر قمة مؤكدة."})
    if lows and close < lows[-1]["price"]:
        events.append({"code": "BEARISH_BOS" if bias == "BEARISH" else "BEARISH_CHOCH",
                       "level": lows[-1]["price"], "close": close,
                       "description": "إغلاق مكتمل تحت آخر قاع مؤكد."})

    tolerance = max(atr * equal_tolerance_atr, 0.0)
    pools = []
    for kind, points in (("BUY_SIDE", highs), ("SELL_SIDE", lows)):
        if len(points) < 2 or tolerance <= 0:
            continue
        # Cluster recent pivots against the latest pivot, avoiding transitive chains.
        latest = points[-1]
        cluster = [p for p in points[-6:] if abs(p["price"] - latest["price"]) <= tolerance]
        if len(cluster) >= 2:
            level = sum(p["price"] for p in cluster) / len(cluster)
            pools.append({"type": kind, "level": level, "touches": len(cluster),
                          "tolerance": tolerance,
                          "description": "قمم متقاربة؛ سيولة شراء محتملة" if kind == "BUY_SIDE" else "قيعان متقاربة؛ سيولة بيع محتملة"})

    last_high = highs[-1]["price"] if highs else None
    last_low = lows[-1]["price"] if lows else None
    return {
        "status": "VALID",
        "bias": bias,
        "high_sequence": high_seq,
        "low_sequence": low_seq,
        "last_confirmed_high": last_high,
        "last_confirmed_low": last_low,
        "atr14": atr if atr > 0 else None,
        "events": events,
        "liquidity_pools": pools,
        "swings": [{"kind": p["kind"], "price": p["price"], "time": p["time"],
                    "confirmed_at_time": p["confirmed_at_time"]} for p in pivots[-12:]],
        "explanation": "التحليل مبني على قمم وقيعان مؤكدة وإغلاقات الشموع؛ تجمعات السيولة احتمالية وليست بيانات أوامر مؤسسية مباشرة.",
    }
