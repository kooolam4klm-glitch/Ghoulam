"""Read-only, conservative technical signal engine for Apex Alpha.

The confidence field is a rule-alignment score, NOT a calibrated probability of
profit. The engine never sends broker orders. It deliberately prefers WAIT when
trend, momentum, recent price action, or quote quality disagree.
"""
from math import isfinite

from charting.indicators import rsi as _shared_rsi

STRATEGY_ID = "STRUCTURE_TREND_MOMENTUM_V2"


def _value(row, key):
    try:
        return float(row[key])
    except (TypeError, KeyError, IndexError, ValueError):
        return float(getattr(row, key))


def _sma(values, period):
    return sum(values[-period:]) / period


def _ema(values, period):
    if len(values) < period:
        return None
    alpha = 2.0 / (period + 1.0)
    value = sum(values[:period]) / period
    for sample in values[period:]:
        value = alpha * sample + (1.0 - alpha) * value
    return value


def _rsi(closes, period=14):
    """Use the same Wilder-smoothed RSI implementation as the chart."""
    values = _shared_rsi(list(closes), period)
    value = values[-1] if values else None
    return float(value) if value is not None else 50.0


def _atr(rows, period=14):
    trs = []
    for i in range(1, len(rows)):
        high = _value(rows[i], "high")
        low = _value(rows[i], "low")
        previous_close = _value(rows[i - 1], "close")
        trs.append(max(high - low, abs(high - previous_close), abs(low - previous_close)))
    return sum(trs[-period:]) / min(period, len(trs)) if trs else 0.0


def _bar_time(row):
    try:
        return int(row["time"])
    except (TypeError, KeyError, IndexError, ValueError):
        try:
            return int(getattr(row, "time"))
        except (TypeError, ValueError, AttributeError):
            return None


def _base_result(symbol, timeframe, signal_bar_time, direction="WAIT", **extra):
    result = {
        "symbol": symbol, "timeframe": timeframe, "strategy_id": STRATEGY_ID,
        "signal_bar_time": signal_bar_time, "bias": "محايد / انتظار",
        "direction": direction, "confidence": 0, "confidence_label": "درجة توافق القواعد وليست احتمال ربح",
        "entry": None, "stop_loss": None, "take_profit": None,
        "score_breakdown": {}, "warnings": [],
    }
    result.update(extra)
    return result


def make_demo_signal(symbol, timeframe, tick, bars, digits=5):
    """Build a cautious signal snapshot from closed candles and the latest quote."""
    try:
        digits = max(0, min(10, int(digits)))
        source_rows = list(bars) if bars is not None else []
        # MT5 copy_rates_from_pos(..., 0, ...) returns the live/forming candle first
        # in chronological array order at the end. Always remove it when possible.
        rows = source_rows[:-1] if len(source_rows) > 1 else source_rows
        signal_bar_time = _bar_time(rows[-1]) if rows else None
        bid = getattr(tick, "bid", None) if tick is not None else None
        ask = getattr(tick, "ask", None) if tick is not None else None
        bid = float(bid) if bid is not None else None
        ask = float(ask) if ask is not None else None
        quote_ok = bid is not None and ask is not None and isfinite(bid) and isfinite(ask) and bid > 0 and ask >= bid
        price_text = (f"Bid {bid:.{digits}f} / Ask {ask:.{digits}f}" if quote_ok else "السعر غير متاح أو غير صالح")
        if len(rows) < 30:
            out = _base_result(symbol, timeframe, signal_bar_time, bias="بيانات غير كافية", warnings=["تحتاج القراءة إلى 30 شمعة مغلقة على الأقل لعرض قراءة أولية."])
            out["summary"] = (f"الأداة: {symbol} | الإطار: {timeframe}\nالسعر الحالي: {price_text}\n"
                              "الحالة: WAIT — بيانات الشموع المغلقة غير كافية (30 شمعة مطلوبة).\n"
                              "لم يُرسل أي أمر تداول.")
            return out
        if not quote_ok:
            out = _base_result(symbol, timeframe, signal_bar_time, bias="اقتباس غير صالح", warnings=["تعذر التحقق من Bid/Ask."])
            out["summary"] = f"الأداة: {symbol} | الإطار: {timeframe}\nالسعر: {price_text}\nالحالة: WAIT — لا تُعرض توصية مع اقتباس غير صالح.\nلم يُرسل أي أمر تداول."
            return out

        closes = [_value(row, "close") for row in rows]
        highs_all = [_value(row, "high") for row in rows]
        lows_all = [_value(row, "low") for row in rows]
        opens = [_value(row, "open") for row in rows]
        if (not all(isfinite(v) for v in closes + highs_all + lows_all + opens)
                or any(h < l for h, l in zip(highs_all, lows_all))
                or any(h < max(o, c) or l > min(o, c)
                       for o, h, l, c in zip(opens, highs_all, lows_all, closes))):
            out = _base_result(symbol, timeframe, signal_bar_time, bias="بيانات غير صالحة", warnings=["قِيَم OHLC غير صالحة أو غير متسقة."])
            out["summary"] = f"الأداة: {symbol} | الإطار: {timeframe}\nالحالة: WAIT — بيانات السوق غير صالحة.\nلم يُرسل أي أمر تداول."
            return out

        timestamps = [_bar_time(row) for row in rows]
        if all(stamp is not None for stamp in timestamps) and any(a >= b for a, b in zip(timestamps, timestamps[1:])):
            out = _base_result(symbol, timeframe, signal_bar_time, bias="ترتيب زمني غير صالح", warnings=["شموع MT5 ليست مرتبة تصاعديًا زمنيًا؛ أُوقفت التوصية."])
            out["summary"] = f"الأداة: {symbol} | الإطار: {timeframe}\nالحالة: WAIT — ترتيب الشموع غير صالح. تحقق من مصدر بيانات MT5.\nلم يُرسل أي أمر تداول."
            return out

        fast = _sma(closes, 10)
        slow = _sma(closes, 30)
        ema20 = _ema(closes, 20)
        ema50 = _ema(closes, 50)
        rsi = _rsi(closes, 14)
        atr = _atr(rows, 14)
        last_close = closes[-1]
        recent = closes[-6:]
        recent_change = recent[-1] - recent[0]
        recent_positive = sum(1 for a, b in zip(recent, recent[1:]) if b > a)
        recent_negative = sum(1 for a, b in zip(recent, recent[1:]) if b < a)
        # Approximate structure comparison: last 5-bar range vs the preceding 5 bars.
        recent_high = max(highs_all[-5:]); prior_high = max(highs_all[-10:-5])
        recent_low = min(lows_all[-5:]); prior_low = min(lows_all[-10:-5])
        higher_high = recent_high > prior_high
        higher_low = recent_low > prior_low
        lower_high = recent_high < prior_high
        lower_low = recent_low < prior_low
        spread = ask - bid
        spread_ratio = spread / atr if atr > 0 else float("inf")

        # A breakout is measured only against earlier completed candles; the
        # current signal candle is not included in its own reference level.
        prior_highs = highs_all[-21:-1]
        prior_lows = lows_all[-21:-1]
        prior_resistance = max(prior_highs) if prior_highs else None
        prior_support = min(prior_lows) if prior_lows else None
        bullish_breakout = (prior_resistance is not None and atr > 0
                            and last_close > prior_resistance + 0.05 * atr)
        bearish_breakout = (prior_support is not None and atr > 0
                            and last_close < prior_support - 0.05 * atr)

        bullish_trend = ema50 is not None and fast > slow and last_close > ema20 and ema20 >= ema50
        bearish_trend = ema50 is not None and fast < slow and last_close < ema20 and ema20 <= ema50
        bullish_momentum = recent_change > 0 and recent_positive >= 3 and 50 <= rsi < 72
        bearish_momentum = recent_change < 0 and recent_negative >= 3 and 28 < rsi <= 50
        bullish_structure = higher_high and higher_low
        bearish_structure = lower_high and lower_low
        # Detect a fresh countertrend turn so a lagging moving average alone cannot
        # trigger a short into an obvious bounce (or a long into a selloff).
        rebound_warning = recent_change > 0 and recent_positive >= 4 and (higher_low or last_close > fast)
        selloff_warning = recent_change < 0 and recent_negative >= 4 and (lower_high or last_close < fast)

        buy_score = 0
        buy_score += 25 if bullish_trend else 0
        buy_score += 25 if bullish_momentum else 0
        buy_score += 25 if bullish_structure else 0
        buy_score += 15 if last_close > fast else 0
        buy_score += 10 if 52 <= rsi <= 66 else 0
        sell_score = 0
        sell_score += 25 if bearish_trend else 0
        sell_score += 25 if bearish_momentum else 0
        sell_score += 25 if bearish_structure else 0
        sell_score += 15 if last_close < fast else 0
        sell_score += 10 if 34 <= rsi <= 48 else 0

        warnings = []
        if ema50 is None:
            warnings.append("EMA(50) غير متاح: نحتاج إلى 50 شمعة مغلقة على الأقل؛ لن تُصدر توصية اتجاهية دون هذا الفلتر.")
        if spread_ratio > 0.20:
            warnings.append("السبريد مرتفع مقارنة بـ ATR؛ تم إيقاف التوصية.")
        if rebound_warning and not bullish_trend:
            warnings.append("ارتداد صاعد قصير يتعارض مع الاتجاه المتأخر؛ لا يتم إصدار SELL حتى يتضح الهيكل.")
        if selloff_warning and not bearish_trend:
            warnings.append("ضغط هابط قصير يتعارض مع الاتجاه المتأخر؛ لا يتم إصدار BUY حتى يتضح الهيكل.")
        if bullish_breakout:
            warnings.append("اختراق صاعد بإغلاق شمعة فوق مقاومة آخر 20 شمعة مغلقة؛ مُنع إصدار SELL عكس الاختراق.")
        if bearish_breakout:
            warnings.append("اختراق هابط بإغلاق شمعة تحت دعم آخر 20 شمعة مغلقة؛ مُنع إصدار BUY عكس الاختراق.")
        if abs(buy_score - sell_score) < 20:
            warnings.append("توافق الاتجاهين غير كافٍ؛ الأفضل الانتظار.")

        direction, confidence, bias = "WAIT", max(buy_score, sell_score), "محايد / انتظار"
        rationale = "لم تجتمع أدلة الاتجاه والزخم وبنية السعر بما يكفي؛ لا يتم فرض BUY أو SELL."
        # Conservative threshold: structure + trend + momentum must agree.
        if (spread_ratio <= 0.20 and not bearish_breakout and buy_score >= 70
                and buy_score - sell_score >= 20 and bullish_trend and bullish_momentum and bullish_structure):
            direction, confidence, bias = "BUY", buy_score, "ميل صعودي مدعوم بالاتجاه والزخم والبنية"
            rationale = "الاتجاه الصاعد والزخم وبنية القمم/القيعان متوافقة على الشموع المغلقة."
        elif (spread_ratio <= 0.20 and not bullish_breakout and sell_score >= 70
              and sell_score - buy_score >= 20 and bearish_trend and bearish_momentum
              and bearish_structure and not rebound_warning):
            direction, confidence, bias = "SELL", sell_score, "ميل هبوطي مدعوم بالاتجاه والزخم والبنية"
            rationale = "الاتجاه الهابط والزخم وبنية القمم/القيعان متوافقة على الشموع المغلقة."
        else:
            confidence = min(69, confidence)

        highs, lows = highs_all[-20:], lows_all[-20:]
        resistance, support = max(highs), min(lows)
        entry = stop_loss = take_profit = None
        if direction == "BUY" and atr > 0:
            entry, stop_loss = ask, min(ask - 1.5 * atr, support - 0.1 * atr)
            if stop_loss >= entry: stop_loss = ask - 1.5 * atr
            take_profit = ask + 2.0 * (ask - stop_loss)
        elif direction == "SELL" and atr > 0:
            entry, stop_loss = bid, max(bid + 1.5 * atr, resistance + 0.1 * atr)
            if stop_loss <= entry: stop_loss = bid + 1.5 * atr
            take_profit = bid - 2.0 * (stop_loss - bid)
        if direction in ("BUY", "SELL") and (atr <= 0 or not all(isfinite(v) for v in (entry, stop_loss, take_profit))):
            direction, entry, stop_loss, take_profit = "WAIT", None, None, None
            warnings.append("تعذر بناء مستويات مخاطرة صالحة؛ تم إلغاء التوصية.")

        def fmt(value): return f"{value:.{digits}f}" if value is not None else "—"
        structure_text = ("قمم وقيعان أعلى" if bullish_structure else "قمم وقيعان أدنى" if bearish_structure else "بنية مختلطة/غير مؤكدة")
        breakdown = {"trend": 25 if (bullish_trend if direction == "BUY" else bearish_trend if direction == "SELL" else False) else 0,
                     "momentum": 25 if (bullish_momentum if direction == "BUY" else bearish_momentum if direction == "SELL" else False) else 0,
                     "structure": 25 if (bullish_structure if direction == "BUY" else bearish_structure if direction == "SELL" else False) else 0,
                     "price_position": 15 if (last_close > fast if direction == "BUY" else last_close < fast if direction == "SELL" else False) else 0,
                     "rsi_zone": 10 if (52 <= rsi <= 66 if direction == "BUY" else 34 <= rsi <= 48 if direction == "SELL" else False) else 0}
        warnings_text = "\nتحذيرات: " + "؛ ".join(warnings) if warnings else ""
        plan = (f"الاتجاه المقترح: {direction} | درجة توافق القواعد: {confidence}/100 (ليست احتمال ربح)\nالدخول الافتراضي: {fmt(entry)} | وقف الخسارة: {fmt(stop_loss)} | الهدف: {fmt(take_profit)}"
                if direction in ("BUY", "SELL") else f"الاتجاه المقترح: WAIT | أعلى درجة توافق للقواعد: {confidence}/100 — ليست احتمال ربح.")
        summary = (
            f"الأداة: {symbol} | الإطار: {timeframe}\nالسعر الحالي: {price_text} | السبريد: {spread:.{digits}f} | السبريد/ATR: {spread_ratio:.3f}\n"
            f"القراءة: {bias} | RSI(14): {rsi:.1f}\nSMA(10): {fast:.{digits}f} | SMA(30): {slow:.{digits}f} | EMA(20): {ema20:.{digits}f} | EMA(50): {fmt(ema50)} | ATR(14): {atr:.{digits}f}\n"
            f"بنية السعر: {structure_text} | تغير آخر 5 فواصل: {recent_change:.{digits}f}\nالدعم التقريبي: {support:.{digits}f} | المقاومة التقريبية: {resistance:.{digits}f}\n"
            f"اختراق إغلاق الشمعة: {'صاعد' if bullish_breakout else 'هابط' if bearish_breakout else 'لا يوجد اختراق مؤكد وفق القاعدة'}\n"
            f"السبب: {rationale}\n{plan}{warnings_text}\n\n"
            "مهم: النسبة درجة توافق قواعد وليست احتمال نجاح أو ربح مثبتًا. لم يتم التحقق من هذه القواعد على بيانات خارج العينة؛ لا تعتمد عليها للتداول الحقيقي قبل الاختبار التاريخي والاختبار الأمامي. لا يُرسل أي أمر تداول."
        )
        return _base_result(symbol, timeframe, signal_bar_time, direction=direction, bias=bias,
                            confidence=int(max(0, min(100, confidence))), score_breakdown=breakdown,
                            warnings=warnings, entry=entry, stop_loss=stop_loss, take_profit=take_profit,
                            rsi=rsi, atr=atr, support=support, resistance=resistance,
                            sma_fast=fast, sma_slow=slow, ema20=ema20, ema50=ema50,
                            structure=structure_text, spread=spread, spread_atr_ratio=spread_ratio,
                            bullish_breakout=bullish_breakout, bearish_breakout=bearish_breakout,
                            prior_resistance=prior_resistance, prior_support=prior_support,
                            summary=summary)
    except Exception as exc:
        out = _base_result(symbol, timeframe, None, bias="ERROR", warnings=[str(exc)])
        out["summary"] = f"تعذر تكوين القراءة التحليلية: {exc}\nلم يتم إنشاء أو إرسال أمر تداول."
        return out
