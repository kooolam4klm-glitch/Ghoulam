"""Read-only heuristic institutional-style price context for Apex Alpha.

This module observes price patterns only; it cannot identify actual institutional
orders, broker stop orders, or intentional manipulation.
"""
from __future__ import annotations
from typing import Any, Iterable
from charting.indicators import atr_wilder_series, confirmed_swing_points, field


def analyze_institutional_context(
    rates: Iterable[Any], *, lookback: int = 120, equal_tolerance_atr: float = 0.15,
    forming_candle: bool = True,
) -> dict[str, Any]:
    """Analyze completed bars. Set forming_candle=False for closed-bar datasets.

    Default True preserves the existing MT5 convention and backward compatibility.
    """
    source = list(rates)
    rows = source[:-1] if forming_candle and len(source) > 1 else source
    empty = {"status": "INSUFFICIENT", "liquidity_pools": [],
             "liquidity_sweeps": [], "fair_value_gaps": []}
    if lookback < 25 or len(rows) < 25:
        return {**empty, "explanation": "يلزم 25 شمعة مكتملة على الأقل، وأن يكون lookback لا يقل عن 25."}
    window = rows[-lookback:]
    pivots = confirmed_swing_points(window, left_bars=2, right_bars=2)
    highs = [x for x in pivots if x["kind"] == "HIGH"]
    lows = [x for x in pivots if x["kind"] == "LOW"]
    atrs = atr_wilder_series(window, 14)
    atr = float(atrs[-1]) if atrs and atrs[-1] is not None else 0.0
    tolerance = max(atr * float(equal_tolerance_atr), 0.0)

    pools: list[dict[str, Any]] = []
    for side, points in (("BUY_SIDE", highs), ("SELL_SIDE", lows)):
        clusters: list[list[dict[str, Any]]] = []
        for point in points:
            price = float(point["price"])
            # A cluster is bounded by its full price span, not chained pairwise gaps.
            matches = [c for c in clusters
                       if max(float(x["price"]) for x in c + [point]) -
                          min(float(x["price"]) for x in c + [point]) <= tolerance]
            if matches:
                target = min(matches, key=lambda c: abs(price - sum(float(x["price"]) for x in c) / len(c)))
                target.append(point)
            else:
                clusters.append([point])
        for cluster in clusters:
            if len(cluster) < 2:
                continue
            level = sum(float(x["price"]) for x in cluster) / len(cluster)
            pools.append({"type": side, "level": level, "touches": len(cluster),
                          "tolerance": tolerance, "evidence": "CONFIRMED_SWING_CLUSTER",
                          "first_time": cluster[0].get("time"), "last_time": cluster[-1].get("time"),
                          "description": "تجمع قمم متقاربة؛ سيولة شراء محتملة" if side == "BUY_SIDE"
                                        else "تجمع قيعان متقاربة؛ سيولة بيع محتملة"})

    last = window[-1]
    high, low, close = field(last, "high"), field(last, "low"), field(last, "close")
    sweeps = []
    # Only pools confirmed before the sweep candle are eligible.
    for pool in pools:
        level = float(pool["level"])
        if pool["type"] == "BUY_SIDE" and high > level + tolerance * 0.05 and close < level:
            sweeps.append({"type": "BUY_SIDE_SWEEP", "level": level,
                           "candle_time": int(field(last, "time")),
                           "wick_atr": (high - max(field(last, "open"), close)) / atr if atr else None,
                           "close_position": (close - low) / (high - low) if high > low else 0.5,
                           "description": "تجاوزت الشمعة تجمع قمم ثم أغلقت أسفله؛ سحب سيولة محتمل."})
        elif pool["type"] == "SELL_SIDE" and low < level - tolerance * 0.05 and close > level:
            sweeps.append({"type": "SELL_SIDE_SWEEP", "level": level,
                           "candle_time": int(field(last, "time")),
                           "wick_atr": (min(field(last, "open"), close) - low) / atr if atr else None,
                           "close_position": (close - low) / (high - low) if high > low else 0.5,
                           "description": "تجاوزت الشمعة تجمع قيعان ثم أغلقت فوقه؛ سحب سيولة محتمل."})

    gaps = []
    start = max(2, len(window) - 40)
    for i in range(start, len(window)):
        a, c = window[i-2], window[i]
        ah, al = field(a, "high"), field(a, "low")
        ch, cl = field(c, "high"), field(c, "low")
        zone = None
        if cl > ah:
            zone = ("BULLISH_FVG", ah, cl)
        elif ch < al:
            zone = ("BEARISH_FVG", ch, al)
        if zone is None:
            continue
        kind, lower, upper = zone
        later = window[i+1:]
        touched = [r for r in later if field(r, "low") <= upper and field(r, "high") >= lower]
        if not touched:
            status = "UNMITIGATED"
        elif kind == "BULLISH_FVG":
            status = "FULLY_MITIGATED" if any(field(r, "low") <= lower for r in touched) else "PARTIALLY_MITIGATED"
        else:
            status = "FULLY_MITIGATED" if any(field(r, "high") >= upper for r in touched) else "PARTIALLY_MITIGATED"
        gaps.append({"type": kind, "lower": lower, "upper": upper,
                     "formed_at": int(field(c, "time")), "status": status,
                     "mitigated_at": int(field(touched[0], "time")) if touched else None})

    return {"status": "VALID", "liquidity_pools": pools[-12:],
            "liquidity_sweeps": sweeps, "fair_value_gaps": gaps[-12:],
            "last_closed_candle_time": int(field(last, "time")),
            "atr_method": "WILDER", "atr14": atr,
            "explanation": "رصد احتمالي لتجمعات القمم/القيعان، وسحب السيولة، وفجوات القيمة العادلة وحالة ملئها. لا يكشف أوامر المؤسسات الفعلية ولا يثبت التلاعب."}
