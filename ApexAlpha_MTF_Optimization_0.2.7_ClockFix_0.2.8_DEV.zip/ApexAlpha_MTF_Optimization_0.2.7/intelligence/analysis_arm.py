"""Read-only Analysis Arm v0.2 for Apex Alpha.

Composes existing MT5 OHLC analysis, indicator calculations, and confirmed
swing points into one explainable report. It never creates or sends orders.
"""
from __future__ import annotations

from math import isfinite
from typing import Any, Mapping

from charting.indicators import confirmed_swing_points, latest_indicator_values
from intelligence.multi_timeframe import analyze_multi_timeframe
from intelligence.structure_analyzer import analyze_market_structure
from intelligence.momentum_volatility import analyze_momentum_volatility
from intelligence.institutional_intelligence import analyze_institutional_context


def _field(row: Any, key: str) -> float:
    try:
        value = float(row[key])
    except (TypeError, KeyError, IndexError, ValueError):
        value = float(getattr(row, key))
    if not isfinite(value):
        raise ValueError(f"قيمة {key} غير صالحة")
    return value


def _validate_rates(rows: list[Any]) -> list[str]:
    issues: list[str] = []
    if len(rows) < 55:
        issues.append("عدد الشموع أقل من 55؛ التحليل متعدد الأطر قد يكون غير مكتمل.")
    previous_time = None
    for index, row in enumerate(rows):
        try:
            o, h, low, c = (_field(row, name) for name in ("open", "high", "low", "close"))
            if h < max(o, c) or low > min(o, c) or h < low:
                issues.append(f"شمعة OHLC غير متسقة عند الفهرس {index}.")
                break
            try:
                stamp = int(row["time"])
            except (TypeError, KeyError, IndexError, ValueError):
                stamp = int(getattr(row, "time"))
            if previous_time is not None and stamp <= previous_time:
                issues.append(f"ترتيب زمني غير صحيح عند الفهرس {index}.")
                break
            previous_time = stamp
        except (TypeError, ValueError, AttributeError, OverflowError):
            issues.append(f"بيانات شمعة ناقصة أو غير رقمية عند الفهرس {index}.")
            break
    return issues


def _structure_context(rows: list[Any]) -> dict[str, Any]:
    # MT5 rates normally end with a forming candle. The pivot detector is
    # deliberately fed completed candles only to avoid repainting.
    closed = rows[:-1] if len(rows) > 1 else rows
    pivots = confirmed_swing_points(closed, left_bars=2, right_bars=2)
    highs = [p for p in pivots if p["kind"] == "HIGH"][-2:]
    lows = [p for p in pivots if p["kind"] == "LOW"][-2:]
    high_state = "UNKNOWN"
    low_state = "UNKNOWN"
    if len(highs) == 2:
        high_state = "HH" if highs[-1]["price"] > highs[-2]["price"] else "LH"
    if len(lows) == 2:
        low_state = "HL" if lows[-1]["price"] > lows[-2]["price"] else "LL"
    if high_state == "HH" and low_state == "HL":
        structure = "BULLISH_STRUCTURE"
        label = "قمم وقيعان صاعدة (HH + HL)"
    elif high_state == "LH" and low_state == "LL":
        structure = "BEARISH_STRUCTURE"
        label = "قمم وقيعان هابطة (LH + LL)"
    elif high_state != "UNKNOWN" and low_state != "UNKNOWN":
        structure = "MIXED_STRUCTURE"
        label = "بنية مختلطة؛ لا يوجد تسلسل واضح للقمم والقيعان"
    else:
        structure = "INSUFFICIENT_SWINGS"
        label = "نقاط التأرجح المؤكدة غير كافية لتصنيف البنية"
    return {
        "code": structure,
        "label": label,
        "last_highs": highs,
        "last_lows": lows,
        "high_sequence": high_state,
        "low_sequence": low_state,
        "pivot_count": len(pivots),
        "note": "القمم والقيعان نقاط محلية مؤكدة بعد شمعتين لاحقتين؛ لا تمثل تنبؤاً بانعكاس السعر.",
    }


def build_analysis_report(frames: Mapping[str, Any], *, symbol: str = "BTCUSD") -> dict[str, Any]:
    """Build a transparent M15/H1/H4 context report from MT5 rates.

    Output is analysis only. No BUY/SELL order, broker call, or position sizing
    is generated here. The caller decides how to present this context.
    """
    normalized = {tf: list(frames.get(tf, []) or []) for tf in ("M15", "H1", "H4")}
    quality = {tf: _validate_rates(rows) for tf, rows in normalized.items()}
    usable_frames = {tf: rows if not quality[tf] else [] for tf, rows in normalized.items()}
    mtf = analyze_multi_timeframe(usable_frames)
    per_frame: dict[str, Any] = {}
    for tf, rows in normalized.items():
        if quality[tf]:
            per_frame[tf] = {
                "data_quality": "INVALID_OR_INSUFFICIENT",
                "issues": quality[tf],
                "indicators": None,
                "structure": None,
            }
            continue
        values = latest_indicator_values(rows)
        structure = _structure_context(rows)
        advanced_structure = analyze_market_structure(rows)
        per_frame[tf] = {
            "data_quality": "VALIDATED",
            "issues": [],
            "indicators": values,
            "structure": structure,
            "advanced_structure": advanced_structure,
            "momentum_volatility": analyze_momentum_volatility(rows),
            "institutional": analyze_institutional_context(rows),
        }
    valid_count = sum(item["data_quality"] == "VALIDATED" for item in per_frame.values())
    warnings = [f"{tf}: {issue}" for tf, issues in quality.items() for issue in issues]
    warnings.append("هذا التقرير سياق تحليلي فقط؛ لا يصدر أوامر تداول ولا يضمن نتيجة.")
    return {
        "schema": 1,
        "module": "ApexAlpha_Analysis_Arm",
        "version": "0.2.6",
        "symbol": str(symbol),
        "read_only": True,
        "trading_enabled": False,
        "status": "READY" if valid_count >= 2 else "INSUFFICIENT_DATA",
        "valid_timeframes": valid_count,
        "multi_timeframe": mtf,
        "timeframes": per_frame,
        "warnings": warnings,
    }
