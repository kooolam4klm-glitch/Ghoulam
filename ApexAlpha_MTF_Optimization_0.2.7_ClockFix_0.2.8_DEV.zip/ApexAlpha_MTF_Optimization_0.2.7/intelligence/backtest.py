"""Cautious, no-lookahead historical evaluation of the demo signal rules.

This is a research tool, not an optimizer or profit guarantee. Entries occur at
next-bar open; if stop and target are both touched in one candle, stop is
assumed first (pessimistic ordering). Commissions and other estimated costs can be
provided in account-currency units and are deducted from each completed trade.
"""
from __future__ import annotations
from math import isfinite
from bisect import bisect_right
from typing import Any, Iterable, Mapping
from types import SimpleNamespace

from intelligence.signal_engine import make_demo_signal
from intelligence.multi_timeframe import analyze_multi_timeframe, apply_multi_timeframe_gate

_TIMEFRAME_SECONDS = {"M1": 60, "M2": 120, "M3": 180, "M4": 240, "M5": 300,
                      "M6": 360, "M10": 600, "M12": 720, "M15": 900, "M20": 1200,
                      "M30": 1800, "H1": 3600, "H2": 7200, "H3": 10800,
                      "H4": 14400, "H6": 21600, "H8": 28800, "H12": 43200,
                      "D1": 86400, "W1": 604800}

def _row_time(row: Any) -> int | None:
    try:
        return int(row["time"])
    except (TypeError, KeyError, IndexError, ValueError):
        try:
            return int(getattr(row, "time"))
        except (TypeError, ValueError, AttributeError):
            return None

def _prepare_mtf_frames(frames: Mapping[str, Iterable[Any]]) -> dict[str, tuple[list[int], list[Any]]]:
    """Pre-index higher-timeframe bars once for fast point-in-time lookups."""
    prepared: dict[str, tuple[list[int], list[Any]]] = {}
    for timeframe in ("M15", "H1", "H4"):
        rows = list(frames.get(timeframe, []) or [])
        pairs = [(_row_time(row), row) for row in rows]
        pairs = [(stamp, row) for stamp, row in pairs if stamp is not None]
        pairs.sort(key=lambda item: item[0])
        prepared[timeframe] = ([item[0] for item in pairs], [item[1] for item in pairs])
    return prepared


def _mtf_snapshot(frames: Mapping[str, Iterable[Any]], decision_time: int,
                  prepared: Mapping[str, tuple[list[int], list[Any]]] | None = None) -> dict[str, Any]:
    """Build an as-of snapshot using only fully closed higher-timeframe bars.

    Binary search finds the last eligible bar; only the latest 100 bars are
    analyzed. The synthetic final row is retained because analyze_timeframe
    intentionally excludes its last row as a forming candle.
    """
    indexed = prepared if prepared is not None else _prepare_mtf_frames(frames)
    snapshot: dict[str, list[Any]] = {}
    for timeframe in ("M15", "H1", "H4"):
        seconds = _TIMEFRAME_SECONDS[timeframe]
        stamps, rows = indexed.get(timeframe, ([], []))
        eligible_end = bisect_right(stamps, decision_time - seconds)
        closed = rows[max(0, eligible_end - 100):eligible_end]
        if closed:
            last_close = _v(closed[-1], "close")
            snapshot[timeframe] = closed + [{"time": decision_time, "open": last_close,
                                             "high": last_close, "low": last_close,
                                             "close": last_close}]
        else:
            snapshot[timeframe] = []
    return analyze_multi_timeframe(snapshot)


def _v(row: Any, key: str) -> float:
    try:
        return float(row[key])
    except (TypeError, KeyError, IndexError, ValueError):
        return float(getattr(row, key))


def _rsi(closes: list[float], period: int = 14) -> float:
    changes = [closes[i] - closes[i - 1] for i in range(1, len(closes))]
    recent = changes[-period:]
    if len(recent) < period:
        return 50.0
    gains = sum(max(v, 0.0) for v in recent) / period
    losses = sum(max(-v, 0.0) for v in recent) / period
    if losses <= 0:
        return 100.0 if gains > 0 else 50.0
    return 100.0 - 100.0 / (1.0 + gains / losses)


def _atr(rows: list[Any], period: int = 14) -> float:
    ranges = []
    for i in range(1, len(rows)):
        high, low = _v(rows[i], "high"), _v(rows[i], "low")
        prev = _v(rows[i - 1], "close")
        ranges.append(max(high - low, abs(high - prev), abs(low - prev)))
    return sum(ranges[-period:]) / min(period, len(ranges)) if ranges else 0.0


def run_backtest(rates: Iterable[Any], *, starting_equity: float = 10_000.0,
                 risk_fraction: float = 0.01, stop_atr: float = 1.5,
                 reward_risk: float = 2.0, cost_per_trade: float = 0.0,
                 spread_point_size: float | None = None,
                 min_bars: int = 60, higher_timeframes: Mapping[str, Iterable[Any]] | None = None,
                 base_timeframe: str = "M1", start_index: int = 0) -> dict[str, Any]:
    """Run a simple walk-forward backtest on chronological OHLC bars.

    `risk_fraction` is the fraction of current equity notionally risked per
    trade; P/L is a simplified compounded equity estimate. `cost_per_trade`
    is in the same account-currency units as starting_equity. The engine does
    not convert price spread to account currency; do not treat results as a
    broker-accurate simulation without instrument-specific cost conversion.
    """
    rows = list(rates) if rates is not None else []
    start_index = int(start_index)
    if start_index < 0:
        raise ValueError("start_index cannot be negative")
    if len(rows) < max(35, int(min_bars)):
        return {"ok": False, "error": f"Need at least {max(35, int(min_bars))} bars.", "trades": [], "metrics": {}}
    starting_equity = float(starting_equity)
    risk_fraction = float(risk_fraction)
    stop_atr = float(stop_atr)
    reward_risk = float(reward_risk)
    cost_per_trade = float(cost_per_trade)
    spread_point_size = None if spread_point_size is None else float(spread_point_size)
    if not isfinite(starting_equity) or starting_equity <= 0:
        raise ValueError("starting_equity must be finite and positive")
    if not isfinite(risk_fraction) or not 0 < risk_fraction <= 0.05:
        raise ValueError("risk_fraction must be > 0 and <= 0.05")
    if not isfinite(stop_atr) or stop_atr <= 0 or not isfinite(reward_risk) or reward_risk <= 0:
        raise ValueError("stop_atr and reward_risk must be positive")
    if not isfinite(cost_per_trade) or cost_per_trade < 0:
        raise ValueError("cost_per_trade cannot be negative")
    if spread_point_size is not None:
        if not isfinite(spread_point_size) or spread_point_size <= 0:
            raise ValueError("spread_point_size must be finite and positive")
        for index, row in enumerate(rows):
            try:
                spread_points = _v(row, "spread_points")
            except (KeyError, TypeError, ValueError, AttributeError):
                return {"ok": False, "error": "spread_point_size requires spread_points on every bar.", "trades": [], "metrics": {}}
            if not isfinite(spread_points) or spread_points < 0:
                return {"ok": False, "error": f"Invalid spread_points at bar {index}.", "trades": [], "metrics": {}}
    for row in rows:
        values = [_v(row, k) for k in ("open", "high", "low", "close")]
        if not all(isfinite(v) for v in values) or values[1] < values[2]:
            return {"ok": False, "error": "OHLC contains invalid values or high < low.", "trades": [], "metrics": {}}

    base_seconds = _TIMEFRAME_SECONDS.get(str(base_timeframe).upper())
    if higher_timeframes is not None and base_seconds is None:
        raise ValueError(f"Unsupported base_timeframe: {base_timeframe}")
    if higher_timeframes is not None and any(_row_time(row) is None for row in rows):
        return {"ok": False, "error": "MTF backtest requires UTC epoch-second timestamps on every base bar.", "trades": [], "metrics": {}}
    prepared_mtf = _prepare_mtf_frames(higher_timeframes) if higher_timeframes is not None else None
    equity = float(starting_equity)
    peak = equity
    max_drawdown = 0.0
    trades: list[dict[str, Any]] = []
    blocked_by_mtf = 0
    mtf_contexts = 0
    i = max(50 if higher_timeframes is not None else 30, 15, start_index)
    while i < len(rows) - 1:
        # Only candles through i are used to generate a signal. Entry is next open.
        history = rows[:i + 1]
        # Reuse the live signal engine instead of maintaining a second, simpler
        # SMA/RSI rule set. Append a synthetic forming bar because the live API
        # deliberately excludes the last (forming) candle from its analysis.
        last_row = history[-1]
        last_close = _v(last_row, "close")
        try:
            last_time = _v(last_row, "time")
            forming = {"time": int(last_time) + 1, "open": last_close,
                       "high": last_close, "low": last_close, "close": last_close}
        except (TypeError, KeyError, IndexError, ValueError, AttributeError):
            forming = {"open": last_close, "high": last_close,
                       "low": last_close, "close": last_close}
        # A zero-spread synthetic quote is used only to ask for a direction.
        # The actual simulated fill remains the next candle's open below.
        quote_price = _v(rows[i + 1], "open")
        signal = make_demo_signal(
            "BACKTEST", "HISTORICAL", SimpleNamespace(bid=quote_price, ask=quote_price),
            history + [forming], digits=10
        )
        direction = str(signal.get("direction", "WAIT")).upper()
        mtf_code = "NOT_USED"
        mtf_overall = "لم يتم تمرير بيانات الأطر الأعلى"
        if higher_timeframes is not None:
            base_open_time = _row_time(rows[i])
            decision_time = base_open_time + base_seconds
            mtf_analysis = _mtf_snapshot(higher_timeframes, decision_time, prepared_mtf)
            mtf_contexts += 1
            mtf_code = str(mtf_analysis.get("overall_code", "INSUFFICIENT"))
            mtf_overall = str(mtf_analysis.get("overall", "سياق غير متاح"))
            gated = apply_multi_timeframe_gate(signal, mtf_analysis)
            if direction in ("BUY", "SELL") and str(gated.get("direction", "WAIT")).upper() == "WAIT":
                blocked_by_mtf += 1
            signal = gated
            direction = str(signal.get("direction", "WAIT")).upper()
        atr = float(signal.get("atr") or 0.0)
        if direction == "WAIT" or atr <= 0:
            i += 1
            continue

        entry_i = i + 1
        entry = _v(rows[entry_i], "open")
        stop_distance = stop_atr * atr
        if direction == "BUY":
            stop, target = entry - stop_distance, entry + stop_distance * reward_risk
        else:
            stop, target = entry + stop_distance, entry - stop_distance * reward_risk
        exit_price, exit_i, outcome = None, None, "OPEN"
        for j in range(entry_i, len(rows)):
            high, low = _v(rows[j], "high"), _v(rows[j], "low")
            if direction == "BUY":
                hit_stop, hit_target = low <= stop, high >= target
            else:
                hit_stop, hit_target = high >= stop, low <= target
            if hit_stop:  # pessimistic if both touched in the same bar
                exit_price, exit_i, outcome = stop, j, "STOP"
                break
            if hit_target:
                exit_price, exit_i, outcome = target, j, "TARGET"
                break
        if exit_price is None:
            # Do not count an unresolved position as a completed trade.
            break
        signed_move = (exit_price - entry) if direction == "BUY" else (entry - exit_price)
        r_multiple = signed_move / stop_distance
        risk_cash = equity * float(risk_fraction)
        spread_cost_cash = 0.0
        if spread_point_size is not None:
            # MT5 exports spread in points. Average entry/exit spread approximates
            # one round-trip spread in price units, then scales it by the stop risk.
            entry_spread = _v(rows[entry_i], "spread_points") * spread_point_size
            exit_spread = _v(rows[exit_i], "spread_points") * spread_point_size
            spread_price_cost = (entry_spread + exit_spread) / 2.0
            spread_cost_cash = risk_cash * (spread_price_cost / stop_distance)
        total_cost_cash = float(cost_per_trade) + spread_cost_cash
        pnl = risk_cash * r_multiple - total_cost_cash
        equity += pnl
        peak = max(peak, equity)
        max_drawdown = max(max_drawdown, (peak - equity) / peak if peak else 0.0)
        trades.append({"direction": direction, "entry_index": entry_i, "exit_index": exit_i,
                       "entry": entry, "stop_loss": stop, "take_profit": target,
                       "exit": exit_price, "outcome": outcome, "r_multiple": r_multiple,
                       "signal_strategy_id": signal.get("strategy_id", "unknown"),
                       "signal_rule_score": int(signal.get("confidence", 0) or 0),
                       "mtf_gate": signal.get("multi_timeframe_gate", "NOT_USED"),
                       "mtf_overall": signal.get("multi_timeframe_overall", mtf_overall),
                       "fixed_cost": float(cost_per_trade), "spread_cost": spread_cost_cash,
                       "total_cost": total_cost_cash, "pnl": pnl, "equity_after": equity})
        # Avoid overlapping positions in this simple baseline.
        i = exit_i + 1

    wins = [t for t in trades if t["pnl"] > 0]
    losses = [t for t in trades if t["pnl"] < 0]
    gross_profit = sum(t["pnl"] for t in wins)
    gross_loss = abs(sum(t["pnl"] for t in losses))
    metrics = {
        "starting_equity": float(starting_equity), "ending_equity": equity,
        "net_pnl": equity - float(starting_equity), "trade_count": len(trades),
        "win_rate_percent": (len(wins) / len(trades) * 100.0) if trades else 0.0,
        "profit_factor": (gross_profit / gross_loss) if gross_loss > 0 else (float("inf") if gross_profit > 0 else 0.0),
        "max_drawdown_percent": max_drawdown * 100.0,
        "average_r": (sum(t["r_multiple"] for t in trades) / len(trades)) if trades else 0.0,
        "expectancy_cash_per_trade": (sum(t["pnl"] for t in trades) / len(trades)) if trades else 0.0,
        "cost_per_trade": float(cost_per_trade),
        "spread_point_size": spread_point_size,
        "spread_cost_total": sum(t.get("spread_cost", 0.0) for t in trades),
        "total_fixed_costs": sum(t.get("fixed_cost", 0.0) for t in trades),
        "total_costs": sum(t.get("total_cost", 0.0) for t in trades),
        "mtf_contexts_evaluated": mtf_contexts,
        "mtf_blocked_signals": blocked_by_mtf,
    }
    note = ("Uses the shared signal engine on closed bars; entry is next-bar open; stop is assumed first if stop and target are both touched. "
            "Fixed costs are caller-supplied. "
            + ("Historical spread cost is approximate from MT5 spread points and the supplied SYMBOL_POINT; not a bid/ask tick simulation. " if spread_point_size is not None else "Historical spread cost is not modeled. ")
            + "Calibrate costs to the broker/instrument. "
            + ("M15/H1/H4 snapshots are aligned by UTC bar-close time; missing, neutral, or conflicting context vetoes actionable signals. " if higher_timeframes is not None else "No higher-timeframe history was supplied, so MTF gating was not applied. ")
            + "This is a research baseline, not a guarantee of future performance.")
    return {"ok": True, "trades": trades, "metrics": metrics, "note": note}
