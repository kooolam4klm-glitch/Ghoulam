"""Multi-timeframe trend/volatility context and a conservative signal veto gate.

The analysis excludes the currently-forming candle. A separate gate can block a
single-timeframe suggestion when higher timeframes are missing, neutral,
conflicting, or clearly opposing. This module never sends broker orders.
"""
from __future__ import annotations
from statistics import median
from typing import Any, Mapping


def _value(row: Any, key: str) -> float:
    try:
        return float(row[key])
    except (TypeError, KeyError, IndexError, ValueError):
        return float(getattr(row, key))


def _sma(values: list[float], period: int) -> float:
    return sum(values[-period:]) / period


def _rsi(closes: list[float], period: int = 14) -> float:
    changes = [closes[i] - closes[i - 1] for i in range(1, len(closes))]
    recent = changes[-period:]
    if len(recent) < period:
        return 50.0
    gains = sum(max(x, 0.0) for x in recent) / period
    losses = sum(max(-x, 0.0) for x in recent) / period
    if losses <= 0:
        return 100.0 if gains > 0 else 50.0
    return 100.0 - (100.0 / (1.0 + gains / losses))


def _true_ranges(rows: list[Any]) -> list[float]:
    ranges: list[float] = []
    for i in range(1, len(rows)):
        high = _value(rows[i], "high")
        low = _value(rows[i], "low")
        prev_close = _value(rows[i - 1], "close")
        ranges.append(max(high - low, abs(high - prev_close), abs(low - prev_close)))
    return ranges


def analyze_timeframe(timeframe: str, source_rows: Any) -> dict[str, Any]:
    """Analyze one MT5 timeframe using closed candles only."""
    rows = list(source_rows) if source_rows is not None else []
    # copy_rates_from_pos(..., 0, ...) includes the forming candle at the end.
    if len(rows) > 1:
        rows = rows[:-1]
    if len(rows) < 55:
        return {
            "timeframe": timeframe, "ok": False, "bias": "بيانات غير كافية",
            "bias_code": "UNKNOWN", "regime": "غير معروف", "close": None,
            "sma20": None, "sma50": None, "rsi14": None, "atr14": None,
            "atr_ratio": None, "message": "نحتاج إلى 55 شمعة مغلقة على الأقل.",
        }

    closes = [_value(row, "close") for row in rows]
    opens = [_value(row, "open") for row in rows]
    highs = [_value(row, "high") for row in rows]
    lows = [_value(row, "low") for row in rows]
    prices = closes + opens + highs + lows
    if (not all(value == value and abs(value) != float("inf") for value in prices)
            or any(h < max(o, c) or l > min(o, c) or h < l
                   for o, h, l, c in zip(opens, highs, lows, closes))):
        return {"timeframe": timeframe, "ok": False, "bias": "بيانات غير صالحة",
                "bias_code": "UNKNOWN", "regime": "غير معروف",
                "message": "تحتوي بيانات OHLC على قيمة غير صالحة أو غير متسقة."}

    times = []
    for row in rows:
        try:
            stamp = int(row["time"])
        except (TypeError, KeyError, IndexError, ValueError):
            try:
                stamp = int(getattr(row, "time"))
            except (TypeError, ValueError, AttributeError):
                stamp = None
        times.append(stamp)
    if all(stamp is not None for stamp in times) and any(a >= b for a, b in zip(times, times[1:])):
        return {"timeframe": timeframe, "ok": False, "bias": "ترتيب زمني غير صالح",
                "bias_code": "UNKNOWN", "regime": "غير معروف",
                "message": "الشموع ليست مرتبة تصاعديًا زمنيًا."}

    sma20 = _sma(closes, 20)
    sma50 = _sma(closes, 50)
    rsi14 = _rsi(closes, 14)
    trs = _true_ranges(rows)
    if len(trs) < 14:
        return {"timeframe": timeframe, "ok": False, "bias": "بيانات غير كافية",
                "bias_code": "UNKNOWN", "regime": "غير معروف",
                "message": "بيانات ATR غير كافية."}

    # Compare current ATR against its own recent history, avoiding fixed absolute
    # thresholds across instruments with different price scales.
    atr_series = [sum(trs[i - 13:i + 1]) / 14 for i in range(13, len(trs))]
    atr14 = atr_series[-1]
    historical_atrs = atr_series[-31:-1] if len(atr_series) > 1 else []
    typical_atr = median(historical_atrs) if historical_atrs else atr14
    atr_ratio = atr14 / typical_atr if typical_atr > 0 else 1.0
    last_close = closes[-1]

    if last_close > sma20 > sma50 and rsi14 >= 52:
        bias, bias_code = "صاعد", "BULLISH"
    elif last_close < sma20 < sma50 and rsi14 <= 48:
        bias, bias_code = "هابط", "BEARISH"
    else:
        bias, bias_code = "محايد / متداخل", "NEUTRAL"

    if atr_ratio >= 1.5:
        regime = "تقلب مرتفع"
    elif atr_ratio <= 0.67:
        regime = "تقلب منخفض"
    else:
        regime = "تقلب معتاد"

    return {
        "timeframe": timeframe, "ok": True, "bias": bias,
        "bias_code": bias_code, "regime": regime, "close": last_close,
        "sma20": sma20, "sma50": sma50, "rsi14": rsi14,
        "atr14": atr14, "atr_ratio": atr_ratio,
        "message": f"RSI={rsi14:.1f}؛ نسبة ATR إلى المعتاد={atr_ratio:.2f}x",
    }


def analyze_multi_timeframe(frames: Mapping[str, Any]) -> dict[str, Any]:
    """Return M15/H1/H4 read-only context and cautious alignment label."""
    order = ("M15", "H1", "H4")
    results = {tf: analyze_timeframe(tf, frames.get(tf, [])) for tf in order}
    usable = [item for item in results.values() if item.get("ok")]
    bullish = sum(item.get("bias_code") == "BULLISH" for item in usable)
    bearish = sum(item.get("bias_code") == "BEARISH" for item in usable)
    neutral = sum(item.get("bias_code") == "NEUTRAL" for item in usable)

    if len(usable) < 2:
        overall, overall_code = "بيانات غير كافية للمقارنة", "INSUFFICIENT"
    elif bullish >= 2 and bearish == 0:
        overall, overall_code = f"ميل صعودي متوافق ({bullish}/{len(usable)} أطر)", "BULLISH_ALIGNMENT"
    elif bearish >= 2 and bullish == 0:
        overall, overall_code = f"ميل هبوطي متوافق ({bearish}/{len(usable)} أطر)", "BEARISH_ALIGNMENT"
    elif bullish > 0 and bearish > 0:
        overall, overall_code = "تعارض بين الأطر — الحذر أولى", "CONFLICT"
    elif neutral == len(usable):
        overall, overall_code = "اتجاه غير واضح / تذبذب محتمل", "NEUTRAL"
    else:
        overall, overall_code = "توافق جزئي — لا يكفي وحده لاتخاذ قرار", "PARTIAL"

    return {
        "overall": overall, "overall_code": overall_code,
        "counts": {"bullish": bullish, "bearish": bearish, "neutral": neutral,
                   "usable": len(usable)},
        "timeframes": results,
        "note": "تُستخدم الأطر الأعلى كفلتر أمان لمنع الإشارات المتعارضة؛ لا يُرسل أي أمر تداول.",
    }


def apply_multi_timeframe_gate(signal: dict[str, Any], analysis: dict[str, Any] | None) -> dict[str, Any]:
    """Apply higher-timeframe context as a hard veto to actionable suggestions.

    This is a safety gate for recommendations, not a forecast or an order sender.
    Missing, neutral, or conflicting context means WAIT rather than guessing.
    """
    result = dict(signal or {})
    direction = str(result.get("direction", "WAIT")).upper()
    code = str((analysis or {}).get("overall_code", "INSUFFICIENT"))
    counts = (analysis or {}).get("counts", {}) or {}
    bullish = int(counts.get("bullish", 0) or 0)
    bearish = int(counts.get("bearish", 0) or 0)
    usable = int(counts.get("usable", 0) or 0)
    overall = str((analysis or {}).get("overall", "السياق متعدد الأطر غير متاح"))
    block_reason = None

    if direction in ("BUY", "SELL"):
        if usable < 2 or code == "INSUFFICIENT":
            block_reason = "بيانات M15/H1/H4 غير كافية؛ حُجبت التوصية حتى تتوفر مقارنة صالحة."
        elif code == "CONFLICT":
            block_reason = "الأطر الأعلى متعارضة؛ لا يتم فرض BUY أو SELL."
        elif code == "NEUTRAL":
            block_reason = "الأطر الأعلى محايدة؛ لا يوجد اتجاه أعلى واضح يدعم الدخول."
        elif code == "BULLISH_ALIGNMENT" and direction == "SELL":
            block_reason = "رفض البيع: الأطر الأعلى متوافقة صعوديًا، وقد يكون الهبوط الحالي تصحيحًا."
        elif code == "BEARISH_ALIGNMENT" and direction == "BUY":
            block_reason = "رفض الشراء: الأطر الأعلى متوافقة هبوطيًا، وقد يكون الصعود الحالي ارتدادًا."
        elif code == "PARTIAL":
            if direction == "SELL" and bullish > 0:
                block_reason = "رفض البيع: يوجد إطار أعلى صاعد مع عدم اكتمال التوافق."
            elif direction == "BUY" and bearish > 0:
                block_reason = "رفض الشراء: يوجد إطار أعلى هابط مع عدم اكتمال التوافق."
            elif bullish == 0 and bearish == 0:
                block_reason = "لا يظهر اتجاه أعلى واضح؛ الأفضل الانتظار."

    result["multi_timeframe"] = analysis
    result["multi_timeframe_gate"] = "BLOCKED" if block_reason else ("ALIGNED" if direction in ("BUY", "SELL") else "WAIT")
    result["multi_timeframe_overall"] = overall
    if block_reason:
        result["blocked_direction"] = direction
        result["summary"] = str(result.get("summary", "")).replace(
            f"الاتجاه المقترح: {direction}", f"الإشارة الأولية قبل فلتر الاتجاه الأعلى: {direction}", 1
        )
        result["direction"] = "WAIT"
        result["entry"] = None
        result["stop_loss"] = None
        result["take_profit"] = None
        warnings = list(result.get("warnings", []) or [])
        warnings.append(block_reason)
        result["warnings"] = warnings
        result["bias"] = "تعارض/تأكيد غير كافٍ — انتظار"
        result["summary"] = (
            str(result.get("summary", ""))
            + f"\n\nفلتر الاتجاه الأعلى: {overall}.\n"
            + block_reason
            + "\nلم يتم إنشاء صفقة أو إرسال أي أمر."
        )
    elif direction in ("BUY", "SELL"):
        result["summary"] = str(result.get("summary", "")) + f"\n\nفلتر الاتجاه الأعلى: {overall}. لا يوجد تعارض واضح مع هذه الإشارة."
    else:
        result["summary"] = str(result.get("summary", "")) + f"\n\nفلتر الاتجاه الأعلى: {overall}."
    return result
