"""Voice-language selection independent from the interface language."""
from __future__ import annotations
import re

SUPPORTED = {"ar", "en", "fr", "ru"}


def detect_text_language(text: str, fallback: str = "en") -> str:
    """Best-effort script/keyword detection for short assistant responses.

    This is intentionally conservative: Arabic and Cyrillic scripts are strong
    signals; French is selected by common French characters/words; otherwise
    use the caller's fallback language.
    """
    value = str(text or "")
    if re.search(r"[\u0600-\u06ff\u0750-\u077f\u08a0-\u08ff]", value):
        return "ar"
    if re.search(r"[\u0400-\u04ff]", value):
        return "ru"
    lower = value.lower()
    if re.search(r"[àâçéèêëîïôùûüÿœæ]", lower) or re.search(
        r"\b(bonjour|merci|analyse|marché|position|achat|vente|risque|vous|avec|est|une|les|des)\b", lower
    ):
        return "fr"
    if re.search(r"\b(hello|the|market|price|trend|please|thanks|what|why|how|buy|sell|signal|position|risk|account|today|is|are|can|you)\b", lower):
        return "en"
    # If the text contains Latin letters but no strong French markers, English
    # is the safest fallback among the supported languages.
    if re.search(r"[a-z]", lower):
        return "en"
    return fallback if fallback in SUPPORTED else "en"


def resolve_voice_language(preference: str, text: str = "", interface_language: str = "ar") -> str:
    """Resolve explicit voice choice or 'auto' from response text/interface."""
    preference = str(preference or "auto").lower()
    if preference in SUPPORTED:
        return preference
    if preference != "auto":
        preference = "auto"
    return detect_text_language(text, fallback=interface_language if interface_language in SUPPORTED else "ar")
