"""Global Qt theme helpers."""
DARK_QSS = r"""
QMainWindow, QDialog, QWidget { background: #0b1220; color: #dce6f5; }
QLabel { color: #dce6f5; }
QFrame#navigationRail { background: #07101e; border: 1px solid #243650; border-radius: 10px; }
QGroupBox { border: 1px solid #283750; border-radius: 8px; margin-top: 10px; padding: 10px 7px 7px 7px; font-weight: 600; color: #a7c5ff; }
QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 5px; }
QLineEdit, QPlainTextEdit, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox, QTableWidget, QListWidget { background: #101a2b; color: #e6edf8; border: 1px solid #2c3b54; border-radius: 5px; padding: 5px; selection-background-color: #6545b8; }
QComboBox QAbstractItemView { background: #101a2b; color: #e6edf8; selection-background-color: #6545b8; }
QPushButton { background: #1a2940; color: #e6edf8; border: 1px solid #354965; border-radius: 6px; padding: 7px 11px; }
QPushButton:hover { background: #283b5a; border-color: #8b5cf6; }
QPushButton:focus { border: 1px solid #2dd4bf; }
QPushButton:pressed { background: #453078; }
QPushButton:disabled { color: #708099; background: #121b2a; }
QTabWidget::pane { border: 1px solid #2c3b54; border-radius: 6px; }
QTabBar::tab { background: #101a2b; color: #bac9df; padding: 8px 14px; margin-right: 3px; border-top-left-radius: 5px; border-top-right-radius: 5px; }
QTabBar::tab:selected { background: #392667; color: white; }
QHeaderView::section { background: #18263b; color: #c5d7ef; padding: 6px; border: 1px solid #26344a; }
QCheckBox { spacing: 8px; }
QCheckBox::indicator { width: 16px; height: 16px; }
QScrollBar:vertical { background: #0d1726; width: 12px; margin: 0; }
QScrollBar::handle:vertical { background: #354965; min-height: 20px; border-radius: 5px; }
"""

LIGHT_QSS = r"""
QMainWindow, QDialog, QWidget { background: #f4f7fb; color: #172235; }
QLabel { color: #172235; }
QGroupBox { border: 1px solid #c7d2e2; border-radius: 8px; margin-top: 10px; padding: 10px 7px 7px 7px; font-weight: 600; color: #3b4e6b; }
QGroupBox::title { subcontrol-origin: margin; left: 12px; padding: 0 5px; }
QLineEdit, QPlainTextEdit, QTextEdit, QComboBox, QSpinBox, QDoubleSpinBox, QTableWidget, QListWidget { background: white; color: #172235; border: 1px solid #c7d2e2; border-radius: 5px; padding: 5px; selection-background-color: #c7d2fe; }
QComboBox QAbstractItemView { background: white; color: #172235; }
QPushButton { background: #e7edf7; color: #172235; border: 1px solid #c7d2e2; border-radius: 6px; padding: 7px 11px; }
QPushButton:hover { background: #dbe5f5; border-color: #7c3aed; }
QPushButton:disabled { color: #9aa7b8; }
QTabWidget::pane { border: 1px solid #c7d2e2; }
QTabBar::tab { background: #e7edf7; color: #334155; padding: 8px 14px; }
QTabBar::tab:selected { background: #ddd6fe; color: #312e81; }
QHeaderView::section { background: #e7edf7; color: #172235; padding: 6px; border: 1px solid #c7d2e2; }
"""


def apply_theme(app, theme: str = "dark") -> None:
    if theme == "system":
        app.setStyleSheet("")
    elif theme == "light":
        app.setStyleSheet(LIGHT_QSS)
    else:
        app.setStyleSheet(DARK_QSS)
