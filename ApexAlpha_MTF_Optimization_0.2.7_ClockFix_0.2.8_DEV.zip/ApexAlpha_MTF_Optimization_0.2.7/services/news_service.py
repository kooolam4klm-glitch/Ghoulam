"""Small RSS news reader for the Apex Alpha market-news panel.

Network work should be called from a worker thread by the GUI. Returned items
are source-labelled and timestamps are preserved; an empty result is never
represented as live news.
"""
from __future__ import annotations
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from html import unescape
import re
import socket
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from xml.etree import ElementTree as ET

DEFAULT_FEEDS = (
    ("CoinDesk", "https://www.coindesk.com/arc/outboundfeeds/rss/"),
    ("Cointelegraph", "https://cointelegraph.com/rss"),
)
USER_AGENT = "ApexAlpha/2.7 (+market-news RSS reader)"


def _clean_text(value: str) -> str:
    value = unescape(re.sub(r"<[^>]+>", " ", value or ""))
    return re.sub(r"\s+", " ", value).strip()


def _parse_date(value: str) -> str:
    if not value:
        return ""
    try:
        dt = parsedate_to_datetime(value)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc).isoformat(timespec="seconds")
    except (TypeError, ValueError, OverflowError):
        return value.strip()


def parse_rss(xml_data: bytes | str, source: str, limit: int = 20) -> list[dict]:
    """Parse RSS 2.0 or common Atom feeds into normalized article records."""
    if isinstance(xml_data, bytes):
        xml_data = xml_data.decode("utf-8", errors="replace")
    root = ET.fromstring(xml_data)
    items = []
    # RSS 2.0 and RDF item nodes.
    nodes = root.findall(".//item")
    atom_ns = {"a": "http://www.w3.org/2005/Atom"}
    if not nodes:
        nodes = root.findall(".//a:entry", atom_ns)
    for node in nodes[:max(1, int(limit))]:
        def child_text(names):
            for name in names:
                found = node.find(name)
                if found is not None and found.text:
                    return found.text.strip()
            return ""
        title = _clean_text(child_text(["title", "{http://www.w3.org/2005/Atom}title"]))
        link = child_text(["link"])
        if not link:
            link_node = node.find("{http://www.w3.org/2005/Atom}link")
            if link_node is not None:
                link = link_node.attrib.get("href", "")
        description = _clean_text(child_text([
            "description", "content:encoded", "{http://purl.org/rss/1.0/modules/content/}encoded",
            "{http://www.w3.org/2005/Atom}summary", "{http://www.w3.org/2005/Atom}content"
        ]))
        published = child_text(["pubDate", "published", "updated", "{http://www.w3.org/2005/Atom}published", "{http://www.w3.org/2005/Atom}updated"])
        if not title or not link.startswith(("https://", "http://")):
            continue
        items.append({"title": title, "summary": description[:500], "url": link,
                      "source": source, "published": _parse_date(published)})
    return items


def fetch_feed(source: str, url: str, timeout: float = 8.0, limit: int = 20) -> dict:
    """Fetch one RSS/Atom feed with bounded timeout and normalized errors."""
    request = Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/rss+xml, application/atom+xml, application/xml, text/xml"})
    try:
        with urlopen(request, timeout=timeout) as response:
            data = response.read(2_000_000)
        return {"source": source, "ok": True, "items": parse_rss(data, source, limit), "error": ""}
    except (HTTPError, URLError, TimeoutError, socket.timeout, OSError, ET.ParseError, ValueError) as exc:
        return {"source": source, "ok": False, "items": [], "error": str(exc)[:300]}


def fetch_market_news(feeds=DEFAULT_FEEDS, per_feed: int = 12, total_limit: int = 30) -> dict:
    """Fetch configured feeds sequentially; invoke in a background worker."""
    all_items, errors = [], []
    for source, url in feeds:
        result = fetch_feed(source, url, limit=per_feed)
        all_items.extend(result["items"])
        if not result["ok"]:
            errors.append({"source": source, "error": result["error"]})
    seen, unique = set(), []
    for item in all_items:
        key = item["url"]
        if key in seen:
            continue
        seen.add(key); unique.append(item)
    unique.sort(key=lambda x: x.get("published", ""), reverse=True)
    return {"ok": bool(unique), "items": unique[:max(1, int(total_limit))],
            "errors": errors, "updated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "message": "" if unique else "No live news available; check network/feed access."}
