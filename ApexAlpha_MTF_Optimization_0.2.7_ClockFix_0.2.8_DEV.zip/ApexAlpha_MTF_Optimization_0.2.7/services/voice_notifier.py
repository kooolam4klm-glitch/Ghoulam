"""Non-blocking desktop voice alerts. Windows uses built-in System.Speech."""
from __future__ import annotations
import base64
import os
import subprocess
import threading
import time

_LOCALE = {"ar": "ar-SA", "en": "en-US", "fr": "fr-FR", "ru": "ru-RU"}


class VoiceNotifier:
    def __init__(self):
        self._lock = threading.Lock()
        self._last_text = ""
        self._last_time = 0.0

    def speak(self, text: str, language: str = "ar", enabled: bool = True) -> bool:
        text = str(text or "").strip()
        if not enabled or not text:
            return False
        with self._lock:
            now = time.monotonic()
            # Suppress rapid duplicate emissions only; a later identical alert is valid.
            if text == self._last_text and now - self._last_time < 3.0:
                return False
            self._last_text = text
            self._last_time = now
        threading.Thread(target=self._speak_worker, args=(text, language), daemon=True,
                         name="ApexVoiceAlert").start()
        return True

    @staticmethod
    def _speak_worker(text: str, language: str):
        try:
            if os.name == "nt":
                encoded = base64.b64encode(text.encode("utf-8")).decode("ascii")
                culture = _LOCALE.get(language, "ar-SA")
                script = (
                    "Add-Type -AssemblyName System.Speech; "
                    "$t=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('" + encoded + "')); "
                    "$s=New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                    "try{$s.SelectVoiceByHints([System.Speech.Synthesis.VoiceGender]::NotSet,"
                    "[System.Speech.Synthesis.VoiceAge]::NotSet,0,"
                    "[Globalization.CultureInfo]::GetCultureInfo('" + culture + "'))}catch{}; "
                    "$s.Speak($t); $s.Dispose()"
                )
                subprocess.run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                               timeout=45, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), check=False)
            else:
                try:
                    import pyttsx3
                    engine = pyttsx3.init(); engine.say(text); engine.runAndWait(); engine.stop()
                except Exception:
                    pass
        except Exception:
            pass
