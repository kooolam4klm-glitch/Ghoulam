"""Minimal OpenAI-compatible Chat Completions client using only stdlib."""
from __future__ import annotations
import json
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError


def chat_completion(api_key: str, model: str, base_url: str, messages: list[dict], timeout: int = 30, max_completion_tokens: int = 800) -> str:
    if not api_key:
        raise ValueError("لم يُضف مفتاح OpenAI API. افتح الإعدادات لإضافته.")
    base = (base_url or "https://api.openai.com/v1").strip().rstrip("/")
    if not base.startswith("https://"):
        raise ValueError("عنوان API يجب أن يبدأ بـ https:// حفاظًا على سرية المفتاح.")
    payload = {"model": (model or "gpt-4o-mini").strip(), "messages": messages,
               "max_completion_tokens": max(1, min(int(max_completion_tokens), 4000))}
    request = Request(base + "/chat/completions", data=json.dumps(payload).encode("utf-8"),
                      headers={"Authorization": f"Bearer {api_key}",
                               "Content-Type": "application/json", "User-Agent": "ApexAlpha/2.9.0"},
                      method="POST")
    try:
        with urlopen(request, timeout=timeout) as response:
            data = json.loads(response.read().decode("utf-8"))
    except HTTPError as exc:
        body = exc.read(2000).decode("utf-8", errors="replace")
        raise RuntimeError(f"OpenAI API أعاد HTTP {exc.code}: {body}") from exc
    except URLError as exc:
        raise RuntimeError(f"تعذر الاتصال بخدمة الذكاء الاصطناعي: {exc.reason}") from exc
    try:
        return str(data["choices"][0]["message"]["content"]).strip()
    except (KeyError, IndexError, TypeError) as exc:
        raise RuntimeError("استجابة API لا تحتوي على نص متوقع.") from exc


def test_connection(api_key: str, model: str, base_url: str) -> str:
    response = chat_completion(api_key, model, base_url,
        [{"role": "user", "content": "Reply with the single word OK."}], timeout=20)
    return response or "اتصال ناجح، لكن الرد كان فارغًا."
