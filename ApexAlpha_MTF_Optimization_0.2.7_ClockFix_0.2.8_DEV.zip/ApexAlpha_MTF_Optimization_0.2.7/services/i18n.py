"""Lightweight translation layer for the main desktop UI and settings."""
from PySide6.QtWidgets import QLabel, QGroupBox, QLineEdit, QPlainTextEdit, QTabWidget, QWidget, QAbstractButton

TEXT = {
    "أكاديمية الاستراتيجيات": {"en":"Strategy Academy", "fr":"Académie des stratégies", "ru":"Академия стратегий"},
    "Apex Alpha — أكاديمية الاستراتيجيات": {"en":"Apex Alpha — Strategy Academy", "fr":"Apex Alpha — Académie des stratégies", "ru":"Apex Alpha — Академия стратегий"},
    "مصدر الدرس": {"en":"Lesson source", "fr":"Source du cours", "ru":"Источник урока"},
    "عنوان الدرس:": {"en":"Lesson title:", "fr":"Titre du cours :", "ru":"Название урока:"},
    "رابط الفيديو:": {"en":"Video URL:", "fr":"URL de la vidéo :", "ru":"Ссылка на видео:"},
    "نوع المصدر:": {"en":"Source type:", "fr":"Type de source :", "ru":"Тип источника:"},
    "النص المستخرج / الترجمة": {"en":"Extracted text / subtitles", "fr":"Texte extrait / sous-titres", "ru":"Извлечённый текст / субтитры"},
    "استيراد نص / ترجمة": {"en":"Import text / subtitles", "fr":"Importer texte / sous-titres", "ru":"Импорт текста / субтитров"},
    "جلب ترجمة الرابط": {"en":"Fetch available captions", "fr":"Récupérer les sous-titres disponibles", "ru":"Получить доступные субтитры"},
    "تفريغ ملف فيديو/صوت": {"en":"Transcribe video / audio file", "fr":"Transcrire vidéo / audio", "ru":"Расшифровать видео / аудио"},
    "حفظ في الذاكرة": {"en":"Save to memory", "fr":"Enregistrer en mémoire", "ru":"Сохранить в память"},
    "استخراج الاستراتيجية بالذكاء الاصطناعي": {"en":"Extract strategy with AI", "fr":"Extraire la stratégie avec l’IA", "ru":"Извлечь стратегию с помощью ИИ"},
    "ما تعلّمه النظام من الدرس — مسودة تحتاج مراجعة": {"en":"What the system extracted — draft for review", "fr":"Extraction du cours — brouillon à vérifier", "ru":"Извлечённое из урока — черновик для проверки"},
    "بحث في الدروس والاستراتيجيات...": {"en":"Search lessons and strategies...", "fr":"Rechercher cours et stratégies...", "ru":"Поиск уроков и стратегий..."},
    "درس جديد": {"en":"New lesson", "fr":"Nouveau cours", "ru":"Новый урок"},
    "حذف": {"en":"Delete", "fr":"Supprimer", "ru":"Удалить"},
    "إغلاق": {"en":"Close", "fr":"Fermer", "ru":"Закрыть"},
    "المصدر: نص مباشر": {"en":"Source: pasted text", "fr":"Source : texte collé", "ru":"Источник: вставленный текст"},
    "استورد رابطًا يحوي ترجمة متاحة، أو ملف SRT/VTT/نص، أو ملف صوت/فيديو. قد يتطلب التفريغ والتحليل اتصالًا بالإنترنت ويستهلك رصيد API. لا يتم حفظ نسخة من ملف الوسائط نفسه.": {"en":"Import a link with available captions, an SRT/VTT/text file, or audio/video. Transcription and analysis may require internet access and API usage. The media file itself is not stored.", "fr":"Importez un lien avec sous-titres disponibles, un fichier SRT/VTT/texte ou audio/vidéo. La transcription et l’analyse peuvent nécessiter Internet et une utilisation API. Le fichier média n’est pas conservé.", "ru":"Импортируйте ссылку с доступными субтитрами, файл SRT/VTT/текст или аудио/видео. Транскрибация и анализ могут требовать интернет и расходовать API. Сам медиафайл не сохраняется."},
    "الاستراتيجيات لا تؤثر في التوصيات الحالية": {"en":"Strategies do not affect current recommendations", "fr":"Les stratégies n’influencent pas les recommandations actuelles", "ru":"Стратегии пока не влияют на текущие рекомендации"},
    "فتح الشارت": {"en":"Open chart", "fr":"Ouvrir le graphique", "ru":"Открыть график"},
    "فتح التوصيات": {"en":"Open recommendations", "fr":"Ouvrir les recommandations", "ru":"Открыть рекомендации"},
    "الإعدادات": {"en":"Settings", "fr":"Paramètres", "ru":"Настройки"},
    "مساعد الذكاء الاصطناعي": {"en":"AI assistant", "fr":"Assistant IA", "ru":"ИИ-помощник"},
    "الاتصال والسوق": {"en":"Connection & Market", "fr":"Connexion et marché", "ru":"Подключение и рынок"},
    "معلومات الحساب": {"en":"Account overview", "fr":"Aperçu du compte", "ru":"Сведения о счёте"},
    "السياق متعدد الأطر — تحليل إضافي للقراءة فقط": {"en":"Multi-timeframe context — read only", "fr":"Contexte multi-unités — lecture seule", "ru":"Мульти-таймфрейм — только чтение"},
    "قراءة السوق — المحاكاة فقط": {"en":"Market analysis — simulation only", "fr":"Analyse du marché — simulation uniquement", "ru":"Анализ рынка — только симуляция"},
    "سجل الأحداث المحلي": {"en":"Local event log", "fr":"Journal local des événements", "ru":"Журнал событий"},
    "اتصال / تحديث الآن": {"en":"Connect / Refresh now", "fr":"Connecter / Actualiser", "ru":"Подключить / Обновить"},
    "إيقاف التحديث التلقائي": {"en":"Stop auto refresh", "fr":"Arrêter l’actualisation auto", "ru":"Остановить автообновление"},
    "تشغيل التحديث التلقائي": {"en":"Start auto refresh", "fr":"Démarrer l’actualisation auto", "ru":"Запустить автообновление"},
    "تحديث السياق متعدد الأطر": {"en":"Refresh multi-timeframe context", "fr":"Actualiser le contexte multi-unités", "ru":"Обновить мульти-таймфрейм"},
    "فتح الشارت الداخلي والتحكم بالمؤشرات": {"en":"Open chart & indicators", "fr":"Ouvrir le graphique et les indicateurs", "ru":"Открыть график и индикаторы"},
    "تسجيل الموافقة على المحاكاة فقط": {"en":"Approve simulation only", "fr":"Valider la simulation uniquement", "ru":"Одобрить только симуляцию"},
    "رفض الإشارة": {"en":"Reject signal", "fr":"Rejeter le signal", "ru":"Отклонить сигнал"},
    "سجل الإشارات ونتائجها": {"en":"Signal history & results", "fr":"Historique et résultats des signaux", "ru":"История и результаты сигналов"},
    "نافذة التوصيات": {"en":"Recommendations window", "fr":"Fenêtre des recommandations", "ru":"Окно рекомендаций"},
    "الرمز": {"en":"Symbol", "fr":"Symbole", "ru":"Символ"},
    "الإطار": {"en":"Timeframe", "fr":"Unité de temps", "ru":"Таймфрейм"},
    "نوع الحساب:": {"en":"Account type:", "fr":"Type de compte :", "ru":"Тип счёта:"},
    "رقم الحساب:": {"en":"Account login:", "fr":"Identifiant du compte :", "ru":"Номер счёта:"},
    "الرصيد:": {"en":"Balance:", "fr":"Solde :", "ru":"Баланс:"},
    "Equity:": {"en":"Equity:", "fr":"Valeur des fonds :", "ru":"Средства:"},
    "Server:": {"en":"Server:", "fr":"Serveur :", "ru":"Сервер:"},
    "مصدر السعر المستخدم:": {"en":"Active price source:", "fr":"Source de prix active :", "ru":"Источник цены:"},
    "حالة جسر الأسعار المحلي:": {"en":"Local price bridge:", "fr":"Pont de prix local :", "ru":"Локальный ценовой мост:"},
    "وقت Tick الخام من MT5 (غير مصحح):": {"en":"Raw MT5 tick time:", "fr":"Heure brute du tick MT5 :", "ru":"Исходное время тика MT5:"},
    "وقت Tick بعد التصحيح (محلي):": {"en":"Corrected tick time (local):", "fr":"Heure corrigée du tick (locale) :", "ru":"Исправленное время тика (местное):"},
    "وقت استلام البيانات (محلي):": {"en":"Data receipt time (local):", "fr":"Heure de réception (locale) :", "ru":"Время получения данных:"},
    "وقت حساب التحليل (محلي):": {"en":"Analysis completion (local):", "fr":"Fin de l’analyse (locale) :", "ru":"Время завершения анализа:"},
    "الاختيار التلقائي يغيّر العرض فقط ولا يغيّر إشارة التداول الأساسية.": {"en":"Auto-selection only changes chart display, not the core signal.", "fr":"La sélection auto modifie l’affichage uniquement.", "ru":"Автовыбор меняет только отображение, не основной сигнал."},
    "افتح إعدادات API": {"en":"Open API settings", "fr":"Ouvrir les paramètres API", "ru":"Открыть настройки API"},
    "لغة الواجهة:": {"en":"Interface language:", "fr":"Langue de l’interface :", "ru":"Язык интерфейса:"},
    "المظهر:": {"en":"Appearance:", "fr":"Apparence :", "ru":"Оформление:"},
    "مزوّد الذكاء الاصطناعي:": {"en":"AI provider:", "fr":"Fournisseur IA :", "ru":"Поставщик ИИ:"},
    "اسم النموذج:": {"en":"Model name:", "fr":"Nom du modèle :", "ru":"Название модели:"},
    "عنوان API الأساسي:": {"en":"API base URL:", "fr":"URL de base API :", "ru":"Базовый URL API:"},
    "مفتاح API:": {"en":"API key:", "fr":"Clé API :", "ru":"Ключ API:"},
    "اختبار الاتصال": {"en":"Test connection", "fr":"Tester la connexion", "ru":"Проверить соединение"},
    "حذف المفتاح المحفوظ": {"en":"Delete saved key", "fr":"Supprimer la clé enregistrée", "ru":"Удалить сохранённый ключ"},
    "إضافة مستوى سعري أفقي:": {"en":"Add horizontal price level:", "fr":"Ajouter un niveau horizontal :", "ru":"Добавить горизонтальный уровень:"},
    "تحديث الشارت": {"en":"Refresh chart", "fr":"Actualiser le graphique", "ru":"Обновить график"},
    "تحديث كل ثانيتين": {"en":"Refresh every 2 seconds", "fr":"Actualiser toutes les 2 secondes", "ru":"Обновлять каждые 2 секунды"},
    "تحليل الإشارات الجديدة تلقائيًا عبر API (قد يستهلك رصيدًا)": {"en":"Auto-analyse new signals via API (may incur usage costs)", "fr":"Analyser automatiquement les signaux via l’API (coût possible)", "ru":"Автоанализ новых сигналов через API (возможна оплата)"},
    "تفعيل الكلام والتنبيهات الصوتية": {"en":"Enable speech and voice alerts", "fr":"Activer la voix et les alertes", "ru":"Включить речь и голосовые оповещения"},
    "إعلان الإشارات الجديدة صوتيًا": {"en":"Speak new signal alerts", "fr":"Annoncer les nouveaux signaux", "ru":"Озвучивать новые сигналы"},
    "الإعلان عند فتح/إغلاق مركز فعلي": {"en":"Announce real position open/close", "fr":"Annoncer l’ouverture/la clôture d’une position réelle", "ru":"Сообщать об открытии/закрытии реальной позиции"},
    "قراءة ردود المساعد بصوت": {"en":"Speak assistant responses", "fr":"Lire les réponses à voix haute", "ru":"Озвучивать ответы помощника"},
    "الإعلان صوتيًا عند انقطاع الاتصال": {"en":"Voice alert on connection loss", "fr":"Alerte vocale en cas de perte de connexion", "ru":"Голосовое оповещение при потере связи"},
    "اختيار الأدوات تلقائيًا حسب حالة السوق": {"en":"Auto-select tools by market regime", "fr":"Sélection auto selon le marché", "ru":"Автовыбор инструментов по рынку"},
    "تفعيل مساعد الذكاء الاصطناعي": {"en":"Enable AI assistant", "fr":"Activer l’assistant IA", "ru":"Включить ИИ-помощника"},
    "حفظ الإعدادات": {"en":"Save settings", "fr":"Enregistrer les paramètres", "ru":"Сохранить настройки"},
    "إلغاء": {"en":"Cancel", "fr":"Annuler", "ru":"Отмена"},
    "عام": {"en":"General", "fr":"Général", "ru":"Общие"},
    "الذكاء الاصطناعي وAPI": {"en":"AI & API", "fr":"IA et API", "ru":"ИИ и API"},
    "الصوت والتنبيهات": {"en":"Voice & Alerts", "fr":"Voix et alertes", "ru":"Голос и оповещения"},
    "لغة المساعد الصوتي:": {"en":"Assistant voice language:", "fr":"Langue vocale de l’assistant :", "ru":"Язык голоса помощника:"},
    "مخاطرة تقديرية لكل توصية (محاكاة فقط):": {"en":"Estimated risk per recommendation (simulation only):", "fr":"Risque estimé par recommandation (simulation uniquement) :", "ru":"Оценочный риск на рекомендацию (только симуляция):"},
}
WINDOW_TITLES = {
    "Apex Alpha — أكاديمية الاستراتيجيات": {"en":"Apex Alpha — Strategy Academy", "fr":"Apex Alpha — Académie des stratégies", "ru":"Apex Alpha — Академия стратегий"},
    "Apex Alpha Intelligence Core": {"en":"Apex Alpha Intelligence Core", "fr":"Apex Alpha Intelligence Core", "ru":"Apex Alpha Intelligence Core"},
    "Apex Alpha — نافذة التوصيات": {"en":"Apex Alpha — Recommendations", "fr":"Apex Alpha — Recommandations", "ru":"Apex Alpha — Рекомендации"},
    "Apex Alpha — مساعد الذكاء الاصطناعي": {"en":"Apex Alpha — AI Assistant", "fr":"Apex Alpha — Assistant IA", "ru":"Apex Alpha — ИИ-помощник"},
    "Apex Alpha — الشارت الداخلي وأدوات التحليل": {"en":"Apex Alpha — Internal Chart & Analysis", "fr":"Apex Alpha — Graphique et analyse", "ru":"Apex Alpha — График и анализ"},
    "Apex Alpha — سجل الإشارات الافتراضية ونتائجها": {"en":"Apex Alpha — Paper Signal History", "fr":"Apex Alpha — Historique des signaux simulés", "ru":"Apex Alpha — История симулированных сигналов"},
}

def translate(source: str, language: str) -> str:
    if language == "ar":
        for ar, values in TEXT.items():
            if source in values.values(): return ar
        return source
    for ar, values in TEXT.items():
        if source == ar: return values.get(language, ar)
        for lang, translated in values.items():
            if source == translated: return values.get(language, ar)
    return source

def translate_widget_tree(root, language: str):
    """Translate supported Qt widgets without calling unsupported APIs.

    QGroupBox exposes title()/setTitle(), not text()/setText(); treating it
    like a label caused the entire dashboard to crash during startup.
    """
    widgets = [root] + root.findChildren(QWidget)
    for widget in widgets:
        try:
            if isinstance(widget, QGroupBox):
                original = widget.title()
                translated = translate(original, language)
                if translated != original:
                    widget.setTitle(translated)
            elif isinstance(widget, QAbstractButton):
                original = widget.text()
                translated = translate(original, language)
                if translated != original:
                    widget.setText(translated)
            elif isinstance(widget, QLabel):
                original = widget.text()
                translated = translate(original, language)
                if translated != original:
                    widget.setText(translated)

            if isinstance(widget, QLineEdit):
                placeholder = widget.placeholderText()
                if placeholder:
                    translated = translate(placeholder, language)
                    if translated != placeholder:
                        widget.setPlaceholderText(translated)

            if isinstance(widget, QPlainTextEdit):
                placeholder = widget.placeholderText()
                if placeholder:
                    translated = translate(placeholder, language)
                    if translated != placeholder:
                        widget.setPlaceholderText(translated)

            if isinstance(widget, QTabWidget):
                for i in range(widget.count()):
                    original = widget.tabText(i)
                    translated = translate(original, language)
                    if translated != original:
                        widget.setTabText(i, translated)

            title = widget.windowTitle()
            if title and title in WINDOW_TITLES:
                widget.setWindowTitle(WINDOW_TITLES[title].get(language, title))
        except (AttributeError, RuntimeError, TypeError):
            # A destroyed or unsupported native widget should not prevent the
            # rest of the application from opening.
            continue
