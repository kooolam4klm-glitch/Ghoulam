"""Small secret store: Windows DPAPI for a per-user encrypted API key.
On non-Windows platforms secrets remain in memory only; no clear-text fallback.
"""
from __future__ import annotations
import base64
import ctypes
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
# Keep the encrypted credential outside the project so it is not bundled with ZIP backups.
if os.name == "nt":
    SECRET_PATH = Path(os.environ.get("APPDATA", str(Path.home()))) / "ApexAlpha" / "openai_key.dpapi"
else:
    SECRET_PATH = ROOT / "config" / "openai_key.dpapi"
_SESSION_KEY = ""


class _DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", ctypes.c_ulong), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]


def _blob(raw: bytes):
    buf = ctypes.create_string_buffer(raw)
    return _DATA_BLOB(len(raw), ctypes.cast(buf, ctypes.POINTER(ctypes.c_ubyte))), buf


def _dpapi(raw: bytes, protect: bool) -> bytes:
    if os.name != "nt":
        raise OSError("Windows DPAPI is only available on Windows")
    from ctypes import wintypes
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    crypt32.CryptProtectData.argtypes = [ctypes.POINTER(_DATA_BLOB), wintypes.LPCWSTR,
                                         ctypes.POINTER(_DATA_BLOB), ctypes.c_void_p,
                                         ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(_DATA_BLOB)]
    crypt32.CryptProtectData.restype = wintypes.BOOL
    crypt32.CryptUnprotectData.argtypes = [ctypes.POINTER(_DATA_BLOB), ctypes.POINTER(wintypes.LPWSTR),
                                           ctypes.POINTER(_DATA_BLOB), ctypes.c_void_p,
                                           ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(_DATA_BLOB)]
    crypt32.CryptUnprotectData.restype = wintypes.BOOL
    kernel32.LocalFree.argtypes = [ctypes.c_void_p]
    kernel32.LocalFree.restype = ctypes.c_void_p
    in_blob, in_buf = _blob(raw)
    out_blob = _DATA_BLOB()
    if protect:
        ok = crypt32.CryptProtectData(ctypes.byref(in_blob), "Apex Alpha API key", None,
                                       None, None, 0x1, ctypes.byref(out_blob))
    else:
        ok = crypt32.CryptUnprotectData(ctypes.byref(in_blob), None, None, None, None,
                                        0x1, ctypes.byref(out_blob))
    if not ok:
        raise ctypes.WinError()
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        kernel32.LocalFree(out_blob.pbData)


def save_api_key(value: str) -> tuple[bool, str]:
    global _SESSION_KEY
    value = str(value or "").strip()
    if not value:
        return True, "لم يتم تغيير مفتاح API الحالي."
    _SESSION_KEY = value
    if os.name != "nt":
        return False, "حُفظ المفتاح للجلسة الحالية فقط؛ التخزين الدائم المشفر متاح على Windows."
    try:
        encrypted = _dpapi(value.encode("utf-8"), True)
        SECRET_PATH.parent.mkdir(parents=True, exist_ok=True)
        SECRET_PATH.write_bytes(base64.b64encode(encrypted))
        try: os.chmod(SECRET_PATH, 0o600)
        except OSError: pass
        return True, "حُفظ مفتاح API مشفرًا بواسطة Windows DPAPI للمستخدم الحالي."
    except Exception as exc:
        return False, f"تعذر حفظ المفتاح بشكل دائم؛ بقي في الذاكرة لهذه الجلسة فقط: {exc}"


def get_api_key() -> str:
    if _SESSION_KEY:
        return _SESSION_KEY
    env_key = os.environ.get("OPENAI_API_KEY", "").strip()
    if env_key:
        return env_key
    if os.name == "nt" and SECRET_PATH.exists():
        try:
            raw = base64.b64decode(SECRET_PATH.read_bytes(), validate=True)
            return _dpapi(raw, False).decode("utf-8")
        except Exception:
            return ""
    return ""


def clear_api_key() -> None:
    global _SESSION_KEY
    _SESSION_KEY = ""
    try: SECRET_PATH.unlink(missing_ok=True)
    except OSError: pass
