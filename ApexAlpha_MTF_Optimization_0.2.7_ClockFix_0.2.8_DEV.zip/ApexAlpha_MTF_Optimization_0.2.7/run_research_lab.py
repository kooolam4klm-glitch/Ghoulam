"""Run Apex Alpha's research comparison against chronological OHLC data.

Accepts either normalized CSV columns (time,open,high,low,close) or the
tab-separated bar export produced by MetaTrader 5 (<DATE>, <TIME>, <OPEN>,
<HIGH>, <LOW>, <CLOSE>, ...). This script never connects to MT5 or places orders.
"""
from __future__ import annotations
import argparse
import csv
import json
import math
from datetime import datetime, timezone
from pathlib import Path

from research.experiment_runner import ExperimentConfig, compare_experiments


def _parse_epoch(value: str, row_number: int) -> int:
    """Parse existing epoch values or an ISO-style combined datetime."""
    value = str(value).strip().strip('"')
    try:
        return int(float(value))
    except ValueError:
        pass
    # Useful when a source already has a single combined datetime column.
    candidates = (
        "%Y.%m.%d %H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%Y.%m.%d %H:%M",
        "%Y-%m-%d %H:%M",
    )
    for fmt in candidates:
        try:
            dt = datetime.strptime(value, fmt).replace(tzinfo=timezone.utc)
            return int(dt.timestamp())
        except ValueError:
            continue
    raise ValueError(f"Could not parse time on data row {row_number}: {value!r}")


def load_csv(path: Path):
    """Load normalized CSV or native MT5 TSV into the research lab schema.

    MT5 exports show broker-server date/time separately. We encode the displayed
    clock values as UTC epoch seconds for this single-timeframe research runner;
    this preserves chronology but is not a broker-timezone conversion.
    """
    rows = []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        first_line = handle.readline()
        if not first_line:
            raise ValueError("The input file is empty.")
        delimiter = "\t" if "\t" in first_line else ","
        handle.seek(0)
        reader = csv.DictReader(handle, delimiter=delimiter)
        if not reader.fieldnames:
            raise ValueError("Could not read column headers from the input file.")

        # MT5 uses names such as <DATE>; normalized files use plain names.
        headers = {str(name).strip().strip("<>").strip().lower(): name for name in reader.fieldnames if name is not None}
        required_prices = ("open", "high", "low", "close")
        missing_prices = [name for name in required_prices if name not in headers]
        has_epoch_time = "time" in headers
        # MT5 exports include separate <DATE> and <TIME> columns.
        has_mt5_datetime = "date" in headers and "time" in headers
        if missing_prices or (not has_epoch_time and not has_mt5_datetime):
            raise ValueError(
                "Unsupported columns. Expected time,open,high,low,close or MT5 export columns "
                "<DATE>,<TIME>,<OPEN>,<HIGH>,<LOW>,<CLOSE>. "
                f"Detected: {', '.join(reader.fieldnames)}"
            )

        for row_number, item in enumerate(reader, start=2):
            try:
                if has_mt5_datetime:
                    date_text = str(item[headers["date"]]).strip()
                    time_text = str(item[headers["time"]]).strip()
                    date_time = f"{date_text} {time_text}"
                    parsed = None
                    for fmt in ("%Y.%m.%d %H:%M:%S", "%Y-%m-%d %H:%M:%S",
                                "%Y.%m.%d %H:%M", "%Y-%m-%d %H:%M"):
                        try:
                            parsed = datetime.strptime(date_time, fmt).replace(tzinfo=timezone.utc)
                            break
                        except ValueError:
                            pass
                    if parsed is None:
                        raise ValueError(f"invalid MT5 date/time {date_time!r}")
                    epoch = int(parsed.timestamp())
                else:
                    epoch = _parse_epoch(item[headers["time"]], row_number)
                record = {"time": epoch}
                for name in required_prices:
                    value = str(item[headers[name]]).strip()
                    if not value:
                        raise ValueError(f"blank {name}")
                    record[name] = float(value)
                # Native MT5 exports carry spread in points, not price units.
                # Conversion is deferred until the user supplies SYMBOL_POINT.
                if "spread" in headers:
                    spread_text = str(item[headers["spread"]]).strip()
                    if not spread_text:
                        raise ValueError("blank spread")
                    spread_points = float(spread_text)
                    if not math.isfinite(spread_points) or spread_points < 0:
                        raise ValueError(f"invalid spread points {spread_text!r}")
                    record["spread_points"] = spread_points
                rows.append(record)
            except (KeyError, TypeError, ValueError) as exc:
                raise ValueError(f"Invalid data row {row_number}: {exc}") from exc
    if not rows:
        raise ValueError("No price bars were found in the input file.")
    return rows

def _json_safe(value):
    if isinstance(value, float) and not math.isfinite(value):
        return None
    if isinstance(value, dict):
        return {k: _json_safe(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_json_safe(v) for v in value]
    return value


def main():
    parser = argparse.ArgumentParser(description="Apex Alpha research lab (read-only)")
    parser.add_argument("csv", help="Chronological OHLC CSV")
    parser.add_argument("--train-fraction", type=float, default=0.70)
    parser.add_argument("--min-bars", type=int, default=100)
    parser.add_argument("--cost-per-trade", type=float, default=0.0,
                        help="Additional fixed estimated account-currency cost per completed trade (e.g. commission/slippage)")
    parser.add_argument("--spread-point-size", type=float, default=None,
                        help="MT5 SYMBOL_POINT for the symbol (price units per spread point); enables approximate historical spread-cost modeling")
    parser.add_argument("--output", default="research_report.json")
    args = parser.parse_args()
    rows = load_csv(Path(args.csv))
    if args.spread_point_size is not None:
        if not math.isfinite(args.spread_point_size) or args.spread_point_size <= 0:
            parser.error("--spread-point-size must be a finite positive number")
        if not all("spread_points" in row for row in rows):
            parser.error("--spread-point-size was supplied, but the input file has no MT5 SPREAD column")
    configs = [
        ExperimentConfig("RR_1.5_ATR_1.5", stop_atr=1.5, reward_risk=1.5, cost_per_trade=args.cost_per_trade, spread_point_size=args.spread_point_size),
        ExperimentConfig("RR_2.0_ATR_1.5", stop_atr=1.5, reward_risk=2.0, cost_per_trade=args.cost_per_trade, spread_point_size=args.spread_point_size),
        ExperimentConfig("RR_2.5_ATR_1.5", stop_atr=1.5, reward_risk=2.5, cost_per_trade=args.cost_per_trade, spread_point_size=args.spread_point_size),
        ExperimentConfig("RR_2.0_ATR_2.0", stop_atr=2.0, reward_risk=2.0, cost_per_trade=args.cost_per_trade, spread_point_size=args.spread_point_size),
    ]
    result = compare_experiments(rows, configs, train_fraction=args.train_fraction, min_bars=args.min_bars)
    output = Path(args.output)
    output.write_text(json.dumps(_json_safe(result), ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    print(f"Research report saved: {output.resolve()}")
    print(f"Status: {'OK' if result.get('ok') else 'CHECK'} | bars={result.get('bar_count', len(rows))}")
    print("Cost model: " + (f"historical MT5 spread (point_size={args.spread_point_size:g}) + fixed cost={args.cost_per_trade:g}" if args.spread_point_size is not None else f"fixed cost only={args.cost_per_trade:g}; historical spread NOT modeled"))
    for item in result.get("results", []):
        train = item.get("train", {})
        test = item.get("holdout", {})
        pf = test.get("profit_factor")
        pf_text = "∞" if isinstance(pf, (int, float)) and not math.isfinite(pf) else (f"{pf:.3f}" if isinstance(pf, (int, float)) else "n/a")
        print(f"{item['config']['name']}: train trades={train.get('trade_count', 0)}, "
              f"holdout trades={test.get('trade_count', 0)}, "
              f"holdout expectancy={test.get('expectancy_cash_per_trade', 0):.4f}, "
              f"net={test.get('net_pnl', 0):.2f}, PF={pf_text}, "
              f"win={test.get('win_rate_percent', 0):.2f}%, "
              f"DD={test.get('max_drawdown_percent', 0):.2f}%, "
              f"spread cost={test.get('spread_cost_total', 0):.2f}")
    print(result.get("warning", ""))
    return 0 if result.get("ok") else 2


if __name__ == "__main__":
    raise SystemExit(main())
