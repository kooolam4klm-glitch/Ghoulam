@echo off
setlocal
cd /d "%~dp0"
set "PYTHON_EXE="

rem Prefer this project's environment if it already exists.
if exist "%~dp0.venv311\Scripts\python.exe" set "PYTHON_EXE=%~dp0.venv311\Scripts\python.exe"

rem Reuse the user's V2.9.4 environment when this candidate is extracted beside it.
if not defined PYTHON_EXE if exist "%~dp0..\ApexAlpha_V2.9.4\.venv311\Scripts\python.exe" set "PYTHON_EXE=%~dp0..\ApexAlpha_V2.9.4\.venv311\Scripts\python.exe"

rem Reuse an already-installed sibling version to avoid large repeated downloads.
if not defined PYTHON_EXE if exist "%~dp0..\ApexAlpha_V2.6.0\.venv311\Scripts\python.exe" set "PYTHON_EXE=%~dp0..\ApexAlpha_V2.6.0\.venv311\Scripts\python.exe"
if not defined PYTHON_EXE if exist "%~dp0..\ApexAlpha_V2.3\.venv311\Scripts\python.exe" set "PYTHON_EXE=%~dp0..\ApexAlpha_V2.3\.venv311\Scripts\python.exe"
if not defined PYTHON_EXE if exist "%~dp0..\ApexAlpha_V2.2\.venv311\Scripts\python.exe" set "PYTHON_EXE=%~dp0..\ApexAlpha_V2.2\.venv311\Scripts\python.exe"
if not defined PYTHON_EXE if exist "%~dp0..\ApexAlpha_V2.1\.venv311\Scripts\python.exe" set "PYTHON_EXE=%~dp0..\ApexAlpha_V2.1\.venv311\Scripts\python.exe"
if not defined PYTHON_EXE if exist "%~dp0..\ApexAlpha_V2.0\.venv311\Scripts\python.exe" set "PYTHON_EXE=%~dp0..\ApexAlpha_V2.0\.venv311\Scripts\python.exe"
if not defined PYTHON_EXE if exist "%~dp0..\ApexAlpha_V1.9\.venv311\Scripts\python.exe" set "PYTHON_EXE=%~dp0..\ApexAlpha_V1.9\.venv311\Scripts\python.exe"
if not defined PYTHON_EXE if exist "%~dp0..\ApexAlpha_V1.8\.venv311\Scripts\python.exe" set "PYTHON_EXE=%~dp0..\ApexAlpha_V1.8\.venv311\Scripts\python.exe"
if not defined PYTHON_EXE if exist "%~dp0..\ApexAlpha_V1.7\.venv311\Scripts\python.exe" set "PYTHON_EXE=%~dp0..\ApexAlpha_V1.7\.venv311\Scripts\python.exe"
if not defined PYTHON_EXE if exist "%~dp0..\ApexAlpha_V1.6\.venv311\Scripts\python.exe" set "PYTHON_EXE=%~dp0..\ApexAlpha_V1.6\.venv311\Scripts\python.exe"
if not defined PYTHON_EXE if exist "%~dp0..\ApexAlpha_V1.5\.venv311\Scripts\python.exe" set "PYTHON_EXE=%~dp0..\ApexAlpha_V1.5\.venv311\Scripts\python.exe"

rem If no reusable environment exists, create one with Python 3.11.
if not defined PYTHON_EXE (
  where py >nul 2>nul
  if errorlevel 1 (
    echo Python Launcher was not found. Install Python 3.11 64-bit, then retry.
    pause
    exit /b 1
  )
  echo Creating Python 3.11 virtual environment...
  py -3.11 -m venv .venv311
  if errorlevel 1 goto :error
  set "PYTHON_EXE=%~dp0.venv311\Scripts\python.exe"
)

"%PYTHON_EXE%" -c "import MetaTrader5, PySide6, pandas, numpy, yt_dlp" >nul 2>nul
if errorlevel 1 (
  echo Installing project dependencies. This may take a few minutes on first launch...
  "%PYTHON_EXE%" -m pip install --index-url https://pypi.org/simple -r requirements.txt
  if errorlevel 1 goto :error
)

"%PYTHON_EXE%" main.py
if errorlevel 1 goto :error
exit /b 0

:error
echo.
echo Startup failed. Read the error above, then share a screenshot for help.
echo If you see "No space left on device", free disk space and retry.
pause
exit /b 1
