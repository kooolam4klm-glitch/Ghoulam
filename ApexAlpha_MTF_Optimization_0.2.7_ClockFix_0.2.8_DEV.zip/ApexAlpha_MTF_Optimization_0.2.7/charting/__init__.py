"""Read-only charting components for Apex Alpha."""
