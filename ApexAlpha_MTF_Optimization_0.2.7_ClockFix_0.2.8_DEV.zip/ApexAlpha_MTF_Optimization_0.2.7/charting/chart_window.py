from __future__ import annotations
from datetime import datetime
from math import isfinite
from typing import Any

from PySide6.QtCore import Qt, QRectF, QPointF, QTimer
from PySide6.QtGui import QPainter, QPen, QBrush, QColor, QFont, QPolygonF
from PySide6.QtWidgets import (
    QDialog, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QPushButton, QApplication,
    QLineEdit, QComboBox, QSpinBox, QCheckBox, QDoubleSpinBox, QGroupBox,
    QMessageBox
)

from charting.indicators import (
    rate_series, sma, ema, bollinger, rsi, macd, support_resistance,
    latest_indicator_values, recommend_chart_tools, evaluate_enabled_indicators,
    confirmed_swing_points,
)


class CandleChart(QWidget):
    """A self-contained painter-based candlestick chart; no charting dependency required."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(560, 360)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, True)
        self.rates: list[Any] = []
        # Main-view zoom level: fewer visible bars makes candle bodies easier to read.
        self.visible_candles = 90
        self.symbol = "BTCUSD"
        self.timeframe = "M15"
        self.digits = 2
        self.options = {
            "sma10": True, "sma30": True, "ema20": False, "bollinger": False,
            "sr": True, "volume": True, "rsi": True, "macd": False, "atr": True,
        }
        self.manual_levels: list[float] = []
        self.signal_levels: dict[str, Any] | None = None
        self.notice = "في انتظار بيانات الشموع من MT5..."

    def zoom_in(self):
        self.visible_candles = max(20, self.visible_candles - 15)
        self.update()

    def zoom_out(self):
        self.visible_candles = min(250, self.visible_candles + 15)
        self.update()

    def reset_zoom(self):
        self.visible_candles = 90
        self.update()

    def wheelEvent(self, event):  # noqa: N802 - Qt API
        # Mouse-wheel zoom works directly over the chart; it does not change data.
        if event.angleDelta().y() > 0:
            self.zoom_in()
        elif event.angleDelta().y() < 0:
            self.zoom_out()
        event.accept()

    def set_data(self, rates, symbol: str, timeframe: str, digits: int = 2):
        self.rates = list(rates) if rates is not None else []
        self.symbol = str(symbol)
        self.timeframe = str(timeframe)
        self.digits = max(0, min(10, int(digits)))
        self.notice = "" if self.rates else "لا توجد شموع متاحة لهذا الرمز والإطار."
        self.update()

    def set_options(self, key: str, enabled: bool):
        self.options[key] = bool(enabled)
        self.update()

    def add_level(self, price: float):
        if not any(abs(price - existing) < max(10 ** (-self.digits), 1e-9) for existing in self.manual_levels):
            self.manual_levels.append(float(price))
        self.update()

    def clear_levels(self):
        self.manual_levels.clear()
        self.update()

    def indicator_values(self):
        return latest_indicator_values(self.rates)

    def set_signal_levels(self, signal: dict | None):
        """Display the latest actionable paper signal; never connected to order execution."""
        if isinstance(signal, dict) and signal.get("direction") in ("BUY", "SELL"):
            self.signal_levels = {
                key: signal.get(key) for key in ("direction", "entry", "stop_loss", "take_profit", "symbol", "timeframe")
            }
        else:
            self.signal_levels = None
        self.update()

    @staticmethod
    def _color(hex_color: str) -> QColor:
        return QColor(hex_color)

    def _line_series(self, painter: QPainter, values, x_for, y_for, color, width=1.5, dashed=False):
        points = []
        for i, value in enumerate(values):
            if value is None:
                if len(points) > 1:
                    painter.setPen(QPen(color, width, Qt.PenStyle.DashLine if dashed else Qt.PenStyle.SolidLine))
                    painter.drawPolyline(QPolygonF(points))
                points = []
            else:
                v = float(value)
                if isfinite(v):
                    points.append(QPointF(x_for(i), y_for(v)))
                else:
                    if len(points) > 1:
                        painter.drawPolyline(QPolygonF(points))
                    points = []
        if len(points) > 1:
            painter.setPen(QPen(color, width, Qt.PenStyle.DashLine if dashed else Qt.PenStyle.SolidLine))
            painter.drawPolyline(QPolygonF(points))

    def paintEvent(self, event):  # noqa: N802 - Qt API
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.fillRect(self.rect(), QColor("#17191d"))
        painter.setPen(QPen(QColor("#8bb8ff")))
        painter.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        if not self.rates:
            painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self.notice)
            painter.end()
            return

        count = min(len(self.rates), self.visible_candles, 250)
        visible_start = len(self.rates) - count
        rows = self.rates[-count:]
        opens = rate_series(rows, "open")
        highs = rate_series(rows, "high")
        lows = rate_series(rows, "low")
        closes = rate_series(rows, "close")
        # MT5's last row is normally the still-forming candle. Calculate every
        # indicator over the full completed history for consistency with signals,
        # then align its values to the visible chart window. The live candle gets
        # no indicator value until it closes.
        closed_rows = self.rates[:-1] if len(self.rates) > 1 else list(self.rates)
        all_closed_closes = rate_series(closed_rows, "close")

        def align_visible(values):
            return [values[i] if i < len(values) else None
                    for i in range(visible_start, visible_start + count)]
        volumes = []
        for row in rows:
            try:
                volumes.append(float(row["tick_volume"]))
            except Exception:
                try: volumes.append(float(getattr(row, "tick_volume")))
                except Exception: volumes.append(0.0)

        view_top = 36.0
        view_bottom = float(self.height() - 34)
        pane_heights = (78 if self.options.get("rsi") else 0) + (78 if self.options.get("macd") else 0)
        volume_height = 44 if self.options.get("volume") else 0
        price_top = view_top
        # Reserve space for the time-axis labels, volume and both optional indicator panes.
        price_bottom = max(price_top + 150, view_bottom - pane_heights - volume_height - 30)
        left = 22.0
        right = float(self.width() - 92)
        plot_width = max(100.0, right - left)
        plot_height = max(130.0, price_bottom - price_top)

        # Compute all indicators on the displayed candle sequence.
        sma10_all = sma(all_closed_closes, 10)
        sma30_all = sma(all_closed_closes, 30)
        ema20_all = ema(all_closed_closes, 20)
        bb_mid_all, bb_upper_all, bb_lower_all = bollinger(all_closed_closes, 20, 2.0)
        rsi_all = rsi(all_closed_closes, 14)
        macd_line_all, macd_signal_all, macd_hist_all = macd(all_closed_closes)
        # Plot history-based indicator series aligned to the visible candle
        # window; all of them use the same complete closed-bar history.
        sma10_values = align_visible(sma10_all)
        sma30_values = align_visible(sma30_all)
        ema20_values = align_visible(ema20_all)
        bb_mid, bb_upper, bb_lower = (align_visible(bb_mid_all), align_visible(bb_upper_all), align_visible(bb_lower_all))
        rsi_values = align_visible(rsi_all)
        macd_line, macd_signal, macd_hist = (align_visible(macd_line_all), align_visible(macd_signal_all), align_visible(macd_hist_all))
        last_completed_rsi = rsi_all[-1] if rsi_all else None
        last_completed_macd = macd_line_all[-1] if macd_line_all else None
        # S/R levels use the last 20 completed bars regardless of zoom level.
        sr_support, sr_resistance = support_resistance(self.rates)

        # Scale the price axis from the visible candle range first. Far-away signal
        # targets or manually drawn levels must not flatten the candles into a line.
        visible_values = list(highs) + list(lows)
        pmin, pmax = min(visible_values), max(visible_values)
        if pmax <= pmin:
            pmax = pmin + max(abs(pmin) * 0.001, 1.0)
        candle_span = pmax - pmin
        # Include nearby overlays only when they fit the current price view.
        overlay_values = []
        if self.options.get("sma10"): overlay_values += [x for x in sma10_values if x is not None]
        if self.options.get("sma30"): overlay_values += [x for x in sma30_values if x is not None]
        if self.options.get("ema20"): overlay_values += [x for x in ema20_values if x is not None]
        if self.options.get("bollinger"): overlay_values += [x for x in bb_upper + bb_lower if x is not None]
        if self.options.get("sr"): overlay_values += [x for x in (sr_support, sr_resistance) if x is not None]
        overlay_values += self.manual_levels
        if self.signal_levels:
            for key in ("entry", "stop_loss", "take_profit"):
                try:
                    value = float(self.signal_levels.get(key))
                    if isfinite(value) and value > 0:
                        overlay_values.append(value)
                except (TypeError, ValueError):
                    pass
        for value in overlay_values:
            if pmin - candle_span * 0.08 <= value <= pmax + candle_span * 0.08:
                pmin = min(pmin, value)
                pmax = max(pmax, value)
        pad = max((pmax - pmin) * 0.07, abs(pmax) * 0.00002)
        pmin -= pad; pmax += pad

        def x_for(i): return left + (i + 0.5) * plot_width / count
        def y_for(price): return price_bottom - ((price - pmin) / (pmax - pmin)) * plot_height

        # Header / current quote-like close.
        painter.setPen(QColor("#d6deeb"))
        last_completed_close = rate_series(self.rates[-2:-1], "close")[0] if len(self.rates) > 1 else closes[-1]
        painter.drawText(22, 22, f"{self.symbol}  |  {self.timeframe}  |  {count} شمعة  |  آخر إغلاق مكتمل: {last_completed_close:.{self.digits}f}")
        painter.setFont(QFont("Segoe UI", 8))
        painter.setPen(QColor("#aab4c0"))
        painter.drawText(22, 34, "القمة/القاع المحليان: بنية سعرية سابقة مؤكدة، وليسا توقعًا لهبوط أو صعود")

        # Main chart background and grid / price scale.
        painter.fillRect(QRectF(left, price_top, plot_width, plot_height), QColor("#111317"))
        painter.setFont(QFont("Segoe UI", 8))
        painter.setPen(QPen(QColor("#2a3039"), 1, Qt.PenStyle.DashLine))
        for grid_i in range(7):
            y = price_top + plot_height * grid_i / 6
            painter.drawLine(QPointF(left, y), QPointF(right, y))
            value = pmax - (pmax - pmin) * grid_i / 6
            painter.setPen(QColor("#aab4c0"))
            painter.drawText(QRectF(right + 5, y - 9, 84, 18), Qt.AlignmentFlag.AlignVCenter,
                             f"{value:.{self.digits}f}")
            painter.setPen(QPen(QColor("#2a3039"), 1, Qt.PenStyle.DashLine))
        for grid_i in range(9):
            x = left + plot_width * grid_i / 8
            painter.drawLine(QPointF(x, price_top), QPointF(x, price_bottom))

        # Bollinger lines behind the candles.
        if self.options.get("bollinger"):
            self._line_series(painter, bb_upper, x_for, y_for, QColor("#9c85ff"), 1.1, True)
            self._line_series(painter, bb_mid, x_for, y_for, QColor("#8270c9"), 0.8, True)
            self._line_series(painter, bb_lower, x_for, y_for, QColor("#9c85ff"), 1.1, True)

        # Draw candles.
        candle_slot = plot_width / count
        body_width = max(2.4, min(11.0, candle_slot * 0.76))
        for i, (op, hi, lo, cl) in enumerate(zip(opens, highs, lows, closes)):
            x = x_for(i)
            rising = cl >= op
            color = QColor("#36d98c") if rising else QColor("#ff5c67")
            painter.setPen(QPen(color, 1.15))
            painter.drawLine(QPointF(x, y_for(hi)), QPointF(x, y_for(lo)))
            top = y_for(max(op, cl)); bottom = y_for(min(op, cl))
            if bottom - top < 1.3: bottom = top + 1.3
            painter.fillRect(QRectF(x - body_width / 2, top, body_width, bottom - top), color)

        # Overlay indicators.
        if self.options.get("sma10"):
            self._line_series(painter, sma10_values, x_for, y_for, QColor("#ffd166"), 1.7)
        if self.options.get("sma30"):
            self._line_series(painter, sma30_values, x_for, y_for, QColor("#4dabf7"), 1.7)
        if self.options.get("ema20"):
            self._line_series(painter, ema20_values, x_for, y_for, QColor("#f08cba"), 1.5)

        # Automatic S/R based on previous closed candles.
        if self.options.get("sr"):
            for value, label, color in ((sr_support, "S20", QColor("#38bdf8")),
                                        (sr_resistance, "R20", QColor("#fb7185"))):
                if value is not None:
                    y = y_for(value)
                    painter.setPen(QPen(color, 1.2, Qt.PenStyle.DashLine))
                    painter.drawLine(QPointF(left, y), QPointF(right, y))
                    painter.setPen(color)
                    painter.drawText(QRectF(left + 4, y - 18, 64, 16), Qt.AlignmentFlag.AlignLeft, f"{label} {value:.{self.digits}f}")
        # Visualize the latest paper signal with entry, stop and target levels.
        # These are analysis overlays only and are never sent to the broker.
        signal_symbol = str(self.signal_levels.get("symbol") or self.symbol) if self.signal_levels else ""
        if self.signal_levels and signal_symbol.casefold() == self.symbol.casefold():
            direction = self.signal_levels.get("direction", "WAIT")
            signal_styles = (
                ("entry", "ENTRADA", QColor("#f8c555"), Qt.PenStyle.SolidLine),
                ("stop_loss", "STOP", QColor("#ff5c67"), Qt.PenStyle.DashLine),
                ("take_profit", "TARGET", QColor("#36d98c"), Qt.PenStyle.DashLine),
            )
            for key, label, color, style in signal_styles:
                try:
                    value = float(self.signal_levels.get(key))
                    if not isfinite(value) or value <= 0:
                        continue
                    y = y_for(value)
                    painter.setPen(QPen(color, 1.8 if key == "entry" else 1.3, style))
                    painter.drawLine(QPointF(left, y), QPointF(right, y))
                    painter.setPen(color)
                    painter.drawText(QRectF(left + 4, y - 17, 210, 15), Qt.AlignmentFlag.AlignLeft,
                                     f"{direction} {label}: {value:.{self.digits}f}")
                except (TypeError, ValueError):
                    continue

        # Mark only swings confirmed by two later *completed* bars. Their
        # labels explicitly say local structure, not a forecast of reversal.
        if self.options.get("sr") and len(closed_rows) >= 9:
            all_swings = confirmed_swing_points(closed_rows, left_bars=2, right_bars=2)
            swing_points = [point for point in all_swings
                            if visible_start <= point["index"] < visible_start + count]
            # Label at most the latest six points; all earlier visible pivots keep dots.
            label_points = {(point["index"], point["kind"])
                            for point in swing_points[-6:]}
            for point in swing_points:
                global_i = point["index"]
                i = global_i - visible_start
                price = float(point["price"])
                is_high = point["kind"] == "HIGH"
                label = "قمة محلية" if is_high else "قاع محلي"
                color = QColor("#fb7185") if is_high else QColor("#38bdf8")
                y_offset = -20 if is_high else 5
                x, y = x_for(i), y_for(price)
                # Hollow marker shows the historical pivot; a second marker on
                # the confirmation candle shows when it became knowable.
                painter.setPen(QPen(color, 1.2))
                painter.setBrush(QBrush(QColor("#111317")))
                painter.drawEllipse(QPointF(x, y), 3.2, 3.2)
                confirmation_index = int(point["confirmed_at_index"])
                confirmation_visible = visible_start <= confirmation_index < visible_start + count
                label_x = x
                if confirmation_visible:
                    cx, cy = x_for(confirmation_index - visible_start), y_for(price)
                    painter.setPen(QPen(color, 1.0, Qt.PenStyle.DotLine))
                    painter.drawLine(QPointF(x, y), QPointF(cx, cy))
                    painter.setBrush(QBrush(color))
                    painter.drawEllipse(QPointF(cx, cy), 2.4, 2.4)
                    label_x = cx
                if (global_i, point["kind"]) in label_points:
                    label_width = 100
                    label_text = ("قمة مؤكدة" if is_high else "قاع مؤكد") if confirmation_visible else ("قمة سابقة" if is_high else "قاع سابق")
                    painter.setBrush(QBrush(QColor("#101827")))
                    label_rect = QRectF(max(left, min(right - label_width, label_x - label_width / 2)),
                                        y + y_offset, label_width, 16)
                    painter.setPen(QPen(color, 1.0))
                    painter.drawRoundedRect(label_rect, 4, 4)
                    painter.setPen(color)
                    painter.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
                    painter.drawText(label_rect, Qt.AlignmentFlag.AlignCenter, label_text)
            painter.setBrush(Qt.BrushStyle.NoBrush)

        # Draw a clear BUY/SELL badge and directional marker only when the
        # signal engine has supplied an actionable paper signal for this symbol.
        if self.signal_levels and signal_symbol.casefold() == self.symbol.casefold():
            direction = str(self.signal_levels.get("direction", "WAIT")).upper()
            if direction in ("BUY", "SELL"):
                color = QColor("#12c995") if direction == "BUY" else QColor("#fb5365")
                x = x_for(count - 1)
                price = closes[-1]
                y = y_for(price)
                if direction == "BUY":
                    triangle = QPolygonF([QPointF(x, y + 2), QPointF(x - 7, y + 14), QPointF(x + 7, y + 14)])
                    badge_text = "شراء  ▲"
                else:
                    triangle = QPolygonF([QPointF(x, y - 2), QPointF(x - 7, y - 14), QPointF(x + 7, y - 14)])
                    badge_text = "بيع  ▼"
                painter.setPen(QPen(color, 1.2))
                painter.setBrush(QBrush(color))
                painter.drawPolygon(triangle)
                badge_x = max(left + 4, min(right - 88, x - 44))
                badge_y = max(price_top + 3, min(price_bottom - 24, y - 31 if direction == "BUY" else y + 15))
                badge = QRectF(badge_x, badge_y, 84, 20)
                painter.setBrush(QBrush(QColor("#101827")))
                painter.setPen(QPen(color, 1.2))
                painter.drawRoundedRect(badge, 5, 5)
                painter.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
                painter.setPen(color)
                painter.drawText(badge, Qt.AlignmentFlag.AlignCenter, badge_text)

        # Manually drawn price levels.
        for idx, value in enumerate(self.manual_levels, 1):
            y = y_for(value)
            painter.setPen(QPen(QColor("#f8c555"), 1.4, Qt.PenStyle.DashLine))
            painter.drawLine(QPointF(left, y), QPointF(right, y))
            painter.setPen(QColor("#f8c555"))
            painter.drawText(QRectF(left + 4, y - 18, 150, 16), Qt.AlignmentFlag.AlignLeft,
                             f"مستوى يدوي {idx}: {value:.{self.digits}f}")

        # Time axis labels.
        painter.setPen(QColor("#aab4c0"))
        for grid_i in range(5):
            index = min(count - 1, int(grid_i * (count - 1) / 4))
            try:
                timestamp = int(rows[index]["time"])
                stamp = datetime.fromtimestamp(timestamp).strftime("%m-%d %H:%M")
            except Exception:
                stamp = str(index)
            x = x_for(index)
            painter.drawText(QRectF(x - 50, price_bottom + 4, 100, 16), Qt.AlignmentFlag.AlignHCenter, stamp)

        y_cursor = price_bottom + 24
        if self.options.get("volume"):
            height = volume_height - 5
            max_volume = max(volumes) if volumes else 0
            vol_top = y_cursor + 3
            painter.fillRect(QRectF(left, vol_top, plot_width, height), QColor("#111317"))
            for i, volume in enumerate(volumes):
                bar_h = (volume / max_volume * (height - 4)) if max_volume > 0 else 0
                color = QColor("#286b55") if closes[i] >= opens[i] else QColor("#7a3037")
                painter.fillRect(QRectF(x_for(i) - body_width / 2, vol_top + height - bar_h,
                                        body_width, bar_h), color)
            painter.setPen(QColor("#aab4c0")); painter.drawText(QRectF(left + 3, vol_top, 100, 14), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, "Tick volume")
            y_cursor += volume_height

        if self.options.get("rsi"):
            pane = QRectF(left, y_cursor + 3, plot_width, 72)
            painter.fillRect(pane, QColor("#111317"))
            rsi_y = lambda val: pane.bottom() - (max(0.0, min(100.0, val)) / 100.0) * pane.height()
            for val in (30, 50, 70):
                y = rsi_y(val)
                painter.setPen(QPen(QColor("#333a46"), 1, Qt.PenStyle.DashLine))
                painter.drawLine(QPointF(left, y), QPointF(right, y))
                painter.setPen(QColor("#aab4c0")); painter.drawText(QRectF(right + 5, y - 8, 30, 16), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, f"{val}")
            self._line_series(painter, rsi_values, x_for, rsi_y, QColor("#c084fc"), 1.5)
            painter.setPen(QColor("#d6deeb")); painter.drawText(QRectF(left + 3, pane.top() + 2, 150, 16), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, f"RSI(14) {last_completed_rsi:.1f}" if last_completed_rsi is not None else "RSI(14) —")
            y_cursor = pane.bottom() + 4

        if self.options.get("macd"):
            pane = QRectF(left, y_cursor + 3, plot_width, 72)
            painter.fillRect(pane, QColor("#111317"))
            numeric = [abs(float(v)) for series in (macd_hist, macd_line, macd_signal) for v in series if v is not None]
            limit = max(numeric) if numeric else 1.0
            limit = max(limit, 1e-8)
            mid_y = pane.top() + pane.height() / 2
            painter.setPen(QPen(QColor("#333a46"), 1, Qt.PenStyle.DashLine)); painter.drawLine(QPointF(left, mid_y), QPointF(right, mid_y))
            xw = max(1.0, candle_slot * 0.55)
            for i, value in enumerate(macd_hist):
                if value is None: continue
                bh = abs(float(value)) / limit * pane.height() * 0.42
                color = QColor("#36d98c") if value >= 0 else QColor("#ff5c67")
                painter.fillRect(QRectF(x_for(i) - xw/2, mid_y - bh if value >= 0 else mid_y, xw, bh), color)
            min_macd, max_macd = -limit, limit
            my = lambda val: pane.bottom() - ((val - min_macd) / (max_macd - min_macd)) * pane.height()
            self._line_series(painter, macd_line, x_for, my, QColor("#ffd166"), 1.2)
            self._line_series(painter, macd_signal, x_for, my, QColor("#4dabf7"), 1.2)
            painter.setPen(QColor("#d6deeb")); painter.drawText(QRectF(left + 3, pane.top() + 2, 260, 16), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, f"MACD(12,26,9) {last_completed_macd:.5f}" if last_completed_macd is not None else "MACD(12,26,9) —")

        # Latest indicator line uses full history, so zooming cannot change
        # values for the same last completed candle.
        vals = latest_indicator_values(self.rates)
        parts = []
        for key, label, opt in (("sma10", "SMA10", "sma10"), ("sma30", "SMA30", "sma30"),
                                ("ema20", "EMA20", "ema20"), ("rsi14", "RSI14", "rsi"),
                                ("bb_upper", "BB↑", "bollinger"), ("support20", "S20", "sr"),
                                ("resistance20", "R20", "sr"), ("atr14", "ATR14", "atr")):
            if self.options.get(opt) and vals.get(key) is not None:
                fmt = ".1f" if key == "rsi14" else f".{self.digits}f"
                parts.append(f"{label}={format(vals[key], fmt)}")
        painter.setPen(QColor("#cbd5e1")); painter.setFont(QFont("Segoe UI", 8))
        painter.drawText(QRectF(left, self.height() - 17, self.width() - 30, 14), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, " | ".join(parts))
        painter.end()


class ChartWindow(QDialog):
    """Separate built-in chart window with user-controlled indicators and drawing levels."""
    def __init__(self, mt5_connection, symbol="BTCUSD", timeframe="M15", parent=None):
        super().__init__(parent)
        self.mt5 = mt5_connection
        self.setWindowTitle("Apex Alpha — الشارت الداخلي وأدوات التحليل")
        # Expose native minimize/maximize/close controls on the chart window.
        # On Windows 11, hovering over maximize opens the OS Snap Layouts menu.
        self.setWindowFlags(self.windowFlags() | Qt.WindowType.WindowMinimizeButtonHint |
                            Qt.WindowType.WindowMaximizeButtonHint | Qt.WindowType.WindowSystemMenuHint)
        self.setSizeGripEnabled(True)
        self.resize(1280, 850)
        self.chart = CandleChart(self)
        self._loading = False

        root = QVBoxLayout(self)
        top = QHBoxLayout()
        top.addWidget(QLabel("الرمز"))
        self.symbol_edit = QLineEdit(symbol)
        self.symbol_edit.setMaximumWidth(150)
        top.addWidget(self.symbol_edit)
        top.addWidget(QLabel("الإطار"))
        self.timeframe_combo = QComboBox()
        self.timeframe_combo.addItems(["M1", "M5", "M15", "M30", "H1", "H4", "D1"])
        self.timeframe_combo.setCurrentText(timeframe if timeframe in ["M1", "M5", "M15", "M30", "H1", "H4", "D1"] else "M15")
        top.addWidget(self.timeframe_combo)
        top.addWidget(QLabel("عدد الشموع"))
        self.count_spin = QSpinBox(); self.count_spin.setRange(60, 250); self.count_spin.setSingleStep(20); self.count_spin.setValue(150)
        top.addWidget(self.count_spin)
        self.refresh_btn = QPushButton("تحديث الشارت")
        self.refresh_btn.clicked.connect(self.refresh_chart)
        top.addWidget(self.refresh_btn)
        self.auto_check = QCheckBox("تحديث كل ثانيتين")
        self.auto_check.setChecked(True)
        top.addWidget(self.auto_check)
        self.half_left_btn = QPushButton("تقسيم: الشارت يسارًا")
        self.half_right_btn = QPushButton("تقسيم: الشارت يمينًا")
        self.maximize_btn = QPushButton("تكبير الشارت")
        self.half_left_btn.clicked.connect(lambda: self.snap_to_side("left"))
        self.half_right_btn.clicked.connect(lambda: self.snap_to_side("right"))
        self.maximize_btn.clicked.connect(self.showMaximized)
        top.addWidget(self.half_left_btn); top.addWidget(self.half_right_btn); top.addWidget(self.maximize_btn)
        top.addStretch()
        root.addLayout(top)

        indicators_box = QGroupBox("المؤشرات والأدوات — اختر ما تريد أن يعرضه الشارت")
        indicators_layout = QGridLayout(indicators_box)
        self.indicator_checks: dict[str, QCheckBox] = {}
        indicator_specs = [
            ("sma10", "SMA 10", True), ("sma30", "SMA 30", True),
            ("ema20", "EMA 20", False), ("bollinger", "Bollinger Bands", False),
            ("sr", "دعم ومقاومة تلقائيان", True), ("volume", "حجم التداول Tick Volume", True),
            ("rsi", "RSI (14) — لوحة سفلية", True), ("macd", "MACD (12,26,9) — لوحة سفلية", False),
            ("atr", "ATR (14) — قراءة التقلب", True),
        ]
        for idx, (key, label, checked) in enumerate(indicator_specs):
            checkbox = QCheckBox(label); checkbox.setChecked(checked)
            checkbox.toggled.connect(lambda value, k=key: self._on_indicator_toggle(k, value))
            self.indicator_checks[key] = checkbox
            indicators_layout.addWidget(checkbox, idx // 3, idx % 3)
        root.addWidget(indicators_box)
        auto_tools_row = QHBoxLayout()
        self.auto_tools_btn = QPushButton("اختيار الأدوات تلقائيًا حسب حالة السوق")
        self.auto_tools_btn.clicked.connect(self.auto_select_tools)
        self.tool_advice_label = QLabel("الاختيار اليدوي متاح؛ الاختيار التلقائي يغيّر عرض المؤشرات فقط ولا يغيّر إشارة التداول.")
        self.tool_advice_label.setWordWrap(True)
        auto_tools_row.addWidget(self.auto_tools_btn)
        auto_tools_row.addWidget(self.tool_advice_label, 1)
        root.addLayout(auto_tools_row)
        self.analysis_label = QLabel("تحليل المؤشرات المفعّلة سيظهر بعد تحميل بيانات كافية.")
        self.analysis_label.setWordWrap(True)
        self.analysis_label.setStyleSheet("color: #b8c9e8; padding: 5px; border: 1px solid #303640; border-radius: 4px;")
        root.addWidget(self.analysis_label)

        draw_box = QGroupBox("أدوات الرسم")
        draw_layout = QHBoxLayout(draw_box)
        draw_layout.addWidget(QLabel("إضافة مستوى سعري أفقي:"))
        self.level_spin = QDoubleSpinBox(); self.level_spin.setDecimals(8); self.level_spin.setRange(0.00000001, 1_000_000_000); self.level_spin.setValue(1.0); self.level_spin.setMaximumWidth(190)
        draw_layout.addWidget(self.level_spin)
        self.add_level_btn = QPushButton("إضافة مستوى")
        self.add_level_btn.clicked.connect(lambda: self.chart.add_level(self.level_spin.value()))
        self.clear_levels_btn = QPushButton("مسح المستويات اليدوية")
        self.clear_levels_btn.clicked.connect(self.chart.clear_levels)
        draw_layout.addWidget(self.add_level_btn); draw_layout.addWidget(self.clear_levels_btn); draw_layout.addStretch()
        root.addWidget(draw_box)
        root.addWidget(self.chart, 1)
        self.account_summary_label = QLabel("الحساب: في انتظار بيانات MT5")
        self.account_summary_label.setWordWrap(True)
        self.account_summary_label.setStyleSheet("color: #a7c5ff; padding: 6px; background: #101a2b; border: 1px solid #283750; border-radius: 6px;")
        root.addWidget(self.account_summary_label)
        self.status_label = QLabel("الشارت مستقل للقراءة فقط؛ لا يرسل أوامر تداول.")
        self.status_label.setWordWrap(True)
        self.status_label.setStyleSheet("color: #d99b48; padding: 4px;")
        root.addWidget(self.status_label)

        self.timer = QTimer(self)
        self.timer.timeout.connect(self._auto_refresh)
        self.timer.start(2000)
        self.auto_check.toggled.connect(self._toggle_auto)
        self.refresh_chart()

    def set_account_summary(self, text: str):
        self.account_summary_label.setText(str(text or "الحساب: في انتظار بيانات MT5"))

    def _enabled_tools(self) -> dict[str, bool]:
        return {key: checkbox.isChecked() for key, checkbox in self.indicator_checks.items()}

    def _on_indicator_toggle(self, key: str, enabled: bool):
        self.chart.set_options(key, enabled)
        self.update_indicator_analysis()

    def update_indicator_analysis(self):
        result = evaluate_enabled_indicators(self.chart.rates, self._enabled_tools())
        vote_text = "، ".join(f"{name}: {'صعودي' if direction == 'BULLISH' else 'هبوطي' if direction == 'BEARISH' else 'محايد'}"
                              for name, direction in result.get("votes", []))
        context_text = " | ".join(result.get("context", []))
        counts = f"الأصوات: صعود {result.get('bullish', 0)} / هبوط {result.get('bearish', 0)} / محايد {result.get('neutral', 0)}"
        text = result.get("label", "")
        if vote_text:
            text += " — " + vote_text
        if result.get("votes"):
            text += " — " + counts
        if context_text:
            text += "\n" + context_text
        text += "\nهذه قراءة توافق للمؤشرات المختارة فقط؛ لا تغيّر إشارة البوت الأساسية ولا تمثل أمر تداول."
        self.analysis_label.setText(text)

    def set_selection(self, symbol: str, timeframe: str):
        self.symbol_edit.setText(symbol or "BTCUSD")
        if timeframe in ["M1", "M5", "M15", "M30", "H1", "H4", "D1"]:
            self.timeframe_combo.setCurrentText(timeframe)
        self.refresh_chart()

    def _toggle_auto(self, enabled: bool):
        if enabled:
            self.timer.start(2000)
        else:
            self.timer.stop()

    def _auto_refresh(self):
        if self.auto_check.isChecked():
            self.refresh_chart(silent=True)

    def auto_select_tools(self):
        """Select chart overlays/panels using simple transparent rules; signal engine is untouched."""
        values = self.chart.indicator_values()
        if values.get("atr14") is None or values.get("sma10") is None or values.get("sma30") is None:
            self.tool_advice_label.setText("بيانات غير كافية لاختيار الأدوات تلقائيًا؛ حدّث الشارت وحاول مجددًا.")
            return
        preset, reason = recommend_chart_tools(values.get("atr_ratio"), values.get("trend_spread_atr"))
        for key, enabled in preset.items():
            self.indicator_checks[key].setChecked(enabled)
        self.tool_advice_label.setText(reason + " هذا اختيار بصري إرشادي فقط، لا يغيّر BUY/SELL/WAIT ولا يضمن نتيجة تداول.")
        self.chart.update()
        self.update_indicator_analysis()

    def snap_to_side(self, side):
        """Resize chart to exactly half the available desktop for side-by-side use."""
        screen = self.screen() or QApplication.primaryScreen()
        if screen is None:
            return
        area = screen.availableGeometry()
        half = area.width() // 2
        x = area.x() if side == "left" else area.x() + half
        self.showNormal()
        self.setGeometry(x, area.y(), half, area.height())

    def refresh_chart(self, silent=False):
        if self._loading:
            return
        symbol = self.symbol_edit.text().strip()
        timeframe = self.timeframe_combo.currentText()
        if not symbol:
            self.status_label.setText("أدخل رمز الأداة كما يظهر في MT5.")
            return
        self._loading = True
        self.refresh_btn.setEnabled(False)
        try:
            result = self.mt5.read_chart_data(symbol, timeframe, self.count_spin.value())
            if not result.get("ok"):
                self.status_label.setText("تعذر تحديث الشارت: " + str(result.get("error", "خطأ غير معروف")))
                if not silent:
                    QMessageBox.warning(self, "تعذر تحديث الشارت", self.status_label.text())
                return
            self.chart.set_data(result["bars"], symbol, timeframe, result.get("digits", 2))
            dashboard = self.parent()
            if dashboard is not None and hasattr(dashboard, "latest_analysis_signal"):
                self.chart.set_signal_levels(dashboard.latest_analysis_signal)
            self.update_indicator_analysis()
            values = self.chart.indicator_values()
            details = []
            visibility = {
                "sma10": "sma10", "sma30": "sma30", "ema20": "ema20",
                "rsi14": "rsi", "macd": "macd", "support20": "sr",
                "resistance20": "sr", "atr14": "atr",
            }
            for key, label, precision in (("sma10", "SMA10", "price"), ("sma30", "SMA30", "price"),
                                          ("ema20", "EMA20", "price"), ("rsi14", "RSI14", "rsi"),
                                          ("macd", "MACD", "macd"), ("atr14", "ATR14", "price"),
                                          ("support20", "الدعم", "price"), ("resistance20", "المقاومة", "price")):
                key_opt = visibility[key]
                if values.get(key) is None or not self.indicator_checks[key_opt].isChecked():
                    continue
                value = values[key]
                if precision == "rsi": shown = f"{value:.1f}"
                elif precision == "macd": shown = f"{value:.5f}"
                else: shown = f"{value:.{self.chart.digits}f}"
                details.append(f"{label}: {shown}")
            self.status_label.setText(
                f"{symbol}/{timeframe} — {len(result['bars'])} شمعة | آخر تحديث {datetime.now().astimezone().strftime('%H:%M:%S')} محليًا | "
                + " | ".join(details) + " | الشارت للتحليل البصري فقط؛ اختيار المؤشرات لا يرسل أوامر تداول."
            )
        except Exception as exc:
            self.status_label.setText(f"خطأ أثناء تحديث الشارت: {exc}")
            if not silent:
                QMessageBox.warning(self, "خطأ", self.status_label.text())
        finally:
            self._loading = False
            self.refresh_btn.setEnabled(True)
