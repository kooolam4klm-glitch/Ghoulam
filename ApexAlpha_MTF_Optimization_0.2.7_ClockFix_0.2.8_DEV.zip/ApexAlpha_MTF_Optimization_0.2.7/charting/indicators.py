"""Pure-Python indicator calculations used by the built-in read-only chart."""
from __future__ import annotations
from math import isfinite, sqrt
from typing import Any, Iterable


def field(row: Any, key: str) -> float:
    try:
        return float(row[key])
    except (TypeError, KeyError, IndexError, ValueError):
        return float(getattr(row, key))


def rate_series(rates: Iterable[Any], key: str) -> list[float]:
    return [field(row, key) for row in rates]


def sma(values: list[float], period: int) -> list[float | None]:
    if period <= 0:
        raise ValueError("period must be positive")
    out: list[float | None] = [None] * len(values)
    rolling = 0.0
    for i, value in enumerate(values):
        rolling += value
        if i >= period:
            rolling -= values[i - period]
        if i >= period - 1:
            out[i] = rolling / period
    return out


def ema(values: list[float], period: int) -> list[float | None]:
    if period <= 0:
        raise ValueError("period must be positive")
    out: list[float | None] = [None] * len(values)
    if len(values) < period:
        return out
    current = sum(values[:period]) / period
    out[period - 1] = current
    alpha = 2.0 / (period + 1.0)
    for i in range(period, len(values)):
        current = (values[i] - current) * alpha + current
        out[i] = current
    return out


def bollinger(values: list[float], period: int = 20, deviations: float = 2.0):
    middle = sma(values, period)
    upper: list[float | None] = [None] * len(values)
    lower: list[float | None] = [None] * len(values)
    for i in range(period - 1, len(values)):
        window = values[i - period + 1:i + 1]
        avg = sum(window) / period
        variance = sum((x - avg) ** 2 for x in window) / period
        sd = sqrt(max(0.0, variance))
        upper[i] = avg + deviations * sd
        lower[i] = avg - deviations * sd
    return middle, upper, lower


def rsi(values: list[float], period: int = 14) -> list[float | None]:
    out: list[float | None] = [None] * len(values)
    if period <= 0 or len(values) <= period:
        return out
    changes = [values[i] - values[i - 1] for i in range(1, len(values))]
    gains = [max(x, 0.0) for x in changes]
    losses = [max(-x, 0.0) for x in changes]
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    def value(gain: float, loss: float) -> float:
        if loss == 0:
            return 100.0 if gain > 0 else 50.0
        return 100.0 - (100.0 / (1.0 + gain / loss))
    out[period] = value(avg_gain, avg_loss)
    for j in range(period, len(changes)):
        avg_gain = (avg_gain * (period - 1) + gains[j]) / period
        avg_loss = (avg_loss * (period - 1) + losses[j]) / period
        out[j + 1] = value(avg_gain, avg_loss)
    return out


def macd(values: list[float], fast: int = 12, slow: int = 26, signal_period: int = 9):
    fast_ema = ema(values, fast)
    slow_ema = ema(values, slow)
    line: list[float | None] = [None] * len(values)
    compact_indices: list[int] = []
    compact_values: list[float] = []
    for i in range(len(values)):
        if fast_ema[i] is not None and slow_ema[i] is not None:
            line[i] = float(fast_ema[i]) - float(slow_ema[i])
            compact_indices.append(i)
            compact_values.append(line[i])
    signal_compact = ema(compact_values, signal_period)
    signal: list[float | None] = [None] * len(values)
    hist: list[float | None] = [None] * len(values)
    for j, index in enumerate(compact_indices):
        signal[index] = signal_compact[j]
        if signal_compact[j] is not None and line[index] is not None:
            hist[index] = float(line[index]) - float(signal_compact[j])
    return line, signal, hist


def support_resistance(rates: Iterable[Any], lookback: int = 20) -> tuple[float | None, float | None]:
    rows = list(rates)
    if lookback <= 0:
        raise ValueError("lookback must be positive")
    # Exclude the potentially forming newest candle if possible.
    closed = rows[:-1] if len(rows) > 1 else rows
    window = closed[-lookback:]
    if not window:
        return None, None
    lows = [field(row, "low") for row in window]
    highs = [field(row, "high") for row in window]
    return min(lows), max(highs)


def confirmed_swing_points(rates: Iterable[Any], left_bars: int = 2,
                           right_bars: int = 2) -> list[dict[str, Any]]:
    """Return confirmed local highs/lows from *completed bars only*.

    A point at index i is reported only after `right_bars` later completed bars
    are present. The index points to the swing candle; `confirmed_at_index`
    points to the candle that made the swing knowable in real time. Strict
    comparisons avoid drawing multiple pivots across a flat equal-high/low top.
    This describes past local structure; it does not predict reversal.
    """
    rows = list(rates)
    left_bars, right_bars = int(left_bars), int(right_bars)
    if left_bars < 1 or right_bars < 1:
        raise ValueError("left_bars and right_bars must be positive")
    if not rows or len(rows) < left_bars + right_bars + 1:
        return []

    highs = [field(row, "high") for row in rows]
    lows = [field(row, "low") for row in rows]

    def bar_time(row):
        try:
            return int(row["time"])
        except (TypeError, KeyError, IndexError, ValueError):
            try:
                return int(getattr(row, "time"))
            except (TypeError, ValueError, AttributeError):
                return None

    points: list[dict[str, Any]] = []
    for i in range(left_bars, len(rows) - right_bars):
        left_highs = highs[i-left_bars:i]
        right_highs = highs[i+1:i+right_bars+1]
        left_lows = lows[i-left_bars:i]
        right_lows = lows[i+1:i+right_bars+1]
        if all(highs[i] > value for value in left_highs + right_highs):
            points.append({"index": i, "kind": "HIGH", "price": highs[i],
                           "time": bar_time(rows[i]),
                           "confirmed_at_index": i + right_bars,
                           "confirmed_at_time": bar_time(rows[i + right_bars])})
        if all(lows[i] < value for value in left_lows + right_lows):
            points.append({"index": i, "kind": "LOW", "price": lows[i],
                           "time": bar_time(rows[i]),
                           "confirmed_at_index": i + right_bars,
                           "confirmed_at_time": bar_time(rows[i + right_bars])})
    points.sort(key=lambda item: (item["index"], item["kind"]))
    return points



def atr_series(rates: Iterable[Any], period: int = 14) -> list[float | None]:
    rows = list(rates)
    out: list[float | None] = [None] * len(rows)
    if period <= 0 or len(rows) < period:
        return out
    true_ranges: list[float] = []
    for i, row in enumerate(rows):
        high = field(row, "high")
        low = field(row, "low")
        if i == 0:
            true_ranges.append(max(0.0, high - low))
        else:
            prev_close = field(rows[i - 1], "close")
            true_ranges.append(max(high - low, abs(high - prev_close), abs(low - prev_close)))
    rolling = sum(true_ranges[:period])
    out[period - 1] = rolling / period
    for i in range(period, len(rows)):
        rolling += true_ranges[i] - true_ranges[i - period]
        out[i] = rolling / period
    return out



def atr_wilder_series(rates: Iterable[Any], period: int = 14) -> list[float | None]:
    """Wilder ATR (RMA of true range), aligned to input rows."""
    rows = list(rates)
    out: list[float | None] = [None] * len(rows)
    if period <= 0 or len(rows) < period:
        return out
    true_ranges: list[float] = []
    for i, row in enumerate(rows):
        high, low = field(row, "high"), field(row, "low")
        if i == 0:
            true_ranges.append(max(0.0, high - low))
        else:
            prev_close = field(rows[i - 1], "close")
            true_ranges.append(max(high - low, abs(high - prev_close), abs(low - prev_close)))
    current = sum(true_ranges[:period]) / period
    out[period - 1] = current
    for i in range(period, len(rows)):
        current = ((current * (period - 1)) + true_ranges[i]) / period
        out[i] = current
    return out


def latest_indicator_values(rates: Iterable[Any]) -> dict[str, float | None]:
    source_rows = list(rates)
    # MT5 normally includes a still-forming final candle. Compute indicator
    # values only on completed bars, but retain source_rows for helpers such
    # as support_resistance that already exclude that final candle themselves.
    rows = source_rows[:-1] if len(source_rows) > 1 else source_rows
    closes = rate_series(rows, "close")
    if not closes:
        return {key: None for key in ("close", "sma10", "sma30", "ema20", "rsi14", "macd", "macd_signal",
                                       "bb_upper", "bb_lower", "atr14", "atr_ratio",
                                       "trend_spread_atr", "support20", "resistance20")}
    sma10 = sma(closes, 10)
    sma30 = sma(closes, 30)
    ema20 = ema(closes, 20)
    rsi14 = rsi(closes, 14)
    _, bb_upper, bb_lower = bollinger(closes, 20, 2.0)
    macd_line, macd_signal, _ = macd(closes)
    atr_values = atr_series(rows, 14)
    support, resistance = support_resistance(source_rows)
    atr_valid = [float(value) for value in atr_values if value is not None]
    atr_current = atr_values[-1] if atr_values else None
    atr_baseline_values = atr_valid[-31:-1] if len(atr_valid) > 1 else []
    atr_baseline = sum(atr_baseline_values) / len(atr_baseline_values) if atr_baseline_values else atr_current
    atr_ratio = (float(atr_current) / float(atr_baseline)) if atr_current is not None and atr_baseline else None
    trend_spread_atr = (abs(float(sma10[-1]) - float(sma30[-1])) / float(atr_current)
                        if sma10[-1] is not None and sma30[-1] is not None and atr_current not in (None, 0) else None)
    result = {
        "close": closes[-1], "sma10": sma10[-1], "sma30": sma30[-1], "ema20": ema20[-1],
        "rsi14": rsi14[-1], "macd": macd_line[-1], "macd_signal": macd_signal[-1],
        "bb_upper": bb_upper[-1], "bb_lower": bb_lower[-1], "atr14": atr_current,
        "atr_ratio": atr_ratio, "trend_spread_atr": trend_spread_atr,
        "support20": support, "resistance20": resistance,
    }
    # Normalize invalid values to None.
    return {key: (float(val) if val is not None and isfinite(float(val)) else None)
            for key, val in result.items()}


def recommend_chart_tools(atr_ratio: float | None, trend_strength_atr: float | None) -> tuple[dict[str, bool], str]:
    """Transparent display preset recommendation; never generates a trade signal."""
    atr_ratio = float(atr_ratio) if atr_ratio is not None and isfinite(float(atr_ratio)) else 1.0
    trend_strength_atr = (float(trend_strength_atr)
                          if trend_strength_atr is not None and isfinite(float(trend_strength_atr)) else 0.0)
    if atr_ratio >= 1.5:
        preset = {"sma10": True, "sma30": True, "ema20": False, "bollinger": True,
                  "sr": True, "volume": True, "rsi": True, "macd": False, "atr": True}
        reason = f"تقلب مرتفع نسبيًا (ATR ×{atr_ratio:.2f}): أظهر Bollinger وRSI والحجم ومستويات الدعم والمقاومة."
    elif trend_strength_atr >= 0.45:
        preset = {"sma10": True, "sma30": True, "ema20": True, "bollinger": False,
                  "sr": True, "volume": True, "rsi": True, "macd": True, "atr": True}
        reason = f"تباعد المتوسطين يبلغ {trend_strength_atr:.2f} ATR: أظهر المتوسطات وMACD والحجم لقراءة الاتجاه."
    else:
        preset = {"sma10": True, "sma30": True, "ema20": False, "bollinger": True,
                  "sr": True, "volume": True, "rsi": True, "macd": False, "atr": True}
        reason = f"الاتجاه غير قوي بما يكفي (التباعد {trend_strength_atr:.2f} ATR): أظهر Bollinger وRSI ومستويات الدعم والمقاومة."
    return preset, reason


def evaluate_enabled_indicators(rates: Iterable[Any], enabled: dict[str, bool]) -> dict[str, Any]:
    """Summarize selected indicator votes as analysis context, not a trade order."""
    rows = list(rates)
    values = latest_indicator_values(rows)
    if len(rows) < 35 or values.get("close") is None:
        return {"status": "INSUFFICIENT", "label": "بيانات غير كافية لتحليل المؤشرات المفعّلة",
                "bullish": 0, "bearish": 0, "neutral": 0, "votes": [], "context": []}

    votes: list[tuple[str, str]] = []
    close = float(values["close"])
    if enabled.get("sma10") and enabled.get("sma30") and values.get("sma10") is not None and values.get("sma30") is not None:
        if values["sma10"] > values["sma30"]:
            votes.append(("تقاطع SMA10/30", "BULLISH"))
        elif values["sma10"] < values["sma30"]:
            votes.append(("تقاطع SMA10/30", "BEARISH"))
        else:
            votes.append(("تقاطع SMA10/30", "NEUTRAL"))
    if enabled.get("ema20") and values.get("ema20") is not None:
        votes.append(("السعر مقابل EMA20", "BULLISH" if close > values["ema20"] else "BEARISH" if close < values["ema20"] else "NEUTRAL"))
    if enabled.get("rsi") and values.get("rsi14") is not None:
        rsi_value = values["rsi14"]
        votes.append(("RSI14", "BULLISH" if rsi_value >= 55 else "BEARISH" if rsi_value <= 45 else "NEUTRAL"))
    if enabled.get("macd") and values.get("macd") is not None and values.get("macd_signal") is not None:
        votes.append(("MACD", "BULLISH" if values["macd"] > values["macd_signal"] else "BEARISH" if values["macd"] < values["macd_signal"] else "NEUTRAL"))

    bullish = sum(direction == "BULLISH" for _, direction in votes)
    bearish = sum(direction == "BEARISH" for _, direction in votes)
    neutral = sum(direction == "NEUTRAL" for _, direction in votes)
    if bullish >= 2 and bullish > bearish:
        status, label = "BULLISH_CONTEXT", "ميل المؤشرات المفعّلة: صعودي نسبيًا"
    elif bearish >= 2 and bearish > bullish:
        status, label = "BEARISH_CONTEXT", "ميل المؤشرات المفعّلة: هبوطي نسبيًا"
    elif len(votes) == 0:
        status, label = "NO_VOTES", "لا توجد مؤشرات اتجاهية كافية مفعّلة للمقارنة"
    else:
        status, label = "MIXED_CONTEXT", "المؤشرات المفعّلة متعارضة أو غير حاسمة"

    context: list[str] = []
    if enabled.get("bollinger") and values.get("bb_upper") is not None and values.get("bb_lower") is not None:
        if close > values["bb_upper"]:
            context.append("الإغلاق فوق Bollinger العلوي؛ قد يكون ممتدًا ولا يعني بيعًا تلقائيًا")
        elif close < values["bb_lower"]:
            context.append("الإغلاق تحت Bollinger السفلي؛ قد يكون ممتدًا ولا يعني شراءً تلقائيًا")
    if enabled.get("atr") and values.get("atr_ratio") is not None:
        ratio = values["atr_ratio"]
        context.append(f"التقلب بحسب ATR: {'مرتفع نسبيًا' if ratio >= 1.5 else 'منخفض نسبيًا' if ratio <= 0.67 else 'معتاد'} (×{ratio:.2f})")
    if enabled.get("sr") and values.get("support20") is not None and values.get("resistance20") is not None:
        context.append(f"نطاق آخر 20 شمعة مغلقة: دعم {values['support20']:.5f} / مقاومة {values['resistance20']:.5f}")
    return {"status": status, "label": label, "bullish": bullish, "bearish": bearish,
            "neutral": neutral, "votes": votes, "context": context}
